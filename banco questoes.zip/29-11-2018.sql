-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 29-Nov-2018 às 20:12
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Extraindo dados da tabela `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"vestibular\",\"table\":\"tb_cursos_tipo\"},{\"db\":\"vestibular\",\"table\":\"tb_tipo_prova\"},{\"db\":\"vestibular\",\"table\":\"tb_edital\"},{\"db\":\"vestibular\",\"table\":\"tb_instituicao\"},{\"db\":\"vestibular\",\"table\":\"tb_cota\"},{\"db\":\"vestibular\",\"table\":\"tb_cursos\"},{\"db\":\"vestibular\",\"table\":\"tb_disciplina\"},{\"db\":\"vestibular\",\"table\":\"tb_alternativas\"},{\"db\":\"vestibular\",\"table\":\"tb_gabarito\"},{\"db\":\"vestibular\",\"table\":\"tb_resultado_final\"}]');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Extraindo dados da tabela `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'vestibular', 'tb_cota', '{\"CREATE_TIME\":\"2018-11-24 16:13:36\",\"col_order\":[0,1,2],\"col_visib\":[1,1,1]}', '2018-11-24 22:12:40');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Extraindo dados da tabela `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2018-11-29 13:47:30', '{\"lang\":\"pt\",\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Estrutura da tabela `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
--
-- Database: `vestibular`
--
CREATE DATABASE IF NOT EXISTS `vestibular` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `vestibular`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2014_10_12_000000_create_users_table', 1),
(5, '2014_10_12_100000_create_password_resets_table', 1),
(6, '2018_11_24_181750_create_tb_alternativas', 1),
(8, '2018_11_24_183357_create_tb_instituicao', 2),
(9, '2018_11_24_183446_create_tb_tipo_prova', 2),
(13, '2018_11_24_184348_create_tb_cursos', 3),
(14, '2018_11_24_190831_create_tb_cursos_tipo', 3),
(15, '2018_11_24_191328_create_tb_disciplina', 3),
(17, '2018_11_24_193137_add_column_instituicao_tb_cursos', 4),
(18, '2018_11_24_200757_create_tb_cota', 5),
(20, '2018_11_24_203934_create_tb_resultado_final', 6),
(21, '2018_11_25_015541_create_tb_gabarito', 7),
(22, '2018_11_25_191618_add_column_tb_instituicao', 8),
(24, '2018_11_24_182407_create_tb_edital', 9);

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_alternativas`
--

CREATE TABLE `tb_alternativas` (
  `id` int(10) UNSIGNED NOT NULL,
  `descricao` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_alternativas`
--

INSERT INTO `tb_alternativas` (`id`, `descricao`) VALUES
(1, 'A'),
(2, 'B'),
(3, 'C'),
(4, 'D'),
(5, 'E'),
(6, 'ANULADA');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cota`
--

CREATE TABLE `tb_cota` (
  `id` int(10) UNSIGNED NOT NULL,
  `cota` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instituicao_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_cota`
--

INSERT INTO `tb_cota` (`id`, `cota`, `instituicao_id`) VALUES
(1, 'Pessoa com deficiência', '1'),
(2, 'Ampla concorrência', '1'),
(3, 'Escola Pública - RPF < 1,5 - Autodeclarado - PCD', '1'),
(4, 'Escola Pública - RPF < 1,5 - Autodeclarado - Demais Vagas', '1'),
(5, 'Escola Pública - RPF < 1,5 - Não Autodeclarado - PCD', '1'),
(6, 'Escola Pública - RPF < 1,5 - Não Autodeclarado - Demais Vagas', '1'),
(7, 'Escola Pública - RPF > 1,5 - Autodeclarado - PCD', '1'),
(8, 'Escola Pública - RPF > 1,5 - Autodeclarado - Demais Vagas', '1'),
(9, 'Escola Pública - RPF > 1,5 - Não Autodeclarado - PCD', '1'),
(10, 'Escola Pública - RPF > 1,5 - Não Autodeclarado - Demais Vagas', '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cursos`
--

CREATE TABLE `tb_cursos` (
  `id` int(10) UNSIGNED NOT NULL,
  `curso` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_curso_id` int(11) NOT NULL,
  `disciplina_especifica_1_id` int(11) NOT NULL,
  `disciplina_especifica_2_id` int(11) NOT NULL,
  `instituicao_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_cursos`
--

INSERT INTO `tb_cursos` (`id`, `curso`, `disciplina_especifica_1_id`, `disciplina_especifica_2_id`, `instituicao_id`) VALUES
(1, 'Agroecologia', 3, 1, 8, 1),
(2, 'Agronomia', 2, 1, 8, 1),
(3, 'Ciências Biológicas', 2, 1, 8, 1),
(4, 'Ciências Biológicas', 1, 1, 8, 1),
(5, 'Enfermagem', 2, 1, 8, 1),
(6, 'Medicina', 2, 1, 8, 1),
(7, 'Medicina Veterinária', 2, 1, 8, 1),
(8, 'Zootecnia', 2, 1, 8, 1),
(9, 'Arquitetura e Urbanismo', 2, 2, 4, 1),
(10, 'Ciência da Computação', 2, 2, 6, 1),
(11, 'Engenharia Civil', 2, 2, 6, 1),
(12, 'Engenharia Elétrica', 2, 2, 6, 1),
(13, 'Matemática', 2, 2, 6, 1),
(14, 'Matemática', 1, 2, 6, 1),
(15, 'Física', 1, 2, 6, 1),
(16, 'Geologia', 2, 2, 8, 1),
(17, 'Antropologia', 2, 3, 4, 1),
(18, 'Ciências Sociais', 2, 3, 4, 1),
(19, 'Relações Internacionais', 2, 3, 4, 1),
(20, 'Direito', 2, 3, 4, 1),
(21, 'História', 1, 3, 4, 1),
(22, 'Geografia', 1, 3, 7, 1),
(23, 'Geografia', 2, 3, 7, 1),
(24, 'Administração', 2, 4, 6, 1),
(25, 'Ciências Contábeis', 2, 4, 6, 1),
(26, 'Ciências Econômicas', 2, 4, 6, 1),
(27, 'Comunicação Social – Jornalismo', 2, 4, 7, 1),
(28, 'Letras - Libras', 2, 4, 7, 1),
(29, 'Psicologia', 2, 4, 7, 1),
(30, 'Música', 1, 4, 7, 1),
(31, 'Pedagogia', 1, 4, 7, 1),
(32, 'Artes Visuais', 1, 4, 7, 1),
(33, 'Secretariado Executivo', 2, 4, 5, 1),
(34, 'Letras - Português', 1, 5, 7, 1),
(35, 'Letras - Português e Espanhol', 1, 5, 7, 1),
(36, 'Letras - Português e Francês', 1, 5, 7, 1),
(37, 'Letras - Português e Inglês', 1, 5, 7, 1),
(38, 'Química', 1, 6, 9, 1);

INSERT INTO `tb_cursos` (`id`, `curso`, `tipo_curso_id`) VALUES
(1, 'Agroecologia', 3),
(2, 'Agronomia', 2),
(3, 'Ciências Biológicas', 2),
(4, 'Ciências Biológicas', 1),
(5, 'Enfermagem', 2),
(6, 'Medicina', 2),
(7, 'Medicina Veterinária', 2),
(8, 'Zootecnia', 2),
(9, 'Arquitetura e Urbanismo', 2),
(10, 'Ciência da Computação', 2),
(11, 'Engenharia Civil', 2),
(12, 'Engenharia Elétrica', 2),
(13, 'Matemática', 2),
(14, 'Matemática', 1),
(15, 'Física', 1),
(16, 'Geologia', 2),
(17, 'Antropologia', 2),
(18, 'Ciências Sociais', 2),
(19, 'Relações Internacionais', 2),
(20, 'Direito', 2),
(21, 'História', 1),
(22, 'Geografia', 1),
(23, 'Geografia', 2),
(24, 'Administração', 2),
(25, 'Ciências Contábeis', 2),
(26, 'Ciências Econômicas', 2),
(27, 'Comunicação Social – Jornalismo', 2),
(28, 'Letras - Libras', 2),
(29, 'Psicologia', 2),
(30, 'Música', 1),
(31, 'Pedagogia', 1),
(32, 'Artes Visuais', 1),
(33, 'Secretariado Executivo', 2),
(34, 'Letras - Português', 1),
(35, 'Letras - Português e Espanhol', 1),
(36, 'Letras - Português e Francês', 1),
(37, 'Letras - Português e Inglês', 1),
(38, 'Química', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cursos_tipo`
--

CREATE TABLE `tb_cursos_tipo` (
  `id` int(10) UNSIGNED NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sigla` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_cursos_tipo`
--

INSERT INTO `tb_cursos_tipo` (`id`, `tipo`, `sigla`) VALUES
(1, 'Licenciatura', '(L)'),
(2, 'Bacharelado', '(B)'),
(3, 'Tecnologia', '(T)');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_disciplina`
--

CREATE TABLE `tb_disciplina` (
  `id` int(10) UNSIGNED NOT NULL,
  `disciplina` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area_id` int(11) DEFAULT NULL,
  `instituicao_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_disciplina`
--

INSERT INTO `tb_disciplina` (`id`, `disciplina`, `area_id`, `instituicao_id`) VALUES
(1, 'Biologia', NULL, 1),
(2, 'Física', NULL, 1),
(3, 'Geografia', NULL, 1),
(4, 'História', NULL, 1),
(5, 'Língua Estrangeira - Espanhol', NULL, 1),
(6, 'Matemática', NULL, 1),
(7, 'Língua Portuguesa', NULL, 1),
(8, 'Química', NULL, 1),
(9, 'Redação', NULL, 1),
(10, 'Língua Estrangeira - Inglês', NULL, 1),
(11, 'Língua Estrangeira - Francês', NULL, 1),
(12, 'Obras Literárias', NULL, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_edital`
--

CREATE TABLE `tb_edital` (
  `id` int(10) UNSIGNED NOT NULL,
  `descricao` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `edital` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instituicao_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ano` int(11) NOT NULL,
  `tipo_prova_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_edital`
--

INSERT INTO `tb_edital` (`id`, `descricao`, `edital`, `instituicao_id`, `ano`, `tipo_prova_id`, `site`, `created_at`, `updated_at`) VALUES
(1, 'Vestibular UFRR (2012)', 'Edital nº 086/2011', '1', 2012, '5', 'http://ufrr.br/cpv/index.php?option=com_phocadownload&view=category&id=47:vestibular-2012&Itemid=301', '2018-11-24 23:04:00', '0000-00-00 00:00:00'),
(2, 'Vestibular UFRR (2013)', 'Edital nº 020/2012', '1', 2013, '5', 'http://ufrr.br/cpv/index.php?option=com_phocadownload&view=category&id=48:vestibular-2013&Itemid=301', '2018-11-24 23:04:00', '0000-00-00 00:00:00'),
(3, 'Vestibular UFRR (2014)', 'Edital nº 040/2013', '1', 2014, '5', 'http://ufrr.br/cpv/index.php?option=com_phocadownload&view=category&id=56:vestibular-2014&Itemid=301', '2018-11-24 23:04:00', '0000-00-00 00:00:00'),
(4, 'Vestibular UFRR (2015)', 'Edital nº 025/2014', '1', 2015, '5', 'http://ufrr.br/cpv/index.php?option=com_phocadownload&view=category&id=67:vestibular-2015&Itemid=301', '2018-11-24 23:04:00', '0000-00-00 00:00:00'),
(5, 'Vestibular UFRR (2016)', 'Edital nº 014/2015', '1', 2016, '5', 'http://ufrr.br/cpv/index.php?option=com_phocadownload&view=category&id=75:vestibular-2016&Itemid=301', '2018-11-24 23:04:00', '0000-00-00 00:00:00'),
(6, 'Vestibular UFRR (2017)', 'Edital nº 021/2016', '1', 2017, '5', 'http://ufrr.br/cpv/index.php?option=com_phocadownload&view=category&id=85:vestibular-2017&Itemid=301', '2018-11-24 23:04:00', '0000-00-00 00:00:00'),
(7, 'Vestibular UFRR (2018)', 'Edital nº 018/2017', '1', 2018, '5', 'http://ufrr.br/cpv/index.php?option=com_phocadownload&view=category&id=91:vestibular-2018&Itemid=301', '2018-11-24 23:04:00', '0000-00-00 00:00:00'),
(8, 'Vestibular UFRR (2019)', 'Edital nº 011/2018', '1', 2019, '5', 'http://ufrr.br/cpv/index.php?option=com_phocadownload&view=category&id=101:vestibular-2019&Itemid=301', '2018-11-24 23:04:00', '0000-00-00 00:00:00'),
(10, 'Vestibular UFRR (2020)', 'Edital n. 015/2019', '1', 2020, '5', 'http://ufrr.br', '2018-11-27 06:19:35', '2018-11-28 03:58:25');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_gabarito`
--

CREATE TABLE `tb_gabarito` (
  `id` int(10) UNSIGNED NOT NULL,
  `numero_questao` int(11) NOT NULL,
  `alternativa_id` int(11) NOT NULL,
  `disciplina_id` int(11) NOT NULL,
  `tipo_prova_id` int(11) NOT NULL,
  `edital_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_gabarito`
--

INSERT INTO `tb_gabarito` (`id`, `numero_questao`, `alternativa_id`, `disciplina_id`, `tipo_prova_id`, `edital_id`) VALUES
(1, 1, 3, 7, 1, 6),
(2, 2, 2, 7, 1, 6),
(3, 3, 3, 7, 1, 6),
(4, 4, 1, 6, 1, 6),
(5, 5, 5, 6, 1, 6),
(6, 6, 3, 6, 1, 6),
(7, 7, 3, 1, 1, 6),
(8, 8, 2, 1, 1, 6),
(9, 9, 3, 1, 1, 6),
(10, 10, 1, 2, 1, 6),
(11, 11, 5, 2, 1, 6),
(12, 12, 2, 2, 1, 6),
(13, 13, 4, 3, 1, 6),
(14, 14, 1, 3, 1, 6),
(15, 15, 2, 3, 1, 6),
(16, 16, 2, 4, 1, 6),
(17, 17, 4, 4, 1, 6),
(18, 18, 4, 4, 1, 6),
(19, 19, 1, 8, 1, 6),
(20, 20, 4, 8, 1, 6),
(21, 21, 3, 8, 1, 6),
(22, 22, 4, 5, 1, 6),
(23, 23, 5, 5, 1, 6),
(24, 24, 1, 5, 1, 6),
(25, 22, 4, 10, 1, 6),
(26, 23, 5, 10, 1, 6),
(27, 24, 1, 10, 1, 6),
(28, 22, 4, 11, 1, 6),
(29, 23, 5, 11, 1, 6),
(30, 24, 1, 11, 1, 6),
(31, 1, 4, 7, 2, 6),
(32, 2, 5, 7, 2, 6),
(33, 3, 1, 7, 2, 6),
(34, 4, 4, 6, 2, 6),
(35, 5, 5, 6, 2, 6),
(36, 6, 4, 6, 2, 6),
(37, 7, 5, 1, 2, 6),
(38, 8, 3, 1, 2, 6),
(39, 9, 3, 1, 2, 6),
(40, 10, 3, 2, 2, 6),
(41, 11, 5, 2, 2, 6),
(42, 12, 1, 2, 2, 6),
(43, 13, 1, 3, 2, 6),
(44, 14, 6, 3, 2, 6),
(45, 15, 1, 3, 2, 6),
(46, 16, 4, 4, 2, 6),
(47, 17, 3, 4, 2, 6),
(48, 18, 5, 4, 2, 6),
(49, 19, 2, 8, 2, 6),
(50, 20, 3, 8, 2, 6),
(51, 21, 1, 8, 2, 6),
(52, 22, 4, 5, 2, 6),
(53, 23, 3, 5, 2, 6),
(54, 24, 5, 5, 2, 6),
(55, 22, 4, 10, 2, 6),
(56, 23, 3, 10, 2, 6),
(57, 24, 5, 10, 2, 6),
(58, 22, 4, 11, 2, 6),
(59, 23, 3, 11, 2, 6),
(60, 24, 5, 11, 2, 6),
(61, 1, 3, 7, 5, 6),
(62, 2, 2, 7, 5, 6),
(63, 3, 3, 7, 5, 6),
(64, 4, 4, 7, 5, 6),
(65, 5, 5, 7, 5, 6),
(66, 6, 1, 7, 5, 6),
(67, 7, 6, 7, 5, 6),
(68, 8, 5, 7, 5, 6),
(69, 9, 4, 7, 5, 6),
(70, 10, 1, 6, 5, 6),
(71, 11, 5, 6, 5, 6),
(72, 12, 3, 6, 5, 6),
(73, 13, 4, 6, 5, 6),
(74, 14, 5, 6, 5, 6),
(75, 15, 4, 6, 5, 6),
(76, 16, 1, 6, 5, 6),
(77, 17, 2, 6, 5, 6),
(78, 18, 2, 6, 5, 6),
(79, 19, 3, 1, 5, 6),
(80, 20, 2, 1, 5, 6),
(81, 21, 3, 1, 5, 6),
(82, 22, 5, 1, 5, 6),
(83, 23, 3, 1, 5, 6),
(84, 24, 3, 1, 5, 6),
(85, 25, 4, 1, 5, 6),
(86, 26, 5, 1, 5, 6),
(87, 27, 1, 1, 5, 6),
(88, 28, 1, 2, 5, 6),
(89, 29, 5, 2, 5, 6),
(90, 30, 2, 2, 5, 6),
(91, 31, 3, 2, 5, 6),
(92, 32, 5, 2, 5, 6),
(93, 33, 1, 2, 5, 6),
(94, 34, 4, 2, 5, 6),
(95, 35, 2, 2, 5, 6),
(96, 36, 2, 2, 5, 6),
(97, 37, 4, 3, 5, 6),
(98, 38, 1, 3, 5, 6),
(99, 39, 2, 3, 5, 6),
(100, 40, 1, 3, 5, 6),
(101, 41, 6, 3, 5, 6),
(102, 42, 1, 3, 5, 6),
(103, 43, 5, 3, 5, 6),
(104, 44, 3, 3, 5, 6),
(105, 45, 5, 3, 5, 6),
(106, 46, 2, 4, 5, 6),
(107, 47, 4, 4, 5, 6),
(108, 48, 4, 4, 5, 6),
(109, 49, 4, 4, 5, 6),
(110, 50, 3, 4, 5, 6),
(111, 51, 5, 4, 5, 6),
(112, 52, 2, 4, 5, 6),
(113, 53, 5, 4, 5, 6),
(114, 55, 1, 8, 5, 6),
(115, 56, 4, 8, 5, 6),
(116, 57, 3, 8, 5, 6),
(117, 58, 2, 8, 5, 6),
(118, 59, 3, 8, 5, 6),
(119, 60, 1, 8, 5, 6),
(120, 61, 4, 8, 5, 6),
(121, 62, 5, 8, 5, 6),
(122, 63, 2, 8, 5, 6),
(123, 64, 4, 5, 5, 6),
(124, 65, 5, 5, 5, 6),
(125, 66, 1, 5, 5, 6),
(126, 67, 4, 5, 5, 6),
(127, 68, 3, 5, 5, 6),
(128, 69, 5, 5, 5, 6),
(129, 70, 1, 5, 5, 6),
(130, 71, 2, 5, 5, 6),
(131, 72, 2, 5, 5, 6),
(132, 64, 4, 10, 5, 6),
(133, 65, 5, 10, 5, 6),
(134, 66, 1, 10, 5, 6),
(135, 67, 4, 10, 5, 6),
(136, 68, 3, 10, 5, 6),
(137, 69, 5, 10, 5, 6),
(138, 70, 1, 10, 5, 6),
(139, 71, 2, 10, 5, 6),
(140, 72, 2, 10, 5, 6),
(141, 64, 4, 11, 5, 6),
(142, 65, 5, 11, 5, 6),
(143, 66, 1, 11, 5, 6),
(144, 67, 4, 11, 5, 6),
(145, 68, 3, 11, 5, 6),
(146, 69, 5, 11, 5, 6),
(147, 70, 1, 11, 5, 6),
(148, 71, 2, 11, 5, 6),
(149, 72, 2, 11, 5, 6),
(150, 1, 5, 7, 1, 5),
(151, 2, 1, 7, 1, 5),
(152, 3, 4, 7, 1, 5),
(153, 4, 4, 6, 1, 5),
(154, 5, 6, 6, 1, 5),
(155, 6, 2, 6, 1, 5),
(156, 7, 4, 1, 1, 5),
(157, 8, 5, 1, 1, 5),
(158, 9, 6, 1, 1, 5),
(159, 10, 6, 2, 1, 5),
(160, 11, 1, 2, 1, 5),
(161, 12, 3, 2, 1, 5),
(162, 13, 3, 3, 1, 5),
(163, 14, 5, 3, 1, 5),
(164, 15, 5, 3, 1, 5),
(165, 16, 1, 4, 1, 5),
(166, 17, 4, 4, 1, 5),
(167, 18, 4, 4, 1, 5),
(168, 19, 3, 8, 1, 5),
(169, 20, 2, 8, 1, 5),
(170, 21, 2, 8, 1, 5),
(171, 22, 4, 5, 1, 5),
(172, 23, 3, 5, 1, 5),
(173, 24, 1, 5, 1, 5),
(174, 22, 4, 10, 1, 5),
(175, 23, 3, 10, 1, 5),
(176, 24, 1, 10, 1, 5),
(177, 22, 4, 11, 1, 5),
(178, 23, 3, 11, 1, 5),
(179, 24, 1, 11, 1, 5),
(180, 1, 4, 7, 2, 5),
(181, 2, 3, 7, 2, 5),
(182, 3, 1, 7, 2, 5),
(183, 4, 5, 6, 2, 5),
(184, 5, 6, 6, 2, 5),
(185, 6, 4, 6, 2, 5),
(186, 7, 1, 1, 2, 5),
(187, 8, 2, 1, 2, 5),
(188, 9, 2, 1, 2, 5),
(189, 10, 1, 2, 2, 5),
(190, 11, 3, 2, 2, 5),
(191, 12, 5, 2, 2, 5),
(192, 13, 4, 3, 2, 5),
(193, 14, 1, 3, 2, 5),
(194, 15, 4, 3, 2, 5),
(195, 16, 5, 4, 2, 5),
(196, 17, 2, 4, 2, 5),
(197, 18, 1, 4, 2, 5),
(198, 19, 4, 8, 2, 5),
(199, 20, 3, 8, 2, 5),
(200, 21, 5, 8, 2, 5),
(201, 22, 5, 5, 2, 5),
(202, 23, 2, 5, 2, 5),
(203, 24, 6, 5, 2, 5),
(204, 22, 5, 10, 2, 5),
(205, 23, 2, 10, 2, 5),
(206, 24, 6, 10, 2, 5),
(207, 22, 5, 11, 2, 5),
(208, 23, 2, 11, 2, 5),
(209, 24, 3, 11, 2, 5),
(210, 1, 3, 7, 5, 5),
(211, 2, 4, 7, 5, 5),
(212, 3, 1, 7, 5, 5),
(213, 4, 5, 7, 5, 5),
(214, 5, 1, 7, 5, 5),
(215, 6, 1, 7, 5, 5),
(216, 7, 2, 7, 5, 5),
(217, 8, 4, 7, 5, 5),
(218, 9, 4, 7, 5, 5),
(219, 10, 3, 6, 5, 5),
(220, 11, 6, 6, 5, 5),
(221, 12, 2, 6, 5, 5),
(222, 13, 2, 6, 5, 5),
(223, 14, 6, 6, 5, 5),
(224, 15, 3, 6, 5, 5),
(225, 16, 5, 6, 5, 5),
(226, 17, 3, 6, 5, 5),
(227, 18, 1, 6, 5, 5),
(228, 19, 1, 1, 5, 5),
(229, 20, 3, 1, 5, 5),
(230, 21, 6, 1, 5, 5),
(231, 22, 1, 1, 5, 5),
(232, 23, 5, 1, 5, 5),
(233, 24, 5, 1, 5, 5),
(234, 25, 2, 1, 5, 5),
(235, 26, 3, 1, 5, 5),
(236, 27, 2, 1, 5, 5),
(237, 28, 6, 2, 5, 5),
(238, 29, 3, 2, 5, 5),
(239, 30, 4, 2, 5, 5),
(240, 31, 4, 2, 5, 5),
(241, 32, 3, 2, 5, 5),
(242, 33, 5, 2, 5, 5),
(243, 34, 2, 2, 5, 5),
(244, 35, 1, 2, 5, 5),
(245, 36, 1, 2, 5, 5),
(246, 37, 3, 3, 5, 5),
(247, 38, 5, 3, 5, 5),
(248, 39, 5, 3, 5, 5),
(249, 40, 1, 3, 5, 5),
(250, 41, 5, 3, 5, 5),
(251, 42, 2, 3, 5, 5),
(252, 43, 2, 3, 5, 5),
(253, 44, 1, 3, 5, 5),
(254, 45, 3, 3, 5, 5),
(255, 46, 3, 4, 5, 5),
(256, 47, 1, 4, 5, 5),
(257, 48, 5, 4, 5, 5),
(258, 49, 4, 4, 5, 5),
(259, 50, 4, 4, 5, 5),
(260, 51, 4, 4, 5, 5),
(261, 52, 1, 4, 5, 5),
(262, 53, 1, 4, 5, 5),
(263, 54, 5, 4, 5, 5),
(264, 55, 3, 8, 5, 5),
(265, 56, 2, 8, 5, 5),
(266, 57, 2, 8, 5, 5),
(267, 58, 4, 8, 5, 5),
(268, 59, 4, 8, 5, 5),
(269, 60, 1, 8, 5, 5),
(270, 61, 6, 8, 5, 5),
(271, 62, 4, 8, 5, 5),
(272, 63, 6, 8, 5, 5),
(273, 64, 3, 5, 5, 5),
(274, 65, 1, 5, 5, 5),
(275, 66, 5, 5, 5, 5),
(276, 67, 1, 5, 5, 5),
(277, 68, 4, 5, 5, 5),
(278, 69, 6, 5, 5, 5),
(279, 70, 2, 5, 5, 5),
(280, 71, 5, 5, 5, 5),
(281, 72, 1, 5, 5, 5),
(282, 64, 3, 10, 5, 5),
(283, 65, 1, 10, 5, 5),
(284, 66, 5, 10, 5, 5),
(285, 67, 1, 10, 5, 5),
(286, 68, 4, 10, 5, 5),
(287, 69, 3, 10, 5, 5),
(288, 70, 2, 10, 5, 5),
(289, 71, 5, 10, 5, 5),
(290, 72, 1, 10, 5, 5),
(291, 64, 3, 11, 5, 5),
(292, 65, 1, 11, 5, 5),
(293, 66, 5, 11, 5, 5),
(294, 67, 1, 11, 5, 5),
(295, 68, 4, 11, 5, 5),
(296, 69, 3, 11, 5, 5),
(297, 70, 2, 11, 5, 5),
(298, 71, 5, 11, 5, 5),
(299, 72, 1, 11, 5, 5),
(300, 1, 2, 7, 1, 4),
(301, 2, 4, 7, 1, 4),
(302, 3, 3, 7, 1, 4),
(303, 4, 4, 6, 1, 4),
(304, 5, 1, 6, 1, 4),
(305, 6, 6, 6, 1, 4),
(306, 7, 5, 1, 1, 4),
(307, 8, 5, 1, 1, 4),
(308, 9, 1, 1, 1, 4),
(309, 10, 1, 2, 1, 4),
(310, 11, 6, 2, 1, 4),
(311, 12, 2, 2, 1, 4),
(312, 13, 3, 3, 1, 4),
(313, 14, 2, 3, 1, 4),
(314, 15, 6, 3, 1, 4),
(315, 16, 3, 4, 1, 4),
(316, 17, 1, 4, 1, 4),
(317, 18, 4, 4, 1, 4),
(318, 19, 3, 8, 1, 4),
(319, 20, 3, 8, 1, 4),
(320, 21, 5, 8, 1, 4),
(321, 22, 2, 5, 1, 4),
(322, 23, 4, 5, 1, 4),
(323, 24, 5, 5, 1, 4),
(324, 22, 2, 10, 1, 4),
(325, 23, 4, 10, 1, 4),
(326, 24, 5, 10, 1, 4),
(327, 22, 2, 11, 1, 4),
(328, 23, 4, 11, 1, 4),
(329, 24, 4, 11, 1, 4),
(330, 1, 5, 7, 2, 4),
(331, 2, 1, 7, 2, 4),
(332, 3, 2, 7, 2, 4),
(333, 4, 1, 6, 2, 4),
(334, 5, 3, 6, 2, 4),
(335, 6, 2, 6, 2, 4),
(336, 7, 1, 1, 2, 4),
(337, 8, 2, 1, 2, 4),
(338, 9, 4, 1, 2, 4),
(339, 10, 3, 2, 2, 4),
(340, 11, 5, 2, 2, 4),
(341, 12, 4, 2, 2, 4),
(342, 13, 5, 3, 2, 4),
(343, 14, 2, 3, 2, 4),
(344, 15, 1, 3, 2, 4),
(345, 16, 3, 4, 2, 4),
(346, 17, 4, 4, 2, 4),
(347, 18, 4, 4, 2, 4),
(348, 19, 5, 8, 2, 4),
(349, 20, 4, 8, 2, 4),
(350, 21, 3, 8, 2, 4),
(351, 22, 3, 5, 2, 4),
(352, 23, 2, 5, 2, 4),
(353, 24, 1, 5, 2, 4),
(354, 22, 3, 10, 2, 4),
(355, 23, 2, 10, 2, 4),
(356, 24, 1, 10, 2, 4),
(357, 22, 3, 11, 2, 4),
(358, 23, 2, 11, 2, 4),
(359, 24, 1, 11, 2, 4),
(360, 1, 3, 7, 5, 4),
(361, 2, 5, 7, 5, 4),
(362, 3, 2, 7, 5, 4),
(363, 4, 2, 7, 5, 4),
(364, 5, 4, 7, 5, 4),
(365, 6, 1, 7, 5, 4),
(366, 7, 6, 7, 5, 4),
(367, 8, 5, 7, 5, 4),
(368, 9, 5, 7, 5, 4),
(369, 10, 1, 6, 5, 4),
(370, 11, 5, 6, 5, 4),
(371, 12, 6, 6, 5, 4),
(372, 13, 1, 6, 5, 4),
(373, 14, 2, 6, 5, 4),
(374, 15, 3, 6, 5, 4),
(375, 16, 1, 6, 5, 4),
(376, 17, 4, 6, 5, 4),
(377, 18, 2, 6, 5, 4),
(378, 19, 5, 1, 5, 4),
(379, 20, 5, 1, 5, 4),
(380, 21, 2, 1, 5, 4),
(381, 22, 4, 1, 5, 4),
(382, 23, 5, 1, 5, 4),
(383, 24, 3, 1, 5, 4),
(384, 25, 1, 1, 5, 4),
(385, 26, 1, 1, 5, 4),
(386, 27, 4, 1, 5, 4),
(387, 28, 6, 2, 5, 4),
(388, 29, 5, 2, 5, 4),
(389, 30, 3, 2, 5, 4),
(390, 31, 3, 2, 5, 4),
(391, 32, 5, 2, 5, 4),
(392, 33, 2, 2, 5, 4),
(393, 34, 2, 2, 5, 4),
(394, 35, 1, 2, 5, 4),
(395, 36, 4, 2, 5, 4),
(396, 37, 5, 3, 5, 4),
(397, 38, 1, 3, 5, 4),
(398, 39, 1, 3, 5, 4),
(399, 40, 4, 3, 5, 4),
(400, 41, 1, 3, 5, 4),
(401, 42, 3, 3, 5, 4),
(402, 43, 5, 3, 5, 4),
(403, 44, 2, 3, 5, 4),
(404, 45, 3, 3, 5, 4),
(405, 46, 1, 4, 5, 4),
(406, 47, 3, 4, 5, 4),
(407, 48, 2, 4, 5, 4),
(408, 49, 2, 4, 5, 4),
(409, 50, 1, 4, 5, 4),
(410, 51, 5, 4, 5, 4),
(411, 52, 3, 4, 5, 4),
(412, 53, 5, 4, 5, 4),
(413, 54, 1, 4, 5, 4),
(414, 55, 2, 8, 5, 4),
(415, 56, 2, 8, 5, 4),
(416, 57, 4, 8, 5, 4),
(417, 58, 5, 8, 5, 4),
(418, 59, 5, 8, 5, 4),
(419, 60, 3, 8, 5, 4),
(420, 61, 2, 8, 5, 4),
(421, 62, 4, 8, 5, 4),
(422, 63, 1, 8, 5, 4),
(423, 64, 5, 5, 5, 4),
(424, 65, 3, 5, 5, 4),
(425, 66, 1, 5, 5, 4),
(426, 67, 4, 5, 5, 4),
(427, 68, 2, 5, 5, 4),
(428, 69, 5, 5, 5, 4),
(429, 70, 1, 5, 5, 4),
(430, 71, 5, 5, 5, 4),
(431, 72, 3, 5, 5, 4),
(432, 64, 5, 10, 5, 4),
(433, 65, 3, 10, 5, 4),
(434, 66, 1, 10, 5, 4),
(435, 67, 4, 10, 5, 4),
(436, 68, 2, 10, 5, 4),
(437, 69, 5, 10, 5, 4),
(438, 70, 1, 10, 5, 4),
(439, 71, 5, 10, 5, 4),
(440, 72, 3, 10, 5, 4),
(441, 64, 5, 11, 5, 4),
(442, 65, 3, 11, 5, 4),
(443, 66, 4, 11, 5, 4),
(444, 67, 4, 11, 5, 4),
(445, 68, 2, 11, 5, 4),
(446, 69, 5, 11, 5, 4),
(447, 70, 1, 11, 5, 4),
(448, 71, 5, 11, 5, 4),
(449, 72, 3, 11, 5, 4),
(450, 1, 2, 7, 1, 3),
(451, 2, 4, 7, 1, 3),
(452, 3, 5, 7, 1, 3),
(453, 4, 5, 6, 1, 3),
(454, 5, 4, 6, 1, 3),
(455, 6, 3, 6, 1, 3),
(456, 7, 4, 1, 1, 3),
(457, 8, 2, 1, 1, 3),
(458, 9, 3, 1, 1, 3),
(459, 10, 6, 2, 1, 3),
(460, 11, 3, 2, 1, 3),
(461, 12, 4, 2, 1, 3),
(462, 13, 5, 3, 1, 3),
(463, 14, 1, 3, 1, 3),
(464, 15, 3, 3, 1, 3),
(465, 16, 3, 4, 1, 3),
(466, 17, 1, 4, 1, 3),
(467, 18, 4, 4, 1, 3),
(468, 19, 5, 8, 1, 3),
(469, 20, 4, 8, 1, 3),
(470, 21, 2, 8, 1, 3),
(471, 22, 1, 5, 1, 3),
(472, 23, 3, 5, 1, 3),
(473, 24, 2, 5, 1, 3),
(474, 22, 1, 10, 1, 3),
(475, 23, 3, 10, 1, 3),
(476, 24, 2, 10, 1, 3),
(477, 1, 3, 7, 2, 3),
(478, 2, 1, 7, 2, 3),
(479, 3, 3, 7, 2, 3),
(480, 4, 1, 6, 2, 3),
(481, 5, 6, 6, 2, 3),
(482, 6, 4, 6, 2, 3),
(483, 7, 1, 1, 2, 3),
(484, 8, 4, 1, 2, 3),
(485, 9, 2, 1, 2, 3),
(486, 10, 2, 2, 2, 3),
(487, 11, 3, 2, 2, 3),
(488, 12, 5, 2, 2, 3),
(489, 13, 2, 3, 2, 3),
(490, 14, 4, 3, 2, 3),
(491, 15, 1, 3, 2, 3),
(492, 16, 2, 4, 2, 3),
(493, 17, 1, 4, 2, 3),
(494, 18, 2, 4, 2, 3),
(495, 19, 4, 8, 2, 3),
(496, 20, 5, 8, 2, 3),
(497, 21, 3, 8, 2, 3),
(498, 22, 4, 5, 2, 3),
(499, 23, 5, 5, 2, 3),
(500, 24, 1, 5, 2, 3),
(501, 22, 4, 10, 2, 3),
(502, 23, 5, 10, 2, 3),
(503, 24, 1, 10, 2, 3),
(504, 1, 2, 7, 5, 3),
(505, 2, 4, 7, 5, 3),
(506, 3, 5, 7, 5, 3),
(507, 4, 3, 7, 5, 3),
(508, 5, 1, 7, 5, 3),
(509, 6, 3, 7, 5, 3),
(510, 7, 4, 7, 5, 3),
(511, 8, 5, 7, 5, 3),
(512, 9, 2, 7, 5, 3),
(513, 10, 5, 6, 5, 3),
(514, 11, 4, 6, 5, 3),
(515, 12, 3, 6, 5, 3),
(516, 13, 1, 6, 5, 3),
(517, 14, 6, 6, 5, 3),
(518, 15, 4, 6, 5, 3),
(519, 16, 1, 6, 5, 3),
(520, 17, 1, 6, 5, 3),
(521, 18, 5, 6, 5, 3),
(522, 19, 4, 1, 5, 3),
(523, 20, 2, 1, 5, 3),
(524, 21, 3, 1, 5, 3),
(525, 22, 4, 1, 5, 3),
(526, 23, 2, 1, 5, 3),
(527, 24, 1, 1, 5, 3),
(528, 25, 5, 1, 5, 3),
(529, 26, 2, 1, 5, 3),
(530, 27, 6, 1, 5, 3),
(531, 28, 6, 2, 5, 3),
(532, 29, 3, 2, 5, 3),
(533, 30, 4, 2, 5, 3),
(534, 31, 2, 2, 5, 3),
(535, 32, 5, 2, 5, 3),
(536, 33, 3, 2, 5, 3),
(537, 34, 1, 2, 5, 3),
(538, 35, 2, 2, 5, 3),
(539, 36, 6, 2, 5, 3),
(540, 37, 5, 3, 5, 3),
(541, 38, 1, 3, 5, 3),
(542, 39, 3, 3, 5, 3),
(543, 40, 2, 3, 5, 3),
(544, 41, 4, 3, 5, 3),
(545, 42, 1, 3, 5, 3),
(546, 43, 3, 3, 5, 3),
(547, 44, 3, 3, 5, 3),
(548, 45, 5, 3, 5, 3),
(549, 46, 3, 4, 5, 3),
(550, 47, 1, 4, 5, 3),
(551, 48, 4, 4, 5, 3),
(552, 49, 2, 4, 5, 3),
(553, 50, 2, 4, 5, 3),
(554, 51, 1, 4, 5, 3),
(555, 52, 4, 4, 5, 3),
(556, 53, 5, 4, 5, 3),
(557, 55, 5, 8, 5, 3),
(558, 56, 4, 8, 5, 3),
(559, 57, 2, 8, 5, 3),
(560, 58, 4, 8, 5, 3),
(561, 59, 5, 8, 5, 3),
(562, 60, 3, 8, 5, 3),
(563, 61, 5, 8, 5, 3),
(564, 62, 2, 8, 5, 3),
(565, 63, 6, 8, 5, 3),
(566, 64, 1, 5, 5, 3),
(567, 65, 3, 5, 5, 3),
(568, 66, 2, 5, 5, 3),
(569, 67, 4, 5, 5, 3),
(570, 68, 5, 5, 5, 3),
(571, 69, 1, 5, 5, 3),
(572, 70, 6, 5, 5, 3),
(573, 71, 5, 5, 5, 3),
(574, 72, 2, 5, 5, 3),
(575, 64, 1, 10, 5, 3),
(576, 65, 3, 10, 5, 3),
(577, 66, 2, 10, 5, 3),
(578, 67, 4, 10, 5, 3),
(579, 68, 5, 10, 5, 3),
(580, 69, 1, 10, 5, 3),
(581, 70, 4, 10, 5, 3),
(582, 71, 5, 10, 5, 3),
(583, 72, 2, 10, 5, 3),
(584, 1, 4, 7, 1, 2),
(585, 2, 3, 7, 1, 2),
(586, 3, 4, 7, 1, 2),
(587, 4, 2, 6, 1, 2),
(588, 5, 3, 6, 1, 2),
(589, 6, 4, 6, 1, 2),
(590, 7, 4, 1, 1, 2),
(591, 8, 2, 1, 1, 2),
(592, 9, 3, 1, 1, 2),
(593, 10, 5, 2, 1, 2),
(594, 11, 1, 2, 1, 2),
(595, 12, 3, 2, 1, 2),
(596, 13, 1, 3, 1, 2),
(597, 14, 5, 3, 1, 2),
(598, 15, 3, 3, 1, 2),
(599, 16, 2, 4, 1, 2),
(600, 17, 1, 4, 1, 2),
(601, 18, 2, 4, 1, 2),
(602, 19, 3, 8, 1, 2),
(603, 20, 5, 8, 1, 2),
(604, 21, 6, 8, 1, 2),
(605, 22, 5, 10, 1, 2),
(606, 23, 4, 10, 1, 2),
(607, 24, 1, 10, 1, 2),
(608, 22, 5, 11, 1, 2),
(609, 23, 4, 11, 1, 2),
(610, 24, 1, 11, 1, 2),
(611, 22, 5, 5, 1, 2),
(612, 23, 6, 5, 1, 2),
(613, 24, 1, 5, 1, 2),
(614, 1, 3, 7, 2, 2),
(615, 2, 4, 7, 2, 2),
(616, 3, 3, 7, 2, 2),
(617, 4, 4, 6, 2, 2),
(618, 5, 5, 6, 2, 2),
(619, 6, 2, 6, 2, 2),
(620, 7, 4, 1, 2, 2),
(621, 8, 3, 1, 2, 2),
(622, 9, 2, 1, 2, 2),
(623, 10, 1, 2, 2, 2),
(624, 11, 4, 2, 2, 2),
(625, 12, 5, 2, 2, 2),
(626, 13, 5, 3, 2, 2),
(627, 14, 1, 3, 2, 2),
(628, 15, 2, 3, 2, 2),
(629, 16, 4, 4, 2, 2),
(630, 17, 3, 4, 2, 2),
(631, 18, 5, 4, 2, 2),
(632, 19, 2, 8, 2, 2),
(633, 20, 1, 8, 2, 2),
(634, 21, 3, 8, 2, 2),
(635, 22, 4, 5, 2, 2),
(636, 23, 2, 5, 2, 2),
(637, 24, 2, 5, 2, 2),
(638, 22, 4, 10, 2, 2),
(639, 23, 2, 10, 2, 2),
(640, 24, 2, 10, 2, 2),
(641, 22, 4, 11, 2, 2),
(642, 23, 2, 11, 2, 2),
(643, 24, 2, 11, 2, 2),
(644, 1, 4, 7, 5, 2),
(645, 2, 3, 7, 5, 2),
(646, 3, 4, 7, 5, 2),
(647, 4, 3, 7, 5, 2),
(648, 5, 4, 7, 5, 2),
(649, 6, 3, 7, 5, 2),
(650, 7, 1, 7, 5, 2),
(651, 8, 5, 7, 5, 2),
(652, 9, 1, 7, 5, 2),
(653, 10, 2, 6, 5, 2),
(654, 11, 3, 6, 5, 2),
(655, 12, 4, 6, 5, 2),
(656, 13, 4, 6, 5, 2),
(657, 14, 5, 6, 5, 2),
(658, 15, 2, 6, 5, 2),
(659, 16, 3, 6, 5, 2),
(660, 17, 2, 6, 5, 2),
(661, 18, 6, 6, 5, 2),
(662, 19, 4, 1, 5, 2),
(663, 20, 2, 1, 5, 2),
(664, 21, 3, 1, 5, 2),
(665, 22, 4, 1, 5, 2),
(666, 23, 3, 1, 5, 2),
(667, 24, 2, 1, 5, 2),
(668, 25, 1, 1, 5, 2),
(669, 26, 1, 1, 5, 2),
(670, 27, 2, 1, 5, 2),
(671, 28, 5, 2, 5, 2),
(672, 29, 1, 2, 5, 2),
(673, 30, 3, 2, 5, 2),
(674, 31, 1, 2, 5, 2),
(675, 32, 4, 2, 5, 2),
(676, 33, 5, 2, 5, 2),
(677, 34, 3, 2, 5, 2),
(678, 35, 4, 2, 5, 2),
(679, 36, 1, 2, 5, 2),
(680, 37, 1, 3, 5, 2),
(681, 38, 5, 3, 5, 2),
(682, 39, 3, 3, 5, 2),
(683, 40, 5, 3, 5, 2),
(684, 41, 1, 3, 5, 2),
(685, 42, 3, 3, 5, 2),
(686, 43, 2, 3, 5, 2),
(687, 44, 5, 3, 5, 2),
(688, 45, 3, 3, 5, 2),
(689, 46, 2, 4, 5, 2),
(690, 47, 1, 4, 5, 2),
(691, 48, 2, 4, 5, 2),
(692, 49, 4, 4, 5, 2),
(693, 50, 3, 4, 5, 2),
(694, 51, 5, 4, 5, 2),
(695, 52, 4, 4, 5, 2),
(696, 53, 1, 4, 5, 2),
(697, 54, 5, 4, 5, 2),
(698, 55, 3, 8, 5, 2),
(699, 56, 5, 8, 5, 2),
(700, 57, 6, 8, 5, 2),
(701, 58, 2, 8, 5, 2),
(702, 59, 1, 8, 5, 2),
(703, 60, 3, 8, 5, 2),
(704, 61, 3, 8, 5, 2),
(705, 62, 1, 8, 5, 2),
(706, 63, 2, 8, 5, 2),
(707, 64, 5, 10, 5, 2),
(708, 65, 4, 10, 5, 2),
(709, 66, 1, 10, 5, 2),
(710, 67, 4, 10, 5, 2),
(711, 68, 2, 10, 5, 2),
(712, 69, 2, 10, 5, 2),
(713, 70, 3, 10, 5, 2),
(714, 71, 4, 10, 5, 2),
(715, 72, 1, 10, 5, 2),
(716, 64, 5, 11, 5, 2),
(717, 65, 4, 11, 5, 2),
(718, 66, 1, 11, 5, 2),
(719, 67, 4, 11, 5, 2),
(720, 68, 2, 11, 5, 2),
(721, 69, 2, 11, 5, 2),
(722, 70, 3, 11, 5, 2),
(723, 71, 4, 11, 5, 2),
(724, 72, 1, 11, 5, 2),
(725, 64, 5, 5, 5, 2),
(726, 65, 6, 5, 5, 2),
(727, 66, 1, 5, 5, 2),
(728, 67, 4, 5, 5, 2),
(729, 68, 2, 5, 5, 2),
(730, 69, 2, 5, 5, 2),
(731, 70, 1, 5, 5, 2),
(732, 71, 4, 5, 5, 2),
(733, 72, 5, 5, 5, 2),
(734, 1, 5, 7, 1, 1),
(735, 2, 1, 7, 1, 1),
(736, 3, 2, 7, 1, 1),
(737, 4, 4, 6, 1, 1),
(738, 5, 3, 6, 1, 1),
(739, 6, 5, 6, 1, 1),
(740, 7, 4, 1, 1, 1),
(741, 8, 5, 1, 1, 1),
(742, 9, 2, 1, 1, 1),
(743, 10, 3, 2, 1, 1),
(744, 11, 4, 2, 1, 1),
(745, 12, 1, 2, 1, 1),
(746, 13, 4, 3, 1, 1),
(747, 14, 3, 3, 1, 1),
(748, 15, 5, 3, 1, 1),
(749, 16, 6, 4, 1, 1),
(750, 17, 4, 4, 1, 1),
(751, 18, 2, 4, 1, 1),
(752, 19, 5, 8, 1, 1),
(753, 20, 2, 8, 1, 1),
(754, 21, 4, 8, 1, 1),
(755, 22, 3, 5, 1, 1),
(756, 23, 1, 5, 1, 1),
(757, 24, 4, 5, 1, 1),
(758, 22, 3, 10, 1, 1),
(759, 23, 1, 10, 1, 1),
(760, 24, 4, 10, 1, 1),
(761, 22, 3, 11, 1, 1),
(762, 23, 1, 11, 1, 1),
(763, 24, 4, 11, 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_instituicao`
--

CREATE TABLE `tb_instituicao` (
  `id` int(10) UNSIGNED NOT NULL,
  `instituicao` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_comissao_vestibular` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_instituicao`
--

INSERT INTO `tb_instituicao` (`id`, `instituicao`, `site`, `site_comissao_vestibular`) VALUES
(1, 'UFRR', 'http://ufrr.br/', 'http://ufrr.br/cpv/'),
(2, 'UERR', 'https://www.uerr.edu.br/', 'https://cpc.uerr.edu.br/');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_resultado_final`
--

CREATE TABLE `tb_resultado_final` (
  `id` int(10) UNSIGNED NOT NULL,
  `ordem` int(11) NOT NULL,
  `inscricao` int(11) NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetiva` double(8,2) NOT NULL,
  `especificas` double(8,2) DEFAULT NULL,
  `redacao` double(8,2) NOT NULL,
  `total` double(8,2) NOT NULL,
  `situacao` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ano` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cota_id` int(11) DEFAULT NULL,
  `curso_id` int(11) NOT NULL,
  `edital_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_resultado_final`
--

INSERT INTO `tb_resultado_final` (`id`, `ordem`, `inscricao`, `nome`, `objetiva`, `especificas`, `redacao`, `total`, `situacao`, `ano`, `cota_id`, `curso_id`, `edital_id`) VALUES
(1, 1, 236540, 'ISABELA AVILA MALBURG', 96.00, 48.00, 28.50, 124.50, 'APROVADO', '2018', 2, 6, 7),
(2, 2, 232073, 'LUIZ AUGUSTO DE ARAUJO PEREIRA JUNIOR', 98.00, 48.00, 25.50, 123.50, 'APROVADO', '2018', 2, 6, 7),
(3, 3, 221006, 'LETÍCIA LINS FREIRE DE OLIVEIRA', 101.00, 51.00, 21.00, 122.00, 'APROVADO', '2018', 2, 6, 7),
(4, 4, 219932, 'LAURA RICARTE BESERRA AMANCIO', 94.00, 51.00, 27.50, 121.50, 'APROVADO', '2018', 2, 6, 7),
(5, 5, 219421, 'ANA CECILIA MARQUES DE LUNA', 97.00, 48.00, 24.00, 121.00, 'APROVADO', '2018', 2, 6, 7),
(6, 6, 219076, 'ISABELLE PEREIRA DE ARAÚJO', 96.00, 51.00, 24.50, 120.50, 'APROVADO', '2018', 2, 6, 7),
(7, 7, 218929, 'JUAN PASTANA ALVES', 91.00, 48.00, 29.50, 120.50, 'APROVADO', '2018', 2, 6, 7),
(8, 8, 227559, 'LEONARDO MATOS SANTOS', 98.00, 48.00, 22.50, 120.50, 'APROVADO', '2018', 2, 6, 7),
(9, 9, 230040, 'KAYLA NUNES PAIVA', 93.00, 48.00, 27.00, 120.00, 'APROVADO', '2018', 2, 6, 7),
(10, 10, 229704, 'ALLAELSON DOS SANTOS DE MORAIS', 95.00, 51.00, 24.50, 119.50, 'APROVADO', '2018', 2, 6, 7),
(11, 11, 221423, 'BRENO OLIVEIRA GOUVEIA', 92.00, 45.00, 27.50, 119.50, 'APROVADO', '2018', 2, 6, 7),
(12, 12, 230557, 'LORENA MARTINS SAMPAIO', 91.00, 45.00, 28.00, 119.00, 'APROVADO', '2018', 2, 6, 7),
(13, 13, 231004, 'RODRIGO FERREIRA OLIVEIRA', 89.00, 48.00, 29.50, 118.50, 'APROVADO', '2018', 2, 6, 7),
(14, 14, 227478, 'LIGIA REBECCA MOTA AMORIM', 93.00, 48.00, 25.00, 118.00, 'APROVADO', '2018', 2, 6, 7),
(15, 15, 230880, 'AUGUSTO MENDES FERREIRA', 96.00, 48.00, 22.00, 118.00, 'APROVADO', '2018', 2, 6, 7),
(16, 16, 220473, 'DANDARA MELO HONORATO', 89.00, 45.00, 29.00, 118.00, 'APROVADO', '2018', 2, 6, 7),
(17, 17, 227793, 'EULLER SERGIO MILEO DE OLIVEIRA JUNIOR', 89.00, 48.00, 28.50, 117.50, 'APROVADO', '2018', 2, 6, 7),
(18, 18, 234211, 'MELINDA MORENO MATOS', 89.00, 48.00, 28.50, 117.50, 'APROVADO', '2018', 2, 6, 7),
(19, 19, 230294, 'RAPHAEL DOS REIS MONTEIRO', 91.00, 48.00, 26.50, 117.50, 'APROVADO', '2018', 2, 6, 7),
(20, 20, 219561, 'CAROLINE BARBOSA MOURA', 93.00, 48.00, 24.50, 117.50, 'APROVADO', '2018', 2, 6, 7),
(21, 21, 220535, 'JOSE VICTOR SILVA DO VALE', 96.00, 51.00, 21.00, 117.00, 'APROVADO', '2018', 2, 6, 7),
(22, 22, 219129, 'THIAGO VINÍCIUS FERREIRA BESERRA', 100.00, 51.00, 16.50, 116.50, 'APROVADO', '2018', 2, 6, 7),
(23, 23, 234178, 'ANGELA SARAH GOMES SEVERIANO', 91.00, 48.00, 25.50, 116.50, 'APROVADO', '2018', 2, 6, 7),
(24, 24, 222938, 'LUCAS CARNEIRO', 90.00, 45.00, 26.00, 116.00, 'APROVADO', '2018', 2, 6, 7),
(25, 25, 218699, 'HENRIQUE MOREIRA BASTOS', 92.00, 51.00, 23.50, 115.50, 'APROVADO', '2018', 2, 6, 7),
(26, 26, 232006, 'RAFAELLA CARVALHO DE OLIVEIRA', 91.00, 48.00, 24.50, 115.50, 'APROVADO', '2018', 2, 6, 7),
(27, 27, 231237, 'NATAN CALIXTO COSTA', 89.00, 48.00, 26.00, 115.00, 'APROVADO', '2018', 2, 6, 7),
(28, 28, 218703, 'DIEGO GUILHERME SANTOS PORTELLA', 92.00, 48.00, 23.00, 115.00, 'APROVADO', '2018', 2, 6, 7),
(29, 29, 225398, 'GABRIELA MORAES GOMES', 95.00, 51.00, 19.50, 114.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(30, 30, 222385, 'WALDIR TEIXEIRA DA MATTA FLORA NETO', 91.00, 45.00, 23.50, 114.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(31, 31, 228659, 'ANDREZA AGUIAR XIMENES', 86.00, 42.00, 28.50, 114.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(32, 32, 222366, 'JÉSSICA VASCONCELOS OLIVETTO', 91.00, 42.00, 23.50, 114.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(33, 33, 218632, 'PEDRO EDUARDO ALVES DA SILVA', 93.00, 51.00, 21.00, 114.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(34, 34, 227675, 'WILLIANE LOPES SOARES COSTA', 88.00, 45.00, 26.00, 114.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(35, 35, 220896, 'LETÍCIA DE SOUSA VALE', 87.00, 42.00, 27.00, 114.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(36, 36, 221523, 'THAYNÁ MARIA MEDEIROS COMOTI VITA', 88.00, 48.00, 25.50, 113.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(37, 37, 234854, 'SAULO DE AVELLAR PAGLIARES', 90.00, 48.00, 23.50, 113.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(38, 38, 219551, 'THAYS KAROLYNE PONTE PRADO AGUIAR', 93.00, 48.00, 20.50, 113.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(39, 39, 232218, 'RAPHAELLY VENZEL', 90.00, 45.00, 23.50, 113.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(40, 40, 222762, 'NATHÁLIA MOURÃO BORGES', 90.00, 54.00, 22.50, 112.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(41, 41, 220550, 'VICTÓRIA VACARI DE BRUM', 94.00, 54.00, 18.50, 112.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(42, 42, 229179, 'FLÁVIA FARTOLINO DA SILVA', 87.00, 45.00, 25.50, 112.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(43, 43, 232430, 'RAMON MOREIRA GOMES DE SOUSA', 88.00, 42.00, 24.50, 112.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(44, 44, 218633, 'RAFAELA MARANHAO RIBEIRO', 85.00, 45.00, 27.00, 112.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(45, 45, 228361, 'JANCER JOSÉ TEIXEIRA JUNIOR', 85.00, 42.00, 27.00, 112.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(46, 46, 231785, 'ALEXANDRE OLIVEIRA ASSUNÇÃO', 96.00, 51.00, 15.50, 111.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(47, 47, 234457, 'LUÍS FELIPE COÊLHO LEITE', 89.00, 45.00, 22.50, 111.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(48, 48, 222302, 'VITORIA RAQUEL MONTEIRO DE MACEDO LIRA', 86.00, 42.00, 25.50, 111.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(49, 49, 230436, 'DYAGO SILVA SANTOS', 89.00, 51.00, 22.00, 111.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(50, 50, 222237, 'LUCIANO BERNARDO SOARES MATOS', 85.00, 45.00, 26.00, 111.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(51, 51, 219609, 'JOÃO GALDINO DE PASCOA JUNIOR', 89.00, 45.00, 22.00, 111.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(52, 52, 235281, 'ISABELLE SANTOS ALVES', 87.00, 42.00, 24.00, 111.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(53, 53, 228663, 'LUIZ AUGUSTO ARAUJO BALEEIRO', 85.00, 39.00, 26.00, 111.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(54, 54, 234957, 'FRANCISCO JOSE DE ARAGAO', 88.00, 45.00, 22.50, 110.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(55, 55, 231637, 'ALBERONE FERREIRA GONDIM SALES', 90.00, 48.00, 20.00, 110.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(56, 56, 227292, 'ANA BEATRIZ COSTA DA SILVA', 85.00, 45.00, 25.00, 110.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(57, 57, 232013, 'MATHEUS HENRIQUE RIBEIRO DA SILVA', 88.00, 45.00, 22.00, 110.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(58, 58, 233569, 'GERMANO PAIVA AGUIAR', 92.00, 48.00, 17.50, 109.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(59, 59, 218836, 'JOÃO MARTINS DE MORAIS NETO', 94.00, 48.00, 15.50, 109.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(60, 60, 227823, 'GUILHERME FERREIRA OESTREICHER', 89.00, 42.00, 20.50, 109.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(61, 61, 235360, 'GUILHERME AFONSO ALVES SOARES', 86.00, 39.00, 23.50, 109.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(62, 62, 236344, 'MIKAEL COUTINHO SILVA', 86.00, 45.00, 23.00, 109.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(63, 63, 230415, 'ANNA LUIZA PRADO MOURA', 85.00, 42.00, 23.50, 108.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(64, 64, 230342, 'CAIO LEONARDO DOS SANTOS SAGGIN', 89.00, 42.00, 19.50, 108.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(65, 65, 230270, 'LAIS RODRIGUES GONDINHO', 88.00, 51.00, 20.00, 108.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(66, 66, 237722, 'LAYSLLY CRISTINA DE ALMEIDA SILVA', 86.00, 42.00, 22.00, 108.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(67, 67, 227852, 'DANIEL FERREIRA OESTREICHER', 88.00, 42.00, 20.00, 108.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(68, 68, 231662, 'WILLIAM OLIVEIRA DA COSTA E SILVA', 91.00, 51.00, 16.50, 107.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(69, 69, 228837, 'LUCAS FÉLIX FELICIO MATOS', 86.00, 45.00, 21.50, 107.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(70, 70, 226467, 'GABRIELLA ZAU SCARANNI', 85.00, 42.00, 22.50, 107.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(71, 71, 218513, 'VITOR ERNESTO CALIARI MOTA', 91.00, 51.00, 16.00, 107.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(72, 72, 228308, 'VITÓRIA DE SOUSA ARAÚJO FARIAS', 86.00, 45.00, 21.00, 107.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(73, 73, 230704, 'ANNE CAROLINE MARINHO BRITO DE OLIVEIRA', 86.00, 45.00, 21.00, 107.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(74, 74, 235172, 'CAMILA PAMPONET DA FONSECA OLIVEIRA', 93.00, 48.00, 13.50, 106.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(75, 75, 228974, 'FLAVIA BASSANI ALVES', 85.00, 45.00, 21.50, 106.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(76, 76, 230496, 'PALLOMA MORAIS DE MEDEIROS REIS', 92.00, 45.00, 14.00, 106.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(77, 77, 235792, 'MARISTHELLA NARA ALVES DE LIMA', 88.00, 42.00, 18.00, 106.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(78, 78, 229052, 'RICARDO LUIS SILVA DE MELO', 88.00, 45.00, 17.50, 105.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(79, 79, 228209, 'MARCUS VINICIUS BARBOSA DE ARAUJO', 86.00, 45.00, 19.00, 105.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(80, 80, 231297, 'LUCCAS LIMA DA SILVA', 88.00, 45.00, 15.00, 103.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(81, 81, 228648, 'JESSICA MAYUMI HAYASHI', 88.00, 48.00, 14.00, 102.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(82, 82, 234487, 'VICTORIA HAMAOKA DE OLIVEIRA', 88.00, 45.00, 14.00, 102.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(83, 83, 229702, 'KARINA VALENTE DE MORAIS SANTOS', 88.00, 42.00, 14.00, 102.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(84, 84, 222821, 'JOÃO MARCOS LOPES BEZERRA', 89.00, 48.00, 12.50, 101.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(85, 85, 221493, 'WENDELL SILVEIRA DE SOUZA', 85.00, 42.00, 16.00, 101.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(86, 86, 235824, 'VINÍCIUS RODRIGUES ASSUNÇAO', 87.00, 42.00, 14.00, 101.00, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(87, 87, 228787, 'RAMYRES CAROLAYNNE SOUSA LOPES SILVA', 92.00, 48.00, 8.50, 100.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(88, 88, 220455, 'LARISSA SANTIAGO GUEDES', 86.00, 42.00, 14.50, 100.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(89, 89, 220171, 'OTAVIO PENNA PELLIZZETTI', 85.00, 45.00, 12.50, 97.50, 'LISTA DE ESPERA', '2018', 2, 6, 7),
(90, 1, 222994, 'HUENDEL BATISTA DE FIGUEIREDO NUNES', 91.00, 45.00, 28.00, 119.00, 'APROVADO', '2018', 4, 6, 7),
(91, 2, 224115, 'HYGOR AVINNER LOPES DA CUNHA', 88.00, 48.00, 27.00, 115.00, 'APROVADO', '2018', 4, 6, 7),
(92, 3, 219589, 'THAISA RIBEIRO DE OLIVEIRA', 79.00, 39.00, 25.50, 104.50, 'APROVADO', '2018', 4, 6, 7),
(93, 4, 233332, 'BRYAN GIUSSEPPE JARAMILLO CARDENAS', 82.00, 45.00, 21.50, 103.50, 'APROVADO', '2018', 4, 6, 7),
(94, 5, 235174, 'CAMILA SAMPAIO FLORENÇA SANTANA', 74.00, 36.00, 28.50, 102.50, 'APROVADO', '2018', 4, 6, 7),
(95, 6, 227007, 'KAIO FIGUEIREDO DA SILVA CRUZ', 78.00, 48.00, 23.50, 101.50, 'APROVADO', '2018', 4, 6, 7),
(96, 7, 218651, 'ALEXANDRE SOUZA DOS SANTOS', 78.00, 42.00, 23.50, 101.50, 'APROVADO', '2018', 4, 6, 7),
(97, 8, 237005, 'MARYCASSIELY RODRIGUES TIZOLIM', 72.00, 33.00, 29.00, 101.00, 'APROVADO', '2018', 4, 6, 7),
(98, 9, 218773, 'STEPHANYE BATISTA DE ANDRADE', 75.00, 42.00, 24.50, 99.50, 'APROVADO', '2018', 4, 6, 7),
(99, 10, 222527, 'ANDRÉ CARNEIRO DE BRITO', 71.00, 36.00, 25.50, 96.50, 'APROVADO', '2018', 4, 6, 7),
(100, 11, 219452, 'LUCAS OLIVEIRA LIMA', 80.00, 39.00, 16.00, 96.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(101, 12, 231315, 'RAFAEL SILVA SOARES', 72.00, 36.00, 24.00, 96.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(102, 13, 221890, 'LAYNA SIQUEIRA DA SILVA', 71.00, 33.00, 24.50, 95.50, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(103, 14, 232042, 'LUANA MAYSA PECCINI', 79.00, 45.00, 16.00, 95.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(104, 15, 229581, 'KAREN EVELYN SOUSA ALVES', 74.00, 39.00, 21.00, 95.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(105, 16, 224296, 'IRIAN DOS SANTOS SOARES', 77.00, 39.00, 18.00, 95.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(106, 17, 234248, 'JORGE LUIZ RIBEIRO DE OLIVEIRA', 83.00, 42.00, 10.50, 93.50, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(107, 18, 228920, 'JACKSON KENNEDY DE SOUZA FERREIRA', 81.00, 48.00, 11.00, 92.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(108, 19, 234974, 'RAYZA BRITO SILVA', 84.00, 48.00, 8.00, 92.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(109, 20, 230295, 'THALES FERREIRA LEITE', 75.00, 33.00, 15.50, 90.50, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(110, 21, 229093, 'VILENA MARJANA BEZERRA PEREIRA', 75.00, 45.00, 15.00, 90.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(111, 22, 229908, 'THALYTA CAVALCANTE FERREIRA', 71.00, 36.00, 17.00, 88.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(112, 23, 218686, 'LUCILANE SANTANA PEREIRA', 77.00, 36.00, 10.50, 87.50, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(113, 24, 222291, 'JOHN ESDRAS DUTRA DE SOUZA', 77.00, 42.00, 10.00, 87.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(114, 25, 231882, 'DIÓRGENES RODRIGUES CARDOSO', 78.00, 36.00, 8.50, 86.50, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(115, 26, 227871, 'HUDSON FARIAS TRAJANO', 75.00, 48.00, 10.00, 85.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(116, 27, 237869, 'VICTOR MANOEL DA SILVA CORREIA', 79.00, 39.00, 6.00, 85.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(117, 28, 228679, 'JAIME BUENO DE ARAUJO', 74.00, 36.00, 11.00, 85.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(118, 29, 219571, 'PAULA AMBRÓSIO SILVA', 73.00, 39.00, 10.00, 83.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(119, 30, 228132, 'FELIPE ROMANO SEIXO', 74.00, 36.00, 9.00, 83.00, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(120, 31, 228545, 'SAMIR ANIEL OLIVEIRA SOUTO', 71.00, 36.00, 8.50, 79.50, 'LISTA DE ESPERA', '2018', 4, 6, 7),
(121, 1, 228198, 'MARIA INGRID SAMPAIO DE OLIVEIRA', 82.00, 48.00, 18.00, 100.00, 'APROVADO', '2018', 6, 6, 7),
(122, 2, 227571, 'KARINA CRISTINA CARVALHO DOS SANTOS', 81.00, 42.00, 18.00, 99.00, 'APROVADO', '2018', 6, 6, 7),
(123, 3, 223411, 'LORENA SIMONE GOVEIA', 77.00, 48.00, 20.00, 97.00, 'APROVADO', '2018', 6, 6, 7),
(124, 4, 234165, 'SUELLEM CRYSTINA DE SIQUEIRA PAIVA DOS SANTOS', 75.00, 48.00, 19.00, 94.00, 'LISTA DE ESPERA', '2018', 6, 6, 7),
(125, 5, 228537, 'RICKY BRENDO RODRIGUES CARDOSO', 79.00, 45.00, 10.50, 89.50, 'LISTA DE ESPERA', '2018', 6, 6, 7),
(126, 6, 227450, 'DHARA MARTINS DE SOUZA', 74.00, 39.00, 12.00, 86.00, 'LISTA DE ESPERA', '2018', 6, 6, 7),
(127, 7, 227531, 'PAULO EDUARDO OLIVEIRA MEDEIROS.', 74.00, 39.00, 3.50, 77.50, 'LISTA DE ESPERA', '2018', 6, 6, 7),
(128, 1, 227175, 'KARLO ANDRÉ VALDIVIA BALLÓN', 99.00, 48.00, 28.50, 127.50, 'APROVADO', '2018', 8, 6, 7),
(129, 2, 221467, 'BRUNO RAFAEL MOREIRA GONDIM', 90.00, 45.00, 25.00, 115.00, 'APROVADO', '2018', 8, 6, 7),
(130, 3, 224766, 'LUISA LYRA RODRIGUES', 87.00, 45.00, 24.50, 111.50, 'APROVADO', '2018', 8, 6, 7),
(131, 4, 219763, 'CIBELE LOUSANE PINHO MOTA', 85.00, 48.00, 24.50, 109.50, 'APROVADO', '2018', 8, 6, 7),
(132, 5, 230930, 'GABRIEL CHAVES MUNIZ DOS SANTOS', 83.00, 45.00, 26.50, 109.50, 'APROVADO', '2018', 8, 6, 7),
(133, 6, 218655, 'POLIANA LUCENA DOS SANTOS', 87.00, 48.00, 20.00, 107.00, 'APROVADO', '2018', 8, 6, 7),
(134, 7, 236496, 'GUILHERME MORGADO SILVA', 87.00, 42.00, 20.00, 107.00, 'APROVADO', '2018', 8, 6, 7),
(135, 8, 235381, 'BRENO TEIXEIRA FARIA ARKADER', 79.00, 39.00, 28.00, 107.00, 'APROVADO', '2018', 8, 6, 7),
(136, 9, 232135, 'IANARA FERNANDA DE LIMA MENDES', 80.00, 39.00, 27.00, 107.00, 'APROVADO', '2018', 8, 6, 7),
(137, 10, 224270, 'HEULLER PABLO CUNHA ALMEIDA', 90.00, 45.00, 16.00, 106.00, 'APROVADO', '2018', 8, 6, 7),
(138, 11, 232220, 'HIGOR BRUNO DA SILVA', 84.00, 39.00, 22.00, 106.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(139, 12, 232428, 'JANDERSON DE CASTRO E SILVA', 85.00, 48.00, 20.50, 105.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(140, 13, 223756, 'EMANUEL SILVA DE ABREU', 80.00, 42.00, 24.50, 104.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(141, 14, 225846, 'ANDRE VINICIUS LIMA SILVA', 83.00, 42.00, 21.50, 104.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(142, 15, 238003, 'LEONARDO SENA DE ALMEIDA', 83.00, 54.00, 21.00, 104.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(143, 16, 230140, 'RODRIGO HIGINO MAR E SILVA', 89.00, 48.00, 14.00, 103.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(144, 17, 234991, 'JHON ANDREO ALMEIDA DOS SANTOS', 83.00, 45.00, 19.00, 102.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(145, 18, 231455, 'KAROLINE GABRIELY SERGIO DE SENA COSTA', 82.00, 42.00, 20.00, 102.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(146, 19, 232797, 'ISABELLA MATOS MEDEIROS', 85.00, 42.00, 17.00, 102.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(147, 20, 224146, 'MATEUS RODRIGUES MOREIRA', 82.00, 42.00, 18.00, 100.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(148, 21, 228744, 'PAULA LUISE SCHIMITZ SILVA', 85.00, 45.00, 14.50, 99.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(149, 22, 227799, 'WENDY LORENI HARDY REINERT', 83.00, 48.00, 14.50, 97.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(150, 23, 225677, 'JÉSSICA DE SOUZA SILVA', 79.00, 51.00, 15.50, 94.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(151, 24, 228390, 'ANDRE JEREMIAS BATISTA COLARES', 81.00, 42.00, 13.50, 94.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(152, 25, 219317, 'ÁQUILA MICAÍAS MACÊDO DE SOUZA GONÇALVES', 84.00, 45.00, 9.50, 93.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(153, 26, 222717, 'MILENA VIEIRA DIAS DOS SANTOS', 79.00, 39.00, 13.50, 92.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(154, 27, 222621, 'LETICIA CABRAL PESSANHA', 83.00, 45.00, 9.00, 92.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(155, 28, 234686, 'SOLANGE VENÂNCIO MILANI', 80.00, 42.00, 11.50, 91.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(156, 29, 233499, 'YANKA COSTA CARVALHO', 81.00, 42.00, 9.50, 90.50, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(157, 30, 221141, 'PAULA TAINÁ BARBOSA ALVES', 82.00, 39.00, 6.00, 88.00, 'LISTA DE ESPERA', '2018', 8, 6, 7),
(158, 1, 232369, 'ANA CAROLINE DOS REIS DANTAS', 92.00, 45.00, 29.50, 121.50, 'APROVADO', '2018', 10, 6, 7),
(159, 2, 219448, 'BRUNO GUEDES PEREIRA', 91.00, 45.00, 29.00, 120.00, 'APROVADO', '2018', 10, 6, 7),
(160, 3, 219889, 'ANA CRISTINA COSTA FERREIRA', 89.00, 48.00, 27.50, 116.50, 'LISTA DE ESPERA', '2018', 10, 6, 7),
(161, 4, 235785, 'FELIPE OLIVEIRA PLASTER', 92.00, 48.00, 24.00, 116.00, 'LISTA DE ESPERA', '2018', 10, 6, 7),
(162, 5, 230078, 'ANA LUÍZA PESSANHA RIBEIRO', 87.00, 45.00, 26.50, 113.50, 'LISTA DE ESPERA', '2018', 10, 6, 7),
(163, 6, 230083, 'JULIA RODRIGUES CAPUTO', 87.00, 45.00, 20.00, 107.00, 'LISTA DE ESPERA', '2018', 10, 6, 7),
(164, 1, 231049, 'LEONARDO CANDIDO PRADO AGUIAR', 83.00, 45.00, 9.00, 92.00, 'APROVADO', '2018', 1, 6, 7),
(165, 2, 227902, 'SEMIRA URIEL JALES DE ALMEIDA', 68.00, 36.00, 15.00, 83.00, 'APROVADO', '2018', 1, 6, 7),
(166, 3, 225024, 'ALÉXIA MAHARA MARQUES ARAÚJO', 65.00, 27.00, 14.00, 79.00, 'APROVADO', '2018', 1, 6, 7),
(167, 4, 223112, 'MARCOS ANTONIO GADELHA FRANKLIN DOS SANTOS', 67.00, 36.00, 11.00, 78.00, 'APROVADO', '2018', 1, 6, 7),
(168, 5, 230790, 'VITOR BRUNO OLIVEIRA DE ARAUJO', 65.00, 30.00, 12.00, 77.00, 'LISTA DE ESPERA', '2018', 1, 6, 7),
(169, 6, 220193, 'SARAH GABRIELLY REZENDE DE OLIVEIRA', 57.00, 21.00, 18.50, 75.50, 'LISTA DE ESPERA', '2018', 1, 6, 7),
(170, 7, 228678, 'ANGELO LIMA SILVA', 53.00, 24.00, 20.50, 73.50, 'LISTA DE ESPERA', '2018', 1, 6, 7),
(171, 8, 228106, 'KATINAYANE JAINE DA SILVA ZOIN', 60.00, 36.00, 13.00, 73.00, 'LISTA DE ESPERA', '2018', 1, 6, 7),
(172, 9, 227625, 'THIAGO QUIRINO ARAÚJO SOUZA', 56.00, 33.00, 10.50, 66.50, 'LISTA DE ESPERA', '2018', 1, 6, 7),
(173, 10, 225282, 'DORIVAN FLORENCIO RODRIGUES DE OLIVEIRA', 50.00, 15.00, 16.00, 66.00, 'LISTA DE ESPERA', '2018', 1, 6, 7),
(174, 11, 225295, 'TENNER DOS SANTOS NUNES', 54.00, 21.00, 9.50, 63.50, 'LISTA DE ESPERA', '2018', 1, 6, 7),
(175, 12, 234634, 'RAPHAEL CARVALHO DE OLIVEIRA', 51.00, 30.00, 8.50, 59.50, 'LISTA DE ESPERA', '2018', 1, 6, 7),
(176, 1, 226176, 'HEMERSON RAFAEL DOS SANTOS SILVA', 52.00, 30.00, 17.50, 69.50, 'APROVADO', '2018', 3, 6, 7),
(177, 2, 235745, 'MAURÍCIO LOPES FERNANDES', 45.00, 18.00, 24.50, 69.50, 'APROVADO', '2018', 3, 6, 7),
(178, 3, 221312, 'RAIKLANY DE SOUZA ALMEIDA', 31.00, 12.00, 15.00, 46.00, 'APROVADO', '2018', 3, 6, 7),
(179, 4, 231246, 'JONATHAN PEREIRA SILVA', 32.00, 12.00, 9.50, 41.50, 'LISTA DE ESPERA', '2018', 3, 6, 7),
(180, 1, 218519, 'TARIANA LUCENA DOS SANTOS', 67.00, 39.00, 25.50, 92.50, 'APROVADO', '2018', 7, 6, 7),
(181, 2, 221208, 'KAROLAYNE BARROS DA SILVA', 68.00, 36.00, 11.00, 79.00, 'APROVADO', '2018', 7, 6, 7),
(182, 3, 232847, 'NAROTTAM SÓCRATES GARCIA CHUMPITAZ', 68.00, 33.00, 9.50, 77.50, 'APROVADO', '2018', 7, 6, 7),
(183, 4, 230387, 'VICTOR GABRIEL DA SILVA BRITO', 50.00, 24.00, 16.00, 66.00, 'LISTA DE ESPERA', '2018', 7, 6, 7),
(184, 5, 222126, 'ARYANNE MENDONÇA ROTH NOGUEIRA', 44.00, 18.00, 12.50, 56.50, 'LISTA DE ESPERA', '2018', 7, 6, 7),
(185, 6, 236300, 'FABIANA ZANETTI DA COSTA', 46.00, 18.00, 10.00, 56.00, 'LISTA DE ESPERA', '2018', 7, 6, 7),
(186, 7, 225717, 'THIAGO TANNURE VIANNA', 45.00, 21.00, 9.00, 54.00, 'LISTA DE ESPERA', '2018', 7, 6, 7),
(187, 1, 233812, 'NICOLE MARQUES DANTAS', 32.00, 12.00, 7.50, 39.50, 'APROVADO', '2018', 9, 6, 7),
(188, 2, 229023, 'AUGUSTO DANTAS LEITÃO', 22.00, 9.00, 14.00, 36.00, 'LISTA DE ESPERA', '2018', 9, 6, 7),
(189, 1, 106387, 'KARINY BATISTA DE OLIVEIRA', 95.00, 51.00, 27.50, 122.50, 'APROVADO', '2017', 2, 6, 6),
(190, 2, 66571, 'TIAGO DE LIMA RODRÍGUEZ', 94.00, 45.00, 28.50, 122.50, 'APROVADO', '2017', 2, 6, 6),
(191, 3, 84790, 'GABRIEL BARBOSA RODRIGUES', 94.00, 54.00, 27.50, 121.50, 'APROVADO', '2017', 2, 6, 6),
(192, 4, 123194, 'THAÍS SILVA SANTOS ZDRADEK', 95.00, 48.00, 25.50, 120.50, 'APROVADO', '2017', 2, 6, 6),
(193, 5, 120977, 'SHELDON OLIVEIRA FERREIRA', 93.00, 45.00, 26.00, 119.00, 'APROVADO', '2017', 2, 6, 6),
(194, 6, 84186, 'MILENA RICARTE BESERRA', 91.00, 51.00, 27.50, 118.50, 'APROVADO', '2017', 2, 6, 6),
(195, 7, 61346, 'HERCILIA ALBUQUERQUE GALVÃO DA COSTA', 91.00, 48.00, 27.50, 118.50, 'APROVADO', '2017', 2, 6, 6),
(196, 8, 59755, 'MAILLA MYLENA MENDES BERGMANN', 92.00, 48.00, 26.50, 118.50, 'APROVADO', '2017', 2, 6, 6),
(197, 9, 93280, 'MARCOS LAÉRCIO RABELO SIQUEIRA', 93.00, 48.00, 25.50, 118.50, 'APROVADO', '2017', 2, 6, 6),
(198, 10, 33272, 'THIAGO WILLIAN MOREIRA CAMPELO', 93.00, 48.00, 25.50, 118.50, 'APROVADO', '2017', 2, 6, 6),
(199, 11, 105530, 'RAFAELLE DE LIMA FERNANDES', 94.00, 48.00, 24.50, 118.50, 'APROVADO', '2017', 2, 6, 6),
(200, 12, 60971, 'ANA LUCIA DE LIMA', 92.00, 51.00, 26.00, 118.00, 'APROVADO', '2017', 2, 6, 6),
(201, 13, 121156, 'LYCIA SILVA RIBEIRO', 94.00, 51.00, 24.00, 118.00, 'APROVADO', '2017', 2, 6, 6),
(202, 14, 122218, 'DANILO VALENTE DE MORAES', 89.00, 42.00, 29.00, 118.00, 'APROVADO', '2017', 2, 6, 6),
(203, 15, 38295, 'MATEUS VASCONCELOS SIQUEIRA', 92.00, 48.00, 25.50, 117.50, 'APROVADO', '2017', 2, 6, 6),
(204, 16, 85243, 'HUGO RAMOS DOMINGOS', 95.00, 51.00, 22.00, 117.00, 'APROVADO', '2017', 2, 6, 6),
(205, 17, 122247, 'GABRIEL FERREIRA JACINTHO', 90.00, 48.00, 27.00, 117.00, 'APROVADO', '2017', 2, 6, 6),
(206, 18, 111347, 'MATHEUS PINHO NAKASHIMA DE MELO', 90.00, 48.00, 27.00, 117.00, 'APROVADO', '2017', 2, 6, 6),
(207, 19, 65567, 'BRUNA MESSIAS JACQUES DE MORAES', 91.00, 48.00, 26.00, 117.00, 'APROVADO', '2017', 2, 6, 6),
(208, 20, 83504, 'JESSYCA BRUNA AGUIAR DO NASCIMENTO', 89.00, 45.00, 28.00, 117.00, 'APROVADO', '2017', 2, 6, 6),
(209, 21, 110449, 'LAÍS OLIVEIRA MATOS', 88.00, 42.00, 29.00, 117.00, 'APROVADO', '2017', 2, 6, 6),
(210, 22, 96025, 'THAYNA MENEZES MAGALHAES', 90.00, 54.00, 26.50, 116.50, 'APROVADO', '2017', 2, 6, 6),
(211, 23, 43625, 'ANA LUÍSA MENDES', 90.00, 48.00, 26.50, 116.50, 'APROVADO', '2017', 2, 6, 6),
(212, 24, 119147, 'BIANCA CRUZ DE MOURA', 88.00, 45.00, 28.50, 116.50, 'APROVADO', '2017', 2, 6, 6),
(213, 25, 110993, 'VICTOR BRAGA BARBOSA', 94.00, 51.00, 22.00, 116.00, 'APROVADO', '2017', 2, 6, 6),
(214, 26, 105969, 'MARIA ELISA DO VALE MOREIRA', 94.00, 51.00, 22.00, 116.00, 'APROVADO', '2017', 2, 6, 6),
(215, 27, 124986, 'THIAGO SANTIAGO DE LIRA', 89.00, 48.00, 27.00, 116.00, 'APROVADO', '2017', 2, 6, 6),
(216, 28, 93839, 'RODRIGO PINHEIRO WILKENS MARINHO', 92.00, 48.00, 24.00, 116.00, 'APROVADO', '2017', 2, 6, 6),
(217, 29, 96882, 'CARLA BALENZUELA ANANIAS', 89.00, 45.00, 27.00, 116.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(218, 30, 118908, 'CAMILA FONSECA CARNEIRO', 91.00, 45.00, 25.00, 116.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(219, 31, 121453, 'WYLIVER BARKYN SAUNDERS ROCHA TAVARES', 90.00, 42.00, 26.00, 116.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(220, 32, 123157, 'ROSEVELTO MAIA BORGES', 87.00, 45.00, 28.50, 115.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(221, 33, 123180, 'ANA BEATRIZ PIRES DE SOUZA', 91.00, 45.00, 24.50, 115.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(222, 34, 124074, 'LUCAS CARVALHO CAMARGO', 90.00, 48.00, 25.00, 115.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(223, 35, 95891, 'ISABELLA MARAVALHA GOMES', 88.00, 48.00, 26.50, 114.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(224, 36, 111102, 'MAX EMMANUEL NUNES CARNEIRO DE OLIVEIRA', 89.00, 48.00, 25.50, 114.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(225, 37, 123064, 'AMANDA CAIXETA MAGALHÃES', 91.00, 48.00, 23.50, 114.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(226, 38, 119582, 'KARINY FACIONI SCALABRIN', 86.00, 42.00, 28.50, 114.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(227, 39, 121462, 'MARCELLO FIGUEIREDO CAMPOS', 87.00, 42.00, 27.50, 114.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(228, 40, 93891, 'LETÍCIA LINS FREIRE DE OLIVEIRA', 89.00, 48.00, 25.00, 114.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(229, 41, 123815, 'AMANDA COSTA BARROS DA SILVA', 87.00, 45.00, 27.00, 114.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(230, 42, 111139, 'ALBERTO MAIA PATRICIO DE FIGUEIREDO JUNIOR', 88.00, 45.00, 26.00, 114.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(231, 43, 97373, 'GABRIEL PATRÍCIO SANTOS DE MEDEIROS', 89.00, 45.00, 25.00, 114.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(232, 44, 108662, 'GIULIA BORGERT PEREGRINO', 91.00, 45.00, 23.00, 114.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(233, 45, 124697, 'WESLEY DE SOUZA TÔRRES', 86.00, 48.00, 27.50, 113.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(234, 46, 112748, 'ADÔNIS BEZERRA CAVALCANTE FILHO', 92.00, 48.00, 21.50, 113.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(235, 47, 122182, 'MILENA ELLEN MINEIRO TORRES', 86.00, 45.00, 27.50, 113.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(236, 48, 121241, 'MATHEUS VINICIUS DA SILVA SANTOS', 87.00, 45.00, 26.50, 113.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(237, 49, 87173, 'LAURA RICARTE BESERRA AMANCIO', 87.00, 45.00, 26.50, 113.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(238, 50, 111310, 'VINÍCIUS RODRIGUES ASSUNÇAO', 87.00, 48.00, 26.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(239, 51, 119892, 'RAISSA DE SOUZA NOBRE', 88.00, 48.00, 25.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(240, 52, 123014, 'DÉBORAH BRAGA COSTA', 88.00, 48.00, 25.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(241, 53, 98823, 'SACHA MONIQUE PINTO CASTRO', 89.00, 48.00, 24.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(242, 54, 108981, 'VICTORIA BARROSO LADEIRA', 90.00, 48.00, 23.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(243, 55, 111741, 'ANA CAROLINA MOTA DE SOUSA', 93.00, 48.00, 20.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(244, 56, 93497, 'ANTONIA LARA DA COSTA MACÊDO', 87.00, 45.00, 26.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(245, 57, 121441, 'MATEUS VIDAL DE NEGREIROS LIRA', 89.00, 45.00, 24.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(246, 58, 120074, 'GUILHERME FIALHO ORTEGAL', 90.00, 45.00, 23.00, 113.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(247, 59, 111650, 'ANGELA SARAH GOMES SEVERIANO', 88.00, 48.00, 24.50, 112.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(248, 60, 93505, 'ANNE LUISE PONTES CORDOVIL', 89.00, 48.00, 23.50, 112.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(249, 61, 122917, 'VINÍCIUS RIBEIRO DE ARÊA LEÃO COSTA', 89.00, 48.00, 23.50, 112.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(250, 62, 121089, 'GABRIELLA ZAU SCARANNI', 92.00, 48.00, 20.50, 112.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(251, 63, 122430, 'LEONARDO ALVAREZ SANTOS', 88.00, 45.00, 24.50, 112.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(252, 64, 120164, 'ALBERONE FERREIRA GONDIM SALES', 89.00, 42.00, 23.50, 112.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(253, 65, 83666, 'IAGO GOUVÊA DO CARMO E SILVA', 90.00, 51.00, 22.00, 112.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(254, 66, 122204, 'BRUNO OLIVEIRA IGNACIO FERREIRA', 87.00, 48.00, 25.00, 112.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(255, 67, 105296, 'MATHEUS GOMES DE SOUSA', 87.00, 45.00, 25.00, 112.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(256, 68, 107395, 'VANESSA VIEIRA PINHEIRO CORRÊA', 90.00, 45.00, 22.00, 112.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(257, 69, 120722, 'LAURA CASTANHEIRA FERREIRA', 87.00, 42.00, 25.00, 112.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(258, 70, 121042, 'JOAO PEDRO SALGADO PIO OLIVEIRA', 87.00, 48.00, 24.50, 111.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(259, 71, 61013, 'CAROLINE BARBOSA MOURA', 86.00, 48.00, 25.00, 111.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(260, 72, 121201, 'MARIA ELIZA CALDAS DOS SANTOS', 87.00, 45.00, 24.00, 111.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(261, 73, 124096, 'VINÍCIUS DE OLIVEIRA LINSBINSKI', 87.00, 48.00, 23.00, 110.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(262, 74, 62980, 'DANIEL FERREIRA OESTREICHER', 89.00, 48.00, 21.00, 110.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(263, 75, 122335, 'MUSI UCHÔA', 89.00, 45.00, 21.00, 110.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(264, 76, 111719, 'ALGENOR MARIA DA COSTA TEIXEIRA NETO', 90.00, 48.00, 19.50, 109.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(265, 77, 88858, 'PAULA LUISE SCHIMITZ SILVA', 89.00, 48.00, 20.00, 109.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(266, 78, 120435, 'CAIO LEONARDO DOS SANTOS SAGGIN', 86.00, 45.00, 23.00, 109.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(267, 79, 122379, 'CAIO CÉSAR VERAS PEREIRA', 86.00, 45.00, 23.00, 109.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(268, 80, 121291, 'WALDIR TEIXEIRA DA MATTA FLORA NETO', 87.00, 45.00, 22.00, 109.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(269, 81, 119657, 'BRUNO GUEDES PEREIRA', 88.00, 42.00, 21.00, 109.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(270, 82, 124615, 'ANA CAROLINA MACEDO CARVALHO DE MELO', 90.00, 48.00, 18.50, 108.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(271, 83, 122457, 'VIVIANE KELLY DE SOUZA MOURA', 92.00, 48.00, 16.50, 108.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(272, 84, 122220, 'LUIS OTAVIO MIRANDA TEIXEIRA', 86.00, 45.00, 22.50, 108.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(273, 85, 94089, 'JAKELINE VALÉRIA DE SOUZA COSTA', 86.00, 45.00, 22.50, 108.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(274, 86, 123430, 'LUIZ AUGUSTO ARAUJO BALEEIRO', 86.00, 48.00, 22.00, 108.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(275, 87, 6578, 'YAGO CHAVES DOS SANTOS AGUIAR', 86.00, 45.00, 22.00, 108.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(276, 88, 97945, 'BRUNA BRAGA DE MENDONÇA', 86.00, 45.00, 22.00, 108.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(277, 89, 105457, 'WAGNER ELISIARIO MONTEIRO', 87.00, 51.00, 20.50, 107.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(278, 90, 88300, 'CLAUDIA JULIANA NORIEGA REY', 91.00, 51.00, 15.00, 106.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(279, 91, 13627, 'ANDRÉA SOUZA DOS SANTOS', 87.00, 48.00, 17.00, 104.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(280, 92, 105896, 'ELANE FROTA ARAGAO', 87.00, 42.00, 17.00, 104.00, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(281, 93, 63258, 'GUILHERME FERREIRA OESTREICHER', 86.00, 48.00, 17.50, 103.50, 'LISTA DE ESPERA', '2017', 2, 6, 6),
(282, 1, 3940, 'SABRINA ARAUJO RAMOS', 86.00, 48.00, 26.50, 112.50, 'APROVADO', '2017', 4, 6, 6),
(283, 2, 91236, 'RODRIGO DOS SANTOS DA SILVA', 92.00, 48.00, 20.00, 112.00, 'APROVADO', '2017', 4, 6, 6),
(284, 3, 98092, 'THALIA INÁCIA ARAÚJO CARDOSO', 84.00, 42.00, 26.50, 110.50, 'APROVADO', '2017', 4, 6, 6),
(285, 4, 124710, 'ASAFY REZENDE SANTOS', 83.00, 48.00, 24.50, 107.50, 'APROVADO', '2017', 4, 6, 6),
(286, 5, 32817, 'VICTOR DA SILVA SANTOS', 82.00, 45.00, 24.50, 106.50, 'APROVADO', '2017', 4, 6, 6),
(287, 6, 83527, 'CAIO VITTOR NASCIMENTO DUO', 86.00, 42.00, 19.00, 105.00, 'APROVADO', '2017', 4, 6, 6),
(288, 7, 121894, 'INGRID GABRIELE DE SOUZA', 79.00, 42.00, 25.50, 104.50, 'APROVADO', '2017', 4, 6, 6),
(289, 8, 43260, 'MICHELLE VANESSA SANTIAGO FRANCO', 78.00, 42.00, 26.00, 104.00, 'APROVADO', '2017', 4, 6, 6),
(290, 9, 82298, 'FLÁVIA MARCELLE BARRETO CAVALCANTE', 81.00, 42.00, 22.50, 103.50, 'APROVADO', '2017', 4, 6, 6),
(291, 10, 97855, 'MARIANA SENA ALMEIDA FIGUEIREDO', 77.00, 42.00, 26.00, 103.00, 'APROVADO', '2017', 4, 6, 6),
(292, 11, 39853, 'LEANDRO OLIVEIRA SAMPAIO', 79.00, 45.00, 23.50, 102.50, 'APROVADO', '2017', 4, 6, 6),
(293, 12, 97417, 'MATEUS DE OLIVEIRA LOPES', 79.00, 42.00, 23.00, 102.00, 'APROVADO', '2017', 4, 6, 6),
(294, 13, 94856, 'IRAN BARROS DE CASTRO', 79.00, 42.00, 22.50, 101.50, 'APROVADO', '2017', 4, 6, 6),
(295, 14, 83979, 'PÂMELLA GRAZIELLA GOMES FONTENELLE', 78.00, 39.00, 23.50, 101.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(296, 15, 121866, 'VICTOR HUGO ARAUJO MORAES', 83.00, 45.00, 18.00, 101.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(297, 16, 112004, 'RAPHAEL DA SILVA SEGHETO', 77.00, 42.00, 24.00, 101.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(298, 17, 111429, 'IRIAN DOS SANTOS SOARES', 79.00, 48.00, 21.50, 100.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(299, 18, 12371, 'VINÍCIUS SANTOS CRUZ', 79.00, 48.00, 21.50, 100.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(300, 19, 98166, 'HEULLER PABLO CUNHA ALMEIDA', 84.00, 45.00, 16.00, 100.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(301, 20, 122046, 'JOÃO VICTOR ANDRADE DE SA', 79.00, 42.00, 21.00, 100.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(302, 21, 85275, 'STEPHANYE BATISTA DE ANDRADE', 75.00, 39.00, 24.50, 99.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(303, 22, 6499, 'CLEIA NASCIMENTO DOS SANTOS', 74.00, 42.00, 24.50, 98.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(304, 23, 122729, 'LETÍCIA GOMES DE SÁ', 75.00, 42.00, 23.00, 98.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(305, 24, 121256, 'ITALO IRIS BOIBA RODRIGUES DA CUNHA', 78.00, 42.00, 20.00, 98.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(306, 25, 110999, 'LUCAS CALDAS DE FIGUEIREDO', 79.00, 45.00, 18.50, 97.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(307, 26, 84106, 'KAIO FIGUEIREDO DA SILVA CRUZ', 74.00, 42.00, 23.50, 97.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(308, 27, 87196, 'WILLIANE CASTRO DA CRUZ', 74.00, 39.00, 23.50, 97.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(309, 28, 64753, 'BRYAN GIUSSEPPE JARAMILLO CARDENAS', 75.00, 36.00, 22.50, 97.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(310, 29, 105189, 'MATEUS MARTINS MORAES', 74.00, 45.00, 21.50, 95.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(311, 30, 118827, 'THALES ZIDANNE DA SILVA LINO', 75.00, 45.00, 19.50, 94.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(312, 31, 64107, 'JOSE MATEUS OLIVEIRA MARIANO', 74.00, 42.00, 20.50, 94.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(313, 32, 3332, 'ODEVÂNIA DA CRUZ AVELINO', 75.00, 42.00, 19.50, 94.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(314, 33, 123384, 'RICKY BRENDO RODRIGUES CARDOSO', 75.00, 39.00, 19.50, 94.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(315, 34, 38115, 'DRIELY PINTO TORREIAS', 75.00, 45.00, 19.00, 94.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(316, 35, 98202, 'RAQUEL COSTA GONCALVES', 75.00, 42.00, 18.50, 93.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(317, 36, 100227, 'MATEUS FERREIRA DE AGUIAR', 78.00, 45.00, 14.50, 92.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(318, 37, 106563, 'ANANDA DUARTE DE OLIVEIRA', 74.00, 42.00, 18.50, 92.50, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(319, 38, 120878, 'GRACIELLE DE FREITAS SOARES', 76.00, 39.00, 15.00, 91.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(320, 39, 83658, 'JAIME BUENO DE ARAUJO', 75.00, 48.00, 14.00, 89.00, 'LISTA DE ESPERA', '2017', 4, 6, 6),
(321, 1, 94716, 'JOÃO VICTOR DE OLIVEIRA CAVALCANTE', 100.00, 51.00, 29.50, 129.50, 'APROVADO', '2017', 6, 6, 6),
(322, 2, 4757, 'ANDERSON ADEMIR KUKLINSKI', 87.00, 48.00, 24.00, 111.00, 'APROVADO', '2017', 6, 6, 6),
(323, 3, 84363, 'STEFANY CAMILY SERRÃO SANTOS', 86.00, 45.00, 25.00, 111.00, 'APROVADO', '2017', 6, 6, 6),
(324, 4, 109603, 'DIANA CLEIA ALMEIDA DA SILVA CASTRO', 82.00, 36.00, 23.50, 105.50, 'LISTA DE ESPERA', '2017', 6, 6, 6),
(325, 5, 83501, 'JHONATAN MATHEUS MENDONÇA DOS SANTOS', 82.00, 45.00, 23.00, 105.00, 'LISTA DE ESPERA', '2017', 6, 6, 6),
(326, 6, 70517, 'MARIA INGRID SAMPAIO DE OLIVEIRA', 82.00, 45.00, 19.50, 101.50, 'LISTA DE ESPERA', '2017', 6, 6, 6),
(327, 7, 2185, 'LORENA SIMONE GOVEIA', 77.00, 42.00, 22.00, 99.00, 'LISTA DE ESPERA', '2017', 6, 6, 6),
(328, 8, 110492, 'KAELLEN OLIVEIRA MORAES FONSECA', 78.00, 42.00, 20.00, 98.00, 'LISTA DE ESPERA', '2017', 6, 6, 6),
(329, 9, 110414, 'PEDRO FELIPE MENDONÇA CAMPOS', 76.00, 42.00, 19.50, 95.50, 'LISTA DE ESPERA', '2017', 6, 6, 6),
(330, 10, 97207, 'DHARA MARTINS DE SOUZA', 76.00, 42.00, 16.00, 92.00, 'LISTA DE ESPERA', '2017', 6, 6, 6),
(331, 1, 61651, 'JOÃO MARCOS MOTA FERREIRA GOMES', 96.00, 54.00, 25.00, 121.00, 'APROVADO', '2017', 8, 6, 6),
(332, 2, 8613, 'MATHEUS DANTAS BRUM', 89.00, 48.00, 23.50, 112.50, 'APROVADO', '2017', 8, 6, 6),
(333, 3, 98574, 'ALLEF LUCAS DE FREITAS COUTINHO', 83.00, 45.00, 28.00, 111.00, 'APROVADO', '2017', 8, 6, 6),
(334, 4, 1618, 'YASMIN DE FREITAS SANTOS', 86.00, 45.00, 25.00, 111.00, 'APROVADO', '2017', 8, 6, 6),
(335, 5, 118455, 'WELLYSON GONCALVES FARIAS', 85.00, 48.00, 25.50, 110.50, 'APROVADO', '2017', 8, 6, 6),
(336, 6, 123358, 'PAULA KATHARINE CORREA NASCIMENTO', 82.00, 45.00, 28.50, 110.50, 'APROVADO', '2017', 8, 6, 6),
(337, 7, 97064, 'JAMILE DE HOLANDA LIMA MAMED', 88.00, 48.00, 22.00, 110.00, 'APROVADO', '2017', 8, 6, 6),
(338, 8, 85341, 'ANTONIO DE PINHO LIMA NETO', 86.00, 48.00, 23.50, 109.50, 'APROVADO', '2017', 8, 6, 6),
(339, 9, 85893, 'JÚLIO CESAR PINHEIRO DE MENEZES FILHO', 84.00, 48.00, 25.00, 109.00, 'APROVADO', '2017', 8, 6, 6),
(340, 10, 84075, 'JESSYANA GOMES VIEIRA', 84.00, 45.00, 25.00, 109.00, 'APROVADO', '2017', 8, 6, 6),
(341, 11, 47635, 'KAMILA KENDRA MAR MARQUES', 85.00, 45.00, 23.50, 108.50, 'APROVADO', '2017', 8, 6, 6),
(342, 12, 59565, 'DIOGENES FILHO', 80.00, 45.00, 28.00, 108.00, 'APROVADO', '2017', 8, 6, 6),
(343, 13, 84589, 'JHENNIFER DO NASCIMENTO PEREIRA', 82.00, 42.00, 26.00, 108.00, 'APROVADO', '2017', 8, 6, 6),
(344, 14, 84247, 'GABRIEL LIMA DA SILVA', 85.00, 42.00, 23.00, 108.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(345, 15, 88231, 'GRACIELLI NONATO BARBOSA', 83.00, 48.00, 23.50, 106.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(346, 16, 119461, 'VITORIA ROSA CAMPOS', 81.00, 45.00, 25.50, 106.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(347, 17, 121788, 'PÁBULO HENRIQUE SIMILLI DA SILVA', 82.00, 45.00, 24.50, 106.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(348, 18, 111285, 'ANTÔNIO DAVI DE MARINHO SOUSA', 85.00, 45.00, 21.50, 106.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(349, 19, 125377, 'MICHELE PEREIRA DA SILVA', 82.00, 42.00, 24.50, 106.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(350, 20, 63748, 'BRUNO DA SILVA PEREIRA', 80.00, 45.00, 26.00, 106.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(351, 21, 107256, 'LEONARDO SENA DE ALMEIDA', 82.00, 45.00, 24.00, 106.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(352, 22, 110795, 'MATHEUS RIBEIRO SOUTO OLIVEIRA', 78.00, 42.00, 27.50, 105.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(353, 23, 96598, 'THAISA RIBEIRO DE OLIVEIRA', 80.00, 42.00, 25.00, 105.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(354, 24, 10815, 'CRISTINO ALVES DAMASCENO', 84.00, 48.00, 20.50, 104.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(355, 25, 118688, 'EMANUEL SILVA DE ABREU', 81.00, 45.00, 23.50, 104.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(356, 26, 119120, 'GEBES VANDERLEI PARENTE SANTOS', 81.00, 42.00, 23.50, 104.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(357, 27, 60162, 'ÍCARO ARRUDA FREIRE DE SOUZA', 82.00, 42.00, 22.50, 104.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(358, 28, 62217, 'BÁRBARA PONCIANO LIMA DIAS', 80.00, 39.00, 24.50, 104.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(359, 29, 125917, 'JESSICA LOPES OLIVEIRA', 78.00, 45.00, 26.00, 104.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(360, 30, 9996, 'HENNYD YURI CARVALHO DA SILVA', 82.00, 48.00, 21.00, 103.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(361, 31, 88454, 'SOLANGE VENÂNCIO MILANI', 78.00, 45.00, 24.50, 102.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(362, 32, 1318, 'POLIANA LUCENA DOS SANTOS', 79.00, 39.00, 23.50, 102.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(363, 33, 62607, 'JOÃO FÁBIO DE FREITAS BRANDÃO', 79.00, 42.00, 23.00, 102.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(364, 34, 98933, 'JANDERSON DE CASTRO E SILVA', 82.00, 48.00, 19.50, 101.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(365, 35, 111722, 'VILENA MARJANA BEZERRA PEREIRA', 80.00, 42.00, 20.00, 100.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(366, 36, 2402, 'SEVERINO CASE DOS SANTOS', 80.00, 51.00, 19.50, 99.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(367, 37, 96619, 'MIQUÉIAS EMANUEL SOUZA LACERDA', 82.00, 45.00, 16.00, 98.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(368, 38, 125235, 'DHANRLEY GOMES DE OLIVEIRA', 78.00, 42.00, 20.00, 98.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(369, 39, 84704, 'SHELDA MARLICE FERNANDES DA SILVA', 78.00, 48.00, 19.50, 97.50, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(370, 40, 121440, 'ALICE CRISTINE CORTEZ DE BARROS SANTOS', 78.00, 39.00, 19.00, 97.00, 'LISTA DE ESPERA', '2017', 8, 6, 6),
(371, 1, 120772, 'MARCELO EDUARDO RAUBER', 90.00, 45.00, 28.00, 118.00, 'APROVADO', '2017', 10, 6, 6),
(372, 2, 99135, 'GABRIEL MARIUSSO SCIOTTI PINTO DA SILVA', 87.00, 45.00, 27.00, 114.00, 'APROVADO', '2017', 10, 6, 6),
(373, 3, 98857, 'TÁRCIO HENRIQUE MARTINS PIMENTEL', 86.00, 42.00, 24.50, 110.50, 'APROVADO', '2017', 10, 6, 6),
(374, 4, 121702, 'YANKA COSTA CARVALHO', 85.00, 48.00, 24.00, 109.00, 'LISTA DE ESPERA', '2017', 10, 6, 6),
(375, 5, 123798, 'ANA LAURA SOUZA DE BARROS', 82.00, 42.00, 22.00, 104.00, 'LISTA DE ESPERA', '2017', 10, 6, 6),
(376, 6, 118584, 'GABRIELLE DE FREITAS NOGUEIRA', 79.00, 39.00, 24.00, 103.00, 'LISTA DE ESPERA', '2017', 10, 6, 6),
(377, 7, 99359, 'LUIZ GABRIEL RAMOS DE SOUSA', 81.00, 45.00, 21.00, 102.00, 'LISTA DE ESPERA', '2017', 10, 6, 6),
(378, 8, 125330, 'KAIQUE LOPES BACELAR', 82.00, 51.00, 19.00, 101.00, 'LISTA DE ESPERA', '2017', 10, 6, 6),
(379, 9, 89128, 'ROGER DUMAS AFONSO AZULAY', 75.00, 42.00, 20.00, 95.00, 'LISTA DE ESPERA', '2017', 10, 6, 6),
(380, 10, 108254, 'KARINA CRISTINA CARVALHO DOS SANTOS', 75.00, 39.00, 14.00, 89.00, 'LISTA DE ESPERA', '2017', 10, 6, 6),
(381, 1, 93523, 'JOÃO PEDRO SOARES DE MACEDO', 94.00, 45.00, 28.00, 122.00, 'APROVADO', '2017', 1, 6, 6),
(382, 2, 110619, 'MATHEUS TELES ROSA', 82.00, 42.00, 23.50, 105.50, 'APROVADO', '2017', 1, 6, 6),
(383, 3, 96937, 'ANTONIO BRENO SILVA GOMES', 74.00, 36.00, 23.50, 97.50, 'APROVADO', '2017', 1, 6, 6),
(384, 4, 93376, 'PEDRO HENRIQUE PEREIRA LUCENA', 72.00, 42.00, 22.00, 94.00, 'APROVADO', '2017', 1, 6, 6),
(385, 5, 86578, 'CARLA HART BORGES DA SILVA', 72.00, 36.00, 21.50, 93.50, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(386, 6, 124762, 'CAIO MENDONCA DE SOUSA', 69.00, 36.00, 23.50, 92.50, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(387, 7, 118471, 'WANESSA CANDIDA DE PAULA', 70.00, 33.00, 22.50, 92.50, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(388, 8, 110425, 'THAIS LIMA TEIXEIRA', 65.00, 36.00, 25.00, 90.00, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(389, 9, 118479, 'GABRIELLA SERRÃO ABREU CONCEIÇÃO', 66.00, 36.00, 22.50, 88.50, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(390, 10, 118528, 'SEMIRA URIEL JALES DE ALMEIDA', 69.00, 36.00, 18.50, 87.50, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(391, 11, 123765, 'FELIPE BARROS GONZÁLEZ CORDEIRO', 69.00, 33.00, 16.50, 85.50, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(392, 12, 97139, 'ANA CAROLINA GADELHA RIBEIRO', 65.00, 36.00, 18.00, 83.00, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(393, 13, 46684, 'DANIEL SANTOS CARVALHO', 67.00, 36.00, 15.00, 82.00, 'LISTA DE ESPERA', '2017', 1, 6, 6),
(394, 1, 35892, 'TULIO MARROQUIM GALVÃO', 95.00, 0.00, 30.00, 125.00, 'APROVADO', '2016', 2, 6, 5),
(395, 2, 43450, 'MICHELLY GAMA SAMPAIO DA SILVA', 95.00, 0.00, 29.50, 124.50, 'APROVADO', '2016', 2, 6, 5),
(396, 3, 110307, 'TANIA RAMCHANDANI', 97.00, 0.00, 27.00, 124.00, 'APROVADO', '2016', 2, 6, 5),
(397, 4, 83906, 'GABRIEL MELO ALEXANDRE SILVA', 97.00, 0.00, 27.00, 124.00, 'APROVADO', '2016', 2, 6, 5),
(398, 5, 86742, 'GEOVANNA FERREIRA SILVA', 95.00, 0.00, 28.50, 123.50, 'APROVADO', '2016', 2, 6, 5),
(399, 6, 61588, 'THÁLES DE SOUZA ISRAEL', 97.00, 0.00, 26.50, 123.50, 'APROVADO', '2016', 2, 6, 5),
(400, 7, 88341, 'PEDRO HENRIQUE SILVA FERNANDES', 95.00, 0.00, 28.50, 123.50, 'APROVADO', '2016', 2, 6, 5),
(401, 8, 111543, 'JOÃO VICTOR SATRAPA SILVA', 96.00, 0.00, 27.00, 123.00, 'APROVADO', '2016', 2, 6, 5),
(402, 9, 110814, 'RUAN ALENCAR LOURENCO', 92.00, 0.00, 30.00, 122.00, 'APROVADO', '2016', 2, 6, 5),
(403, 10, 4924, 'HERBERT IAGO FEITOSA DA FONSECA', 94.00, 0.00, 28.00, 122.00, 'APROVADO', '2016', 2, 6, 5),
(404, 11, 59517, 'DOMINIK CASTRO DE ARAÚJO', 93.00, 0.00, 28.50, 121.50, 'APROVADO', '2016', 2, 6, 5),
(405, 12, 109492, 'KAROLAINE LIMA SOUZA', 90.00, 0.00, 30.00, 120.00, 'APROVADO', '2016', 2, 6, 5),
(406, 13, 108556, 'MATHEUS LUCAS DA SILVA SANTANA', 92.00, 0.00, 28.00, 120.00, 'APROVADO', '2016', 2, 6, 5),
(407, 14, 11804, 'KIM TAVARES MESQUITA', 92.00, 0.00, 27.00, 119.00, 'APROVADO', '2016', 2, 6, 5),
(408, 15, 109084, 'BEATRIZ BARBOSA TEIXEIRA', 93.00, 0.00, 26.00, 119.00, 'APROVADO', '2016', 2, 6, 5),
(409, 16, 105912, 'LUCAS EDUARDO THOMAZ MÁRQUEZ', 96.00, 0.00, 23.00, 119.00, 'APROVADO', '2016', 2, 6, 5),
(410, 17, 107663, 'DYANDRA DOS SANTOS PORTO', 92.00, 0.00, 27.00, 119.00, 'APROVADO', '2016', 2, 6, 5),
(411, 18, 87551, 'JULIANA LARISSA LAURIANO RAMOS', 89.00, 0.00, 30.00, 119.00, 'APROVADO', '2016', 2, 6, 5),
(412, 19, 108923, 'AUDREY STELLA AKEMI NOGAMI', 92.00, 0.00, 27.00, 119.00, 'APROVADO', '2016', 2, 6, 5),
(413, 20, 83980, 'ANA KARLA DE SOUSA BATISTA', 89.00, 0.00, 29.50, 118.50, 'APROVADO', '2016', 2, 6, 5),
(414, 21, 3938, 'IGOR DA SILVA VASCONCELOS', 92.00, 0.00, 26.50, 118.50, 'APROVADO', '2016', 2, 6, 5),
(415, 22, 40303, 'FABIANE MARINHO BRITO DE OLIVEIRA', 92.00, 0.00, 26.00, 118.00, 'APROVADO', '2016', 2, 6, 5),
(416, 23, 85490, 'TEONILDO SOARES TEIXEIRA FILHO', 90.00, 0.00, 28.00, 118.00, 'APROVADO', '2016', 2, 6, 5),
(417, 24, 67103, 'LARISSA SOARES CARDOSO', 90.00, 0.00, 28.00, 118.00, 'APROVADO', '2016', 2, 6, 5),
(418, 25, 110189, 'MARYANA SOUSA TOMAS PEREIRA', 90.00, 0.00, 27.50, 117.50, 'APROVADO', '2016', 2, 6, 5),
(419, 26, 60698, 'ROSA MARIA DE OLIVEIRA GALVÃO DA COSTA', 93.00, 0.00, 24.50, 117.50, 'APROVADO', '2016', 2, 6, 5),
(420, 27, 36166, 'RAMON FIGUEIRA PINTO', 92.00, 0.00, 25.00, 117.00, 'APROVADO', '2016', 2, 6, 5),
(421, 28, 85012, 'ÍTALLO DE SOUZA ALMEIDA', 90.00, 0.00, 27.00, 117.00, 'APROVADO', '2016', 2, 6, 5),
(422, 29, 35894, 'RODRIGO MARROQUIM GALVÃO', 89.00, 0.00, 28.00, 117.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(423, 30, 66166, 'TAMIE OLIVEIRA TIMOTEO', 89.00, 0.00, 27.50, 116.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(424, 31, 106526, 'IGOR DOS SANTOS COSTA', 90.00, 0.00, 26.50, 116.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(425, 32, 40074, 'SUED SOARES LIMA', 93.00, 0.00, 23.50, 116.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(426, 33, 97167, 'FRANKLIN FERREIRA REZENDE NETO', 97.00, 0.00, 19.50, 116.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(427, 34, 89194, 'SUZANI NAOMI HIGA', 94.00, 0.00, 22.00, 116.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(428, 35, 97373, 'GABRIEL PATRÍCIO SANTOS DE MEDEIROS', 88.00, 0.00, 27.50, 115.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(429, 36, 93178, 'LETÍCIA ROCHA', 90.00, 0.00, 25.50, 115.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(430, 37, 108660, 'GABRIEL PEREIRA GOMES', 90.00, 0.00, 25.50, 115.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(431, 38, 112469, 'MARIANA MANTOVANI MARCIANO', 91.00, 0.00, 24.00, 115.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(432, 39, 33264, 'MIRIAN ALEJANDRA TORRES CÁRDENAS', 89.00, 0.00, 26.00, 115.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(433, 40, 109038, 'CAROLINA BRAGA BORGES', 89.00, 0.00, 26.00, 115.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(434, 41, 111139, 'ALBERTO MAIA PATRICIO DE FIGUEIREDO JUNIO', 90.00, 0.00, 25.00, 115.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(435, 42, 111039, 'MARCOS BARROS DE SOUSA E SILVA', 90.00, 0.00, 25.00, 115.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(436, 43, 111588, 'LEANDRO MAQUINE NUNES GONCALVES', 96.00, 0.00, 18.50, 114.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(437, 44, 15889, 'GENIVAL SEBASTIÃO DA SILVA NETO', 93.00, 0.00, 21.50, 114.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(438, 45, 88622, 'PEDRO HENRIQUE DE OLIVEIRA', 90.00, 0.00, 24.00, 114.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(439, 46, 43625, 'ANA LUÍSA MENDES', 95.00, 0.00, 19.00, 114.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(440, 47, 5091, 'LUÍS FELIPE COÊLHO LEITE', 88.00, 0.00, 26.00, 114.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(441, 48, 93839, 'RODRIGO PINHEIRO WILKENS MARINHO', 89.00, 0.00, 25.00, 114.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(442, 49, 66571, 'TIAGO DE LIMA RODRÍGUEZ', 90.00, 0.00, 24.00, 114.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(443, 50, 36999, 'ARIEL DE SÁ RORIZ RIBEIRO', 88.00, 0.00, 25.50, 113.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(444, 51, 110472, 'EMÍLIA FARIAS MONTENEGRO GOUVEIA', 89.00, 0.00, 24.50, 113.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(445, 52, 93280, 'MARCOS LAÉRCIO RABELO SIQUEIRA', 90.00, 0.00, 23.50, 113.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(446, 53, 110289, 'ANA CLARA DOS SANTOS ALVES', 91.00, 0.00, 22.50, 113.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(447, 54, 88417, 'GABRIEL FERREIRA RODRIGUES', 88.00, 0.00, 25.50, 113.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(448, 55, 14752, 'ANTONIO SALGADO ARAGÃO NETO', 90.00, 0.00, 23.50, 113.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(449, 56, 112091, 'GABRIEL GIMENEZ PORTO DE OLIVEIRA', 92.00, 0.00, 21.50, 113.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(450, 57, 34530, 'VALMIR ANDRÉ PECCINI', 90.00, 0.00, 23.00, 113.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(451, 58, 6578, 'YAGO CHAVES DOS SANTOS AGUIAR', 91.00, 0.00, 22.00, 113.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(452, 59, 109062, 'VANESSA OLIVEIRA REZENDE SANT ANA', 90.00, 0.00, 23.00, 113.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(453, 60, 86022, 'LIZANDRA CUNHA DE CARVALHO', 88.00, 0.00, 24.50, 112.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(454, 61, 65567, 'BRUNA MESSIAS JACQUES DE MORAES', 88.00, 0.00, 24.50, 112.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(455, 62, 105052, 'PAULO VITOR LIMA ABREU', 89.00, 0.00, 23.50, 112.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(456, 63, 98517, 'BRUNA DE PAULA', 90.00, 0.00, 22.50, 112.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(457, 64, 106270, 'GABRIEL PEDROSO BASTOS', 90.00, 0.00, 22.50, 112.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(458, 65, 99407, 'MARCELO CUSTODIO LOPES', 91.00, 0.00, 21.00, 112.00, 'LISTA DE ESPERA', '2016', 2, 6, 5);
INSERT INTO `tb_resultado_final` (`id`, `ordem`, `inscricao`, `nome`, `objetiva`, `especificas`, `redacao`, `total`, `situacao`, `ano`, `cota_id`, `curso_id`, `edital_id`) VALUES
(459, 66, 100068, 'RAMON MOREIRA GOMES DE SOUSA', 91.00, 0.00, 21.00, 112.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(460, 67, 62980, 'DANIEL FERREIRA OESTREICHER', 91.00, 0.00, 21.00, 112.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(461, 68, 89716, 'FRANCISCO RENAN FERREIRA DE SOUSA', 89.00, 0.00, 23.00, 112.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(462, 69, 97768, 'RICARDO MARQUES DE LIMA JUNIOR', 90.00, 0.00, 21.00, 111.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(463, 70, 85243, 'HUGO RAMOS DOMINGOS', 91.00, 0.00, 19.50, 110.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(464, 71, 110993, 'VICTOR BRAGA BARBOSA', 91.00, 0.00, 19.00, 110.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(465, 72, 110202, 'LUCAS ARAUJO DE SOUSA', 98.00, 0.00, 12.00, 110.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(466, 73, 33674, 'ANA VITORIA BEZERRA MARQUES', 91.00, 0.00, 18.50, 109.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(467, 74, 85411, 'RAMYRES CAROLAYNNE SOUSA LOPES SILVA', 89.00, 0.00, 20.50, 109.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(468, 75, 60958, 'LUIZ FELIPE SOARES DA SILVA', 91.00, 0.00, 18.00, 109.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(469, 76, 111347, 'MATHEUS PINHO NAKASHIMA DE MELO', 90.00, 0.00, 19.00, 109.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(470, 77, 112492, 'ANDRESSA MORAIS COSTA', 90.00, 0.00, 18.50, 108.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(471, 78, 108721, 'BEATRIZ DE SOUZA CALVOSO', 89.00, 0.00, 18.00, 107.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(472, 79, 111719, 'ALGENOR MARIA DA COSTA TEIXEIRA NETO', 90.00, 0.00, 17.00, 107.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(473, 80, 84776, 'GABRIELA MARIA MÜLLER', 91.00, 0.00, 16.00, 107.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(474, 81, 7909, 'KARLA CRISTIANY GOMES DE OLIVEIRA', 89.00, 0.00, 16.00, 105.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(475, 82, 33336, 'JOSÉ JACKSON DA SILVA LUCENA SANTANA', 90.00, 0.00, 15.00, 105.00, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(476, 83, 111650, 'ANGELA SARAH GOMES SEVERIANO', 88.00, 0.00, 16.50, 104.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(477, 84, 107480, 'ADOLFO DE SOUZA PASSAMANI', 89.00, 0.00, 11.50, 100.50, 'LISTA DE ESPERA', '2016', 2, 6, 5),
(478, 1, 83944, 'RAYLSON ARAÚJO MONTENEGRO', 93.00, 0.00, 24.50, 117.50, 'APROVADO', '2016', 4, 6, 5),
(479, 2, 9095, 'REJANE AGUIAR MAGALHÃES', 90.00, 0.00, 27.00, 117.00, 'APROVADO', '2016', 4, 6, 5),
(480, 3, 64603, 'GESSICA YANNE BRASIL VIEIRA', 88.00, 0.00, 28.50, 116.50, 'APROVADO', '2016', 4, 6, 5),
(481, 4, 89327, 'MAIARA RODRIGUES RUBIM', 86.00, 0.00, 26.50, 112.50, 'APROVADO', '2016', 4, 6, 5),
(482, 5, 14396, 'ANA CÁSSIA SILVA OLIVEIRA', 87.00, 0.00, 23.00, 110.00, 'APROVADO', '2016', 4, 6, 5),
(483, 6, 109100, 'RENAN DA SILVA BENTES', 87.00, 0.00, 22.00, 109.00, 'APROVADO', '2016', 4, 6, 5),
(484, 7, 59618, 'INGRID THAÍS DE OLIVEIRA SILVA', 82.00, 0.00, 27.00, 109.00, 'APROVADO', '2016', 4, 6, 5),
(485, 8, 86153, 'LAÉRCIO FERREIRA ARAÚJO', 79.00, 0.00, 28.50, 107.50, 'APROVADO', '2016', 4, 6, 5),
(486, 9, 63321, 'RAIANE DIAS DE SOUZA', 86.00, 0.00, 21.00, 107.00, 'APROVADO', '2016', 4, 6, 5),
(487, 10, 111031, 'NATHALIA BITTENCOURT GRACIANO', 77.00, 0.00, 30.00, 107.00, 'APROVADO', '2016', 4, 6, 5),
(488, 11, 83877, 'CLAUDIA DOS PASSOS FARIAS', 87.00, 0.00, 19.50, 106.50, 'APROVADO', '2016', 4, 6, 5),
(489, 12, 108561, 'TOMAZ CERDEIRA CHAVES NETO', 83.00, 0.00, 23.50, 106.50, 'APROVADO', '2016', 4, 6, 5),
(490, 13, 97769, 'RONNY HELSON DE SOUZA ALVES', 84.00, 0.00, 22.00, 106.00, 'APROVADO', '2016', 4, 6, 5),
(491, 14, 40327, 'PABLO ANDRE BRITO DE SOUZA', 78.00, 0.00, 28.00, 106.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(492, 15, 108880, 'ALINE COSTA MACEDO MENEZES EVANGELISTA', 88.00, 0.00, 16.00, 104.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(493, 16, 43260, 'MICHELLE VANESSA SANTIAGO FRANCO', 82.00, 0.00, 21.50, 103.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(494, 17, 39853, 'LEANDRO OLIVEIRA SAMPAIO', 83.00, 0.00, 20.50, 103.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(495, 18, 84156, 'RODRIGO PINHEIRO DE SOUZA', 77.00, 0.00, 26.50, 103.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(496, 19, 110213, 'ADNA ABIGAIL DA COSTA SILVA', 77.00, 0.00, 26.00, 103.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(497, 20, 42719, 'MARIANA BRILHANTE SANTOS DE SOUZA CRUZ', 77.00, 0.00, 26.00, 103.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(498, 21, 93705, 'FELIPE ROMANO SEIXO', 79.00, 0.00, 24.00, 103.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(499, 22, 110937, 'BRENDA DE OLIVEIRA SANTA ROSA', 83.00, 0.00, 19.00, 102.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(500, 23, 98895, 'KEILA SANTANA DO NASCIMENTO', 77.00, 0.00, 24.00, 101.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(501, 24, 87196, 'WILLIANE CASTRO DA CRUZ', 77.00, 0.00, 24.00, 101.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(502, 25, 59675, 'ALEXANDRE SOUZA DOS SANTOS', 79.00, 0.00, 21.00, 100.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(503, 26, 60574, 'GEOVANE SOUZA PEREIRA', 77.00, 0.00, 22.50, 99.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(504, 27, 2185, 'LORENA SIMONE GOVEIA', 79.00, 0.00, 20.50, 99.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(505, 28, 2624, 'RAPHAEL BARROS ROCHA', 78.00, 0.00, 21.50, 99.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(506, 29, 111329, 'ALEX MORAES DO NASCIMENTO JUNIOR', 77.00, 0.00, 21.50, 98.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(507, 30, 86570, 'SILWANNA PEREIRA COSTA', 79.00, 0.00, 19.00, 98.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(508, 31, 15600, 'KEYLA SOUSA SILVA', 77.00, 0.00, 20.50, 97.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(509, 32, 112320, 'GILSON LOPES DE OLIVEIRA JUNIOR', 77.00, 0.00, 20.00, 97.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(510, 33, 38260, 'DIENY KETHANY DA SILVA GOMES', 79.00, 0.00, 18.00, 97.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(511, 34, 106557, 'MATHEUS DA SILVA SAKAMOTO', 77.00, 0.00, 19.00, 96.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(512, 35, 37974, 'HUDSON FARIAS TRAJANO', 82.00, 0.00, 13.50, 95.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(513, 36, 61688, 'CAMILA SAMPAIO FLORENÇA SANTANA', 76.00, 0.00, 17.50, 93.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(514, 37, 64753, 'BRYAN GIUSSEPPE JARAMILLO CARDENAS', 77.00, 0.00, 16.50, 93.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(515, 38, 89420, 'DANIEL FERNANDES', 79.00, 0.00, 14.00, 93.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(516, 39, 97207, 'DHARA MARTINS DE SOUZA', 80.00, 0.00, 13.00, 93.00, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(517, 40, 64107, 'JOSE MATEUS OLIVEIRA MARIANO', 76.00, 0.00, 16.50, 92.50, 'LISTA DE ESPERA', '2016', 4, 6, 5),
(518, 1, 8444, 'TATIELY RODRIGUES MARTINS', 88.00, 0.00, 29.00, 117.00, 'APROVADO', '2016', 6, 6, 5),
(519, 2, 108568, 'CAMILA ALVES DO AMARAL SILVA', 84.00, 0.00, 27.50, 111.50, 'APROVADO', '2016', 6, 6, 5),
(520, 3, 60805, 'GABRIELLY LETICIA SOARES FERREIRA', 84.00, 0.00, 20.50, 104.50, 'APROVADO', '2016', 6, 6, 5),
(521, 4, 110725, 'ALEXANDRE APOLO SILVA COELHO', 77.00, 0.00, 26.50, 103.50, 'LISTA DE ESPERA', '2016', 6, 6, 5),
(522, 5, 38115, 'DRIELY PINTO TORREIAS', 80.00, 0.00, 23.00, 103.00, 'LISTA DE ESPERA', '2016', 6, 6, 5),
(523, 6, 3940, 'SABRINA ARAUJO RAMOS', 83.00, 0.00, 20.00, 103.00, 'LISTA DE ESPERA', '2016', 6, 6, 5),
(524, 7, 12371, 'VINÍCIUS SANTOS CRUZ', 76.00, 0.00, 22.00, 98.00, 'LISTA DE ESPERA', '2016', 6, 6, 5),
(525, 8, 37953, 'LACY CARVALHO FALCÃO', 75.00, 0.00, 22.50, 97.50, 'LISTA DE ESPERA', '2016', 6, 6, 5),
(526, 9, 97810, 'ALBERTO BORGES MOREIRA', 75.00, 0.00, 18.00, 93.00, 'LISTA DE ESPERA', '2016', 6, 6, 5),
(527, 1, 11716, 'DIEGO ERNANDES BARBOSA GUIMARÃES', 96.00, 0.00, 23.00, 119.00, 'APROVADO', '2016', 8, 6, 5),
(528, 2, 38105, 'ÁUREA SÉRGIA DA SILVA MACÊDO', 91.00, 0.00, 24.50, 115.50, 'APROVADO', '2016', 8, 6, 5),
(529, 3, 32519, 'KEMILY DE ALMEIDA LIMA', 89.00, 0.00, 26.00, 115.00, 'APROVADO', '2016', 8, 6, 5),
(530, 4, 84009, 'LUIZE LOPES SALAZAR', 90.00, 0.00, 22.00, 112.00, 'APROVADO', '2016', 8, 6, 5),
(531, 5, 35671, 'OHANA DE OLIVEIRA SOUZA', 90.00, 0.00, 21.50, 111.50, 'APROVADO', '2016', 8, 6, 5),
(532, 6, 34134, 'SUENIA MANDUCA RODRIGUES', 89.00, 0.00, 22.00, 111.00, 'APROVADO', '2016', 8, 6, 5),
(533, 7, 105099, 'THAIS LAVAREDA NASCIMENTO', 83.00, 0.00, 28.00, 111.00, 'APROVADO', '2016', 8, 6, 5),
(534, 8, 83042, 'ANA CAROLINA DORNELLES POERSCHKE', 87.00, 0.00, 23.50, 110.50, 'APROVADO', '2016', 8, 6, 5),
(535, 9, 85810, 'BRUNA OLIVEIRA ARAÚJO', 92.00, 0.00, 17.50, 109.50, 'APROVADO', '2016', 8, 6, 5),
(536, 10, 61675, 'LOURIVAL LUCAS RIBEIRO BALMANTE', 87.00, 0.00, 22.50, 109.50, 'APROVADO', '2016', 8, 6, 5),
(537, 11, 83570, 'NICOLE LIMA DE ANDRADE', 86.00, 0.00, 23.50, 109.50, 'APROVADO', '2016', 8, 6, 5),
(538, 12, 97300, 'PEDRO HENRIQUE BRITO FRANCISCO', 88.00, 0.00, 21.00, 109.00, 'APROVADO', '2016', 8, 6, 5),
(539, 13, 110886, 'EDUARDO VIDAL DA MOTA SANTOS', 82.00, 0.00, 27.00, 109.00, 'APROVADO', '2016', 8, 6, 5),
(540, 14, 97826, 'VIVALDO LOGRADO JUNIOR', 92.00, 0.00, 17.00, 109.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(541, 15, 81868, 'RAMON FILIPE MARTINS', 88.00, 0.00, 21.00, 109.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(542, 16, 97991, 'THAMYREZ QUEZIA DE ASSIS', 83.00, 0.00, 26.00, 109.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(543, 17, 84589, 'JHENNIFER DO NASCIMENTO PEREIRA', 88.00, 0.00, 20.50, 108.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(544, 18, 40148, 'RAIMUNDO SILVA LOURENÇO', 85.00, 0.00, 23.50, 108.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(545, 19, 59716, 'CIBELE LOUSANE PINHO MOTA', 87.00, 0.00, 21.50, 108.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(546, 20, 89128, 'ROGER DUMAS AFONSO AZULAY', 89.00, 0.00, 18.50, 107.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(547, 21, 110704, 'THAYNÁ VATTIMO CARBALHEDA DA SILVA', 82.00, 0.00, 25.50, 107.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(548, 22, 1618, 'YASMIN DE FREITAS SANTOS', 86.00, 0.00, 21.00, 107.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(549, 23, 60628, 'RAILANE DINIZ FARIAS', 86.00, 0.00, 21.00, 107.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(550, 24, 37540, 'STEFANNY FERREIRA GOMES', 87.00, 0.00, 19.50, 106.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(551, 25, 84377, 'IGOR OLIVEIRA DA SILVA', 82.00, 0.00, 24.50, 106.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(552, 26, 4711, 'MARYCASSIELY RODRIGUES TIZOLIM', 83.00, 0.00, 23.00, 106.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(553, 27, 64840, 'DANIEL ROSA CORREA LEAL', 93.00, 0.00, 13.00, 106.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(554, 28, 47635, 'KAMILA KENDRA MAR MARQUES', 81.00, 0.00, 24.50, 105.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(555, 29, 64199, 'CARLA MARIANA DE MELO BEECK', 81.00, 0.00, 24.50, 105.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(556, 30, 60162, 'ÍCARO ARRUDA FREIRE DE SOUZA', 86.00, 0.00, 18.50, 104.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(557, 31, 9017, 'MAIKIA ADINAIARA DE SOUZA ARAUJO', 81.00, 0.00, 23.00, 104.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(558, 32, 62474, 'LUCAS OLIVEIRA ANDRE MAGALHAES', 83.00, 0.00, 19.50, 102.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(559, 33, 10815, 'CRISTINO ALVES DAMASCENO', 84.00, 0.00, 18.50, 102.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(560, 34, 60993, 'DIEGO HENRIQUE DE OLIVEIRA LIMA BERNARDO', 82.00, 0.00, 19.00, 101.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(561, 35, 63748, 'BRUNO DA SILVA PEREIRA', 82.00, 0.00, 17.00, 99.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(562, 36, 39726, 'LUIS HENRIQUE SILVA DE JESUS', 83.00, 0.00, 16.00, 99.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(563, 37, 32571, 'ALBANO CASTRO DE ALBUQUERQUE JUNIOR', 81.00, 0.00, 17.00, 98.00, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(564, 38, 94890, 'BEATRIZ DE SOUZA CARDOSO', 85.00, 0.00, 11.50, 96.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(565, 39, 63890, 'CARLOS EDUARDO DOS SANTOS MELO', 80.00, 0.00, 15.50, 95.50, 'LISTA DE ESPERA', '2016', 8, 6, 5),
(566, 1, 106608, 'BRUNA DELLATORRE DINIZ', 95.00, 0.00, 26.50, 121.50, 'APROVADO', '2016', 10, 6, 5),
(567, 2, 97488, 'ROMUALDO DE FREITAS RUIZ FILHO', 96.00, 0.00, 25.00, 121.00, 'APROVADO', '2016', 10, 6, 5),
(568, 3, 60646, 'MARIA CAROLINA FERREIRA CHAN', 90.00, 0.00, 28.50, 118.50, 'APROVADO', '2016', 10, 6, 5),
(569, 4, 95028, 'TAYENNE FIGUEIREDO BENTES', 88.00, 0.00, 27.00, 115.00, 'LISTA DE ESPERA', '2016', 10, 6, 5),
(570, 5, 75829, 'LUANA MAYSA PECCINI', 90.00, 0.00, 24.00, 114.00, 'LISTA DE ESPERA', '2016', 10, 6, 5),
(571, 6, 98857, 'TÁRCIO HENRIQUE MARTINS PIMENTEL', 87.00, 0.00, 25.50, 112.50, 'LISTA DE ESPERA', '2016', 10, 6, 5),
(572, 7, 85893, 'JÚLIO CESAR PINHEIRO DE MENEZES FILHO', 92.00, 0.00, 18.00, 110.00, 'LISTA DE ESPERA', '2016', 10, 6, 5),
(573, 8, 4757, 'ANDERSON ADEMIR KUKLINSKI', 91.00, 0.00, 18.50, 109.50, 'LISTA DE ESPERA', '2016', 10, 6, 5),
(574, 9, 87956, 'HILTON LUIZ SEVERO DE ALMEIDA', 88.00, 0.00, 17.50, 105.50, 'LISTA DE ESPERA', '2016', 10, 6, 5),
(575, 1, 85802, 'BRUNO KRAUSPENHAR TEIXEIRA', 92.00, 0.00, 27.50, 119.50, 'APROVADO', '2016', 1, 6, 5),
(576, 2, 95041, 'MATHEUS MYCHAEL MAZZARO CONCHY', 77.00, 0.00, 19.50, 96.50, 'APROVADO', '2016', 1, 6, 5),
(577, 3, 37277, 'LUCAS NILSON LIMA DOS SANTOS', 79.00, 0.00, 16.50, 95.50, 'APROVADO', '2016', 1, 6, 5),
(578, 4, 108360, 'MARCOS FAGUNDES LEITE GRANJEIRO', 78.00, 0.00, 17.50, 95.50, 'APROVADO', '2016', 1, 6, 5),
(579, 5, 41562, 'JONATHAN PEREIRA SILVA', 68.00, 0.00, 20.00, 88.00, 'LISTA DE ESPERA', '2016', 1, 6, 5),
(580, 6, 46684, 'DANIEL SANTOS CARVALHO', 67.00, 0.00, 20.00, 87.00, 'LISTA DE ESPERA', '2016', 1, 6, 5),
(581, 7, 97139, 'ANA CAROLINA GADELHA RIBEIRO', 64.00, 0.00, 23.00, 87.00, 'LISTA DE ESPERA', '2016', 1, 6, 5),
(582, 8, 109322, 'DIVINO SILVA MARQUES JÚNIOR', 65.00, 0.00, 18.50, 83.50, 'LISTA DE ESPERA', '2016', 1, 6, 5),
(583, 9, 108842, 'JOSIANE KALÉCIA CHAVEZ CRUZ', 62.00, 0.00, 21.00, 83.00, 'LISTA DE ESPERA', '2016', 1, 6, 5),
(584, 10, 86899, 'PATRÍCIA FERNANDES VIEIRA', 61.00, 0.00, 19.50, 80.50, 'LISTA DE ESPERA', '2016', 1, 6, 5),
(585, 11, 67582, 'ANGELO LIMA SILVA', 67.00, 0.00, 13.00, 80.00, 'LISTA DE ESPERA', '2016', 1, 6, 5),
(586, 12, 93376, 'PEDRO HENRIQUE PEREIRA LUCENA', 65.00, 0.00, 11.50, 76.50, 'LISTA DE ESPERA', '2016', 1, 6, 5),
(587, 1, 10425, 'FRANK SILAS SALDANHA MARQUES', 89.00, 0.00, 27.50, 116.50, 'APROVADO', '2015', 2, 6, 4),
(588, 2, 88508, 'NAYARA RAFAELA SAMPAIO BARBOSA', 93.00, 0.00, 22.00, 115.00, 'APROVADO', '2015', 2, 6, 4),
(589, 3, 780, 'STEFFI FERREIRA BUTTENBENDER', 93.00, 0.00, 21.00, 114.00, 'APROVADO', '2015', 2, 6, 4),
(590, 4, 93667, 'DANIEL LOPES COSTA', 96.00, 0.00, 18.00, 114.00, 'APROVADO', '2015', 2, 6, 4),
(591, 5, 41635, 'BIANCA QUINTELLA RIBEIRO CORRÊA AMARO', 86.00, 0.00, 28.00, 114.00, 'APROVADO', '2015', 2, 6, 4),
(592, 6, 97888, 'VIVIANE HARUE HIGA', 86.00, 0.00, 28.00, 114.00, 'APROVADO', '2015', 2, 6, 4),
(593, 7, 96656, 'BRUNO RODRIGUES LOPES', 92.00, 0.00, 22.00, 114.00, 'APROVADO', '2015', 2, 6, 4),
(594, 8, 63831, 'STEPHANY PINA DA CUNHA NASCIMENTO MESQUITA', 94.00, 0.00, 19.50, 113.50, 'APROVADO', '2015', 2, 6, 4),
(595, 9, 98668, 'ANDREW GEORG WISCHNESKI', 92.00, 0.00, 21.00, 113.00, 'APROVADO', '2015', 2, 6, 4),
(596, 10, 35704, 'INDRA LICIANE NASCIMENTO DE FREITAS', 88.00, 0.00, 24.50, 112.50, 'APROVADO', '2015', 2, 6, 4),
(597, 11, 100669, 'JESSÉ DA COSTA CORRÊA FILHO', 95.00, 0.00, 17.50, 112.50, 'APROVADO', '2015', 2, 6, 4),
(598, 12, 4716, 'KARINA ANGÉLICA SOTO CHILLCCE', 93.00, 0.00, 19.50, 112.50, 'APROVADO', '2015', 2, 6, 4),
(599, 13, 40322, 'MATHEUS ARAUJO MOREIRA', 91.00, 0.00, 21.00, 112.00, 'APROVADO', '2015', 2, 6, 4),
(600, 14, 2389, 'CASSIA IASMIN DE SOUZA NASCIMENTO', 87.00, 0.00, 25.00, 112.00, 'APROVADO', '2015', 2, 6, 4),
(601, 15, 60437, 'MIRTES OKAWA ESSASHIKA DO NASCIMENTO', 91.00, 0.00, 21.00, 112.00, 'APROVADO', '2015', 2, 6, 4),
(602, 16, 61318, 'MIRIAN BEATRIZ GOMES DA SILVA', 84.00, 0.00, 28.00, 112.00, 'APROVADO', '2015', 2, 6, 4),
(603, 17, 87232, 'CAIO BRENNO ABREU', 86.00, 0.00, 26.00, 112.00, 'APROVADO', '2015', 2, 6, 4),
(604, 18, 62093, 'LUCAS GRANGEIRO FIN', 94.00, 0.00, 17.50, 111.50, 'APROVADO', '2015', 2, 6, 4),
(605, 19, 93360, 'FABIANNA FABIOLA NERI TEIXEIRA', 86.00, 0.00, 25.00, 111.00, 'APROVADO', '2015', 2, 6, 4),
(606, 20, 971, 'DANILO AUGUSTO VIDIGAL DE ANDRADE', 90.00, 0.00, 20.50, 110.50, 'APROVADO', '2015', 2, 6, 4),
(607, 21, 59793, 'OLYMPIO VITTOR ARCURIO FONSECA', 94.00, 0.00, 16.50, 110.50, 'APROVADO', '2015', 2, 6, 4),
(608, 22, 461, 'CHAYANNE CHRISTINI ALVES BEZERRA', 91.00, 0.00, 19.00, 110.00, 'APROVADO', '2015', 2, 6, 4),
(609, 23, 32644, 'DALET ZAINE FREITAS MUNIZ', 86.00, 0.00, 23.50, 109.50, 'APROVADO', '2015', 2, 6, 4),
(610, 24, 61592, 'TAMILLY EUNICE DA SILVA PACHECO', 88.00, 0.00, 21.00, 109.00, 'APROVADO', '2015', 2, 6, 4),
(611, 25, 60511, 'MIRYANNE SAMPAIO ESPER', 90.00, 0.00, 19.00, 109.00, 'APROVADO', '2015', 2, 6, 4),
(612, 26, 41689, 'JOSE LAERCIO DE ARAUJO FILHO', 89.00, 0.00, 20.00, 109.00, 'APROVADO', '2015', 2, 6, 4),
(613, 27, 64301, 'ROGÉRIO BATISTA MONTENEGRO', 92.00, 0.00, 17.00, 109.00, 'APROVADO', '2015', 2, 6, 4),
(614, 28, 61552, 'LUIZA REDIN FESTINALLI', 90.00, 0.00, 19.00, 109.00, 'APROVADO', '2015', 2, 6, 4),
(615, 29, 33002, 'RAFAELA NASCIMENTO LIMA', 87.00, 0.00, 22.00, 109.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(616, 30, 88495, 'NATHANAEL PHILIPE MENDONCA E SILVA', 88.00, 0.00, 21.00, 109.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(617, 31, 84952, 'NATÁLIA BATISTA DE LIMA E SILVA', 86.00, 0.00, 22.50, 108.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(618, 32, 96839, 'MILTON GOMES DO NASCIMENTO FILHO', 90.00, 0.00, 18.00, 108.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(619, 33, 96031, 'BRUNO BELIZÁRIO FONSECA', 86.00, 0.00, 22.00, 108.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(620, 34, 89194, 'SUZANI NAOMI HIGA', 90.00, 0.00, 18.00, 108.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(621, 35, 100877, 'JOSE DA SILVA JUNIOR', 83.00, 0.00, 24.50, 107.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(622, 36, 35841, 'WASHINGTON LUIZ AQUINO DE SOUZA JÚNIOR', 83.00, 0.00, 24.50, 107.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(623, 37, 7827, 'VALENTINA RYAN DE ALMEIDA LIMA', 86.00, 0.00, 21.00, 107.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(624, 38, 43712, 'LUISA SALOMÃO BARAÚNA BENTO', 88.00, 0.00, 19.00, 107.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(625, 39, 32423, 'YASMIN BASTOS SILVA GOMES', 85.00, 0.00, 22.00, 107.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(626, 40, 59655, 'BÁRBARA VASCONCELOS SANTOS', 86.00, 0.00, 20.50, 106.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(627, 41, 85172, 'SAMANTHA SANCHES DA CRUZ', 91.00, 0.00, 15.50, 106.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(628, 42, 59768, 'LAYLA CALAZANS MULLER', 85.00, 0.00, 21.50, 106.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(629, 43, 4924, 'HERBERT IAGO FEITOSA DA FONSECA', 88.00, 0.00, 18.50, 106.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(630, 44, 7809, 'ATHOS HIAGO DA SILVA OLIVEIRA', 90.00, 0.00, 16.50, 106.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(631, 45, 99530, 'FELIPE BRUNO GUALBERTO DE ARAGÃO', 90.00, 0.00, 16.50, 106.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(632, 46, 97472, 'GABRIEL MEDINA MONTE REY', 85.00, 0.00, 21.00, 106.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(633, 47, 35892, 'TULIO MARROQUIM GALVÃO', 89.00, 0.00, 17.00, 106.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(634, 48, 97768, 'RICARDO MARQUES DE LIMA JUNIOR', 91.00, 0.00, 14.50, 105.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(635, 49, 33009, 'SWAMINE DA SILVA GOMES', 85.00, 0.00, 20.50, 105.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(636, 50, 93178, 'LETÍCIA ROCHA', 85.00, 0.00, 20.50, 105.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(637, 51, 96882, 'CARLA BALENZUELA ANANIAS', 85.00, 0.00, 20.00, 105.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(638, 52, 33336, 'JOSÉ JACKSON DA SILVA LUCENA SANTANA', 89.00, 0.00, 16.00, 105.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(639, 53, 33683, 'LAYANE FERREIRA BALBINO', 85.00, 0.00, 20.00, 105.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(640, 54, 61346, 'HERCILIA ALBUQUERQUE GALVÃO DA COSTA', 87.00, 0.00, 17.50, 104.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(641, 55, 33460, 'EMILY PINHEIRO MORAIS', 89.00, 0.00, 15.00, 104.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(642, 56, 41474, 'JEFFERSON MARTINS DE LIMA', 87.00, 0.00, 17.00, 104.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(643, 57, 38295, 'MATEUS VASCONCELOS SIQUEIRA', 84.00, 0.00, 19.50, 103.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(644, 58, 14752, 'ANTONIO SALGADO ARAGÃO NETO', 87.00, 0.00, 16.50, 103.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(645, 59, 97816, 'GABRIELA PEREIRA SALLES', 86.00, 0.00, 17.00, 103.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(646, 60, 60472, 'JANAINA GOMES DA ROCHA', 87.00, 0.00, 16.00, 103.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(647, 61, 93280, 'MARCOS LAÉRCIO RABELO SIQUEIRA', 89.00, 0.00, 14.00, 103.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(648, 62, 100068, 'RAMON MOREIRA GOMES DE SOUSA', 86.00, 0.00, 16.50, 102.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(649, 63, 97167, 'FRANKLIN FERREIRA REZENDE NETO', 93.00, 0.00, 9.50, 102.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(650, 64, 15889, 'GENIVAL SEBASTIÃO DA SILVA NETO', 86.00, 0.00, 16.50, 102.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(651, 65, 43450, 'MICHELLY GAMA SAMPAIO DA SILVA', 84.00, 0.00, 18.00, 102.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(652, 66, 40074, 'SUED SOARES LIMA', 84.00, 0.00, 17.50, 101.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(653, 67, 100169, 'DANIEL SCHMITZ NUÑES', 90.00, 0.00, 11.50, 101.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(654, 68, 33272, 'THIAGO WILLIAN MOREIRA CAMPELO', 84.00, 0.00, 17.00, 101.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(655, 69, 93224, 'MIGUEL REBOUÇAS DE SOUSA', 85.00, 0.00, 16.00, 101.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(656, 70, 63849, 'FLAWBERTH LEUIS TAVARES BARBOSA DE SOUSA', 85.00, 0.00, 16.00, 101.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(657, 71, 99062, 'RODOLFO CARDOSO DUTRA DE ALENCAR', 88.00, 0.00, 12.50, 100.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(658, 72, 97383, 'ISABEL CRISTINA DE LIMA PIZA', 86.00, 0.00, 14.50, 100.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(659, 73, 60958, 'LUIZ FELIPE SOARES DA SILVA', 86.00, 0.00, 14.50, 100.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(660, 74, 525, 'ANA JACKELINE DE OLIVEIRA LOUZADA LOPES', 83.00, 0.00, 17.00, 100.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(661, 75, 65507, 'WERLEY DE OLIVEIRA E OLIVEIRA CRUZ', 86.00, 0.00, 14.00, 100.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(662, 76, 89716, 'FRANCISCO RENAN FERREIRA DE SOUSA', 87.00, 0.00, 13.00, 100.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(663, 77, 85202, 'LUCIANO CARVALHO DUDEK', 85.00, 0.00, 14.50, 99.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(664, 78, 98151, 'JULIANA ALENCAR DE ARRUDA CÂMARA', 87.00, 0.00, 12.00, 99.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(665, 79, 6578, 'YAGO CHAVES DOS SANTOS AGUIAR', 84.00, 0.00, 14.50, 98.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(666, 80, 59517, 'DOMINIK CASTRO DE ARAÚJO', 89.00, 0.00, 9.00, 98.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(667, 81, 97532, 'CASSIUS OLIVEIRA BARBOSA', 84.00, 0.00, 12.00, 96.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(668, 82, 32752, 'FAVIO ALEXANDRO ANDRADE DELGADO', 85.00, 0.00, 11.00, 96.00, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(669, 83, 11541, 'FRANCISCO LUIDI MOTA MARQUES DE PINHO', 84.00, 0.00, 11.50, 95.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(670, 84, 99088, 'DIOGO ANTÔNIO GIMENEZ DE BARROS', 84.00, 0.00, 10.50, 94.50, 'LISTA DE ESPERA', '2015', 2, 6, 4),
(671, 1, 63499, 'RICARDO DOS SANTOS MIRANDA', 100.00, 0.00, 23.00, 123.00, 'APROVADO', '2015', 4, 6, 4),
(672, 2, 33142, 'DMITRI RAVEL BARROSO ABREU', 90.00, 0.00, 19.50, 109.50, 'APROVADO', '2015', 4, 6, 4),
(673, 3, 83612, 'GILSKLEY DE OLIVEIRA COELHO', 89.00, 0.00, 17.50, 106.50, 'APROVADO', '2015', 4, 6, 4),
(674, 4, 39280, 'NATANAEL LEMOS DA CRUZ', 84.00, 0.00, 20.00, 104.00, 'APROVADO', '2015', 4, 6, 4),
(675, 5, 59903, 'ANTÔNIO LUCAS SÁGICA MARQUES', 86.00, 0.00, 17.00, 103.00, 'APROVADO', '2015', 4, 6, 4),
(676, 6, 89282, 'KAREN PATRÍCIA GUTIERREZ TURPO', 89.00, 0.00, 14.00, 103.00, 'APROVADO', '2015', 4, 6, 4),
(677, 7, 100597, 'DANIEL RODRIGUES DA SILVA', 83.00, 0.00, 19.00, 102.00, 'APROVADO', '2015', 4, 6, 4),
(678, 8, 35756, 'CARLOS HENRIQUE BATISTA FIGUEIREDO DE MENDONÇA', 85.00, 0.00, 17.00, 102.00, 'APROVADO', '2015', 4, 6, 4),
(679, 9, 85799, 'ALINY COSTA DA SILVA', 80.00, 0.00, 21.00, 101.00, 'APROVADO', '2015', 4, 6, 4),
(680, 10, 43382, 'TÂMARA OLIVEIRA VIEIRA', 81.00, 0.00, 18.50, 99.50, 'APROVADO', '2015', 4, 6, 4),
(681, 11, 97558, 'ANA KALINE SOUZA LOURENÇO', 76.00, 0.00, 23.50, 99.50, 'APROVADO', '2015', 4, 6, 4),
(682, 12, 85017, 'DEISY LIMA PESSOA', 76.00, 0.00, 23.00, 99.00, 'APROVADO', '2015', 4, 6, 4),
(683, 13, 59920, 'JOANA MUÑOZ PALOMINO', 77.00, 0.00, 21.50, 98.50, 'APROVADO', '2015', 4, 6, 4),
(684, 14, 99734, 'FLAVIO RENAN PAULA DA COSTA', 81.00, 0.00, 16.50, 97.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(685, 15, 85893, 'JÚLIO CESAR PINHEIRO DE MENEZES FILHO', 86.00, 0.00, 11.50, 97.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(686, 16, 40327, 'PABLO ANDRE BRITO DE SOUZA', 76.00, 0.00, 21.00, 97.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(687, 17, 9095, 'REJANE AGUIAR MAGALHÃES', 75.00, 0.00, 21.50, 96.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(688, 18, 60993, 'DIEGO HENRIQUE DE OLIVEIRA LIMA BERNARDO', 78.00, 0.00, 18.50, 96.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(689, 19, 86153, 'LAÉRCIO FERREIRA ARAÚJO', 72.00, 0.00, 24.00, 96.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(690, 20, 83877, 'CLAUDIA DOS PASSOS FARIAS', 79.00, 0.00, 17.00, 96.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(691, 21, 84589, 'JHENNIFER DO NASCIMENTO PEREIRA', 80.00, 0.00, 16.00, 96.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(692, 22, 36784, 'JAMIS SOUZA DOS SANTOS', 82.00, 0.00, 13.00, 95.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(693, 23, 59716, 'CIBELE LOUSANE PINHO MOTA', 76.00, 0.00, 18.50, 94.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(694, 24, 60628, 'RAILANE DINIZ FARIAS', 72.00, 0.00, 20.00, 92.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(695, 25, 97659, 'WILGNER JOSE DE SOUSA SANTOS', 71.00, 0.00, 20.00, 91.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(696, 26, 94644, 'TAIANNY AMAZONAS LOPES', 73.00, 0.00, 18.00, 91.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(697, 27, 64753, 'BRYAN GIUSSEPPE JARAMILLO CARDENAS', 77.00, 0.00, 13.50, 90.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(698, 28, 43260, 'MICHELLE VANESSA SANTIAGO FRANCO', 74.00, 0.00, 16.00, 90.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(699, 29, 38260, 'DIENY KETHANY DA SILVA GOMES', 72.00, 0.00, 17.00, 89.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(700, 30, 3332, 'ODEVÂNIA DA CRUZ AVELINO', 74.00, 0.00, 14.00, 88.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(701, 31, 2624, 'RAPHAEL BARROS ROCHA', 79.00, 0.00, 9.00, 88.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(702, 32, 99752, 'MARCOS ANTONIO OLIVEIRA SOUSA', 75.00, 0.00, 12.00, 87.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(703, 33, 99576, 'GABRIELE GOMES COSTA', 71.00, 0.00, 15.50, 86.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(704, 34, 2185, 'LORENA SIMONE GOVEIA', 76.00, 0.00, 10.00, 86.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(705, 35, 15322, 'EDISON FERREIRA DE ARAÚJO JÚNIOR', 71.00, 0.00, 15.00, 86.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(706, 36, 83658, 'JAIME BUENO DE ARAUJO', 72.00, 0.00, 14.00, 86.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(707, 37, 62434, 'LEONILDO DE ALBUQUERQUE FARIAS', 73.00, 0.00, 12.50, 85.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(708, 38, 13071, 'ADRIANO HENRIQUE LIMA DE OLIVEIRA', 71.00, 0.00, 14.00, 85.00, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(709, 39, 95340, 'DOUGLAS TAMAMARU DE SOUZA', 75.00, 0.00, 6.50, 81.50, 'LISTA DE ESPERA', '2015', 4, 6, 4),
(710, 1, 12622, 'THIAGO DE SOUZA PERUSSOLO', 86.00, 0.00, 16.00, 102.00, 'APROVADO', '2015', 6, 6, 4),
(711, 2, 88219, 'MARCELO DA SILVA GARCIA', 82.00, 0.00, 17.50, 99.50, 'APROVADO', '2015', 6, 6, 4),
(712, 3, 32379, 'ANNA RAILLA BARBALHO ALVES', 80.00, 0.00, 18.00, 98.00, 'APROVADO', '2015', 6, 6, 4),
(713, 4, 37953, 'LACY CARVALHO FALCÃO', 72.00, 0.00, 22.00, 94.00, 'LISTA DE ESPERA', '2015', 6, 6, 4),
(714, 5, 9810, 'IGOR IVISON ALMEIDA FERREIRA', 68.00, 0.00, 17.50, 85.50, 'LISTA DE ESPERA', '2015', 6, 6, 4),
(715, 6, 3940, 'SABRINA ARAUJO RAMOS', 69.00, 0.00, 16.50, 85.50, 'LISTA DE ESPERA', '2015', 6, 6, 4),
(716, 7, 100567, 'HELANIO VERAS RODRIGUES', 71.00, 0.00, 14.50, 85.50, 'LISTA DE ESPERA', '2015', 6, 6, 4),
(717, 8, 7408, 'ANTONIO DE MORAES SOUSA JUNIOR', 70.00, 0.00, 11.00, 81.00, 'LISTA DE ESPERA', '2015', 6, 6, 4),
(718, 9, 72034, 'FRANCISCO KLEBER DA SILVA DAMASCENO', 70.00, 0.00, 10.50, 80.50, 'LISTA DE ESPERA', '2015', 6, 6, 4),
(719, 1, 93881, 'JORGE GUILHERME VIEIRA NOGUEIRA', 92.00, 0.00, 25.00, 117.00, 'APROVADO', '2015', 8, 6, 4),
(720, 2, 62529, 'ELISON EMANUEL ARAÚJO LIMA', 97.00, 0.00, 19.00, 116.00, 'APROVADO', '2015', 8, 6, 4),
(721, 3, 97764, 'JOHANNA DE MELO SANTOS RODAS', 89.00, 0.00, 23.50, 112.50, 'APROVADO', '2015', 8, 6, 4),
(722, 4, 98404, 'ANDRÉ CADES BARBOSA PAZ OLIVEIRA DE MELO', 93.00, 0.00, 19.00, 112.00, 'APROVADO', '2015', 8, 6, 4),
(723, 5, 5310, 'SILVIO ROBERTO SARAIVA MONTEIRO', 96.00, 0.00, 14.00, 110.00, 'APROVADO', '2015', 8, 6, 4),
(724, 6, 59794, 'CATHERINE MENEZES COSTA', 92.00, 0.00, 16.50, 108.50, 'APROVADO', '2015', 8, 6, 4),
(725, 7, 94324, 'DEBORAH GOMES BELLEI', 82.00, 0.00, 26.50, 108.50, 'APROVADO', '2015', 8, 6, 4),
(726, 8, 2100, 'ANNE KAROLYNNE MAGGI ALMEIDA', 81.00, 0.00, 27.00, 108.00, 'APROVADO', '2015', 8, 6, 4),
(727, 9, 98494, 'MARCOS ANTONIO COUTINHO COSTA RODRIGUES', 80.00, 0.00, 28.00, 108.00, 'APROVADO', '2015', 8, 6, 4),
(728, 10, 63357, 'DWILLIO MENEZES GUIMARÃES', 94.00, 0.00, 12.50, 106.50, 'APROVADO', '2015', 8, 6, 4),
(729, 11, 86270, 'RENATA DE OLIVEIRA GALVAO', 82.00, 0.00, 23.50, 105.50, 'APROVADO', '2015', 8, 6, 4),
(730, 12, 12210, 'VÍTOR DANIEL MENEZES COSTA', 87.00, 0.00, 18.50, 105.50, 'APROVADO', '2015', 8, 6, 4),
(731, 13, 12144, 'GABRIEL HENRIQUE SILVA MOREIRA', 86.00, 0.00, 18.00, 104.00, 'APROVADO', '2015', 8, 6, 4),
(732, 14, 12154, 'CARLA VITÓRIA DAMASCENO RODRIGUES CEDRO', 78.00, 0.00, 25.50, 103.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(733, 15, 924, 'ANNE KAROLINE TOMÉ BRIGLIA', 82.00, 0.00, 20.50, 102.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(734, 16, 93308, 'ILDSON VINÍCIUS LIMA DE MELO', 84.00, 0.00, 18.00, 102.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(735, 17, 39056, 'JOAO PAULO DE OLIVEIRA CAMARA', 85.00, 0.00, 17.00, 102.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(736, 18, 88395, 'RAIANA SOUZA DA SILVA', 78.00, 0.00, 23.00, 101.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(737, 19, 81868, 'RAMON FILIPE MARTINS', 79.00, 0.00, 22.00, 101.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(738, 20, 37540, 'STEFANNY FERREIRA GOMES', 84.00, 0.00, 16.50, 100.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(739, 21, 96869, 'KEVIN AGNER RAMOS GUEDES', 77.00, 0.00, 21.00, 98.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(740, 22, 1618, 'YASMIN DE FREITAS SANTOS', 77.00, 0.00, 20.00, 97.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(741, 23, 64840, 'DANIEL ROSA CORREA LEAL', 82.00, 0.00, 14.50, 96.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(742, 24, 95851, 'STHEFANY SOUZA CARDOSO BARROS', 80.00, 0.00, 16.50, 96.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(743, 25, 83759, 'VERENA DE ASSIS FERREIRA', 75.00, 0.00, 20.00, 95.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(744, 26, 88421, 'BÁRBARA GOMES FERREIRA', 77.00, 0.00, 17.50, 94.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(745, 27, 8613, 'MATHEUS DANTAS BRUM', 78.00, 0.00, 16.00, 94.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(746, 28, 88454, 'SOLANGE VENÂNCIO MILANI', 77.00, 0.00, 16.50, 93.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(747, 29, 1318, 'POLIANA LUCENA DOS SANTOS', 75.00, 0.00, 18.00, 93.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(748, 30, 64807, 'RENATA BRECKENFELD SALUSTIANO BARROS', 75.00, 0.00, 17.50, 92.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(749, 31, 95614, 'RENAN CARDOSO SANCHEZ', 85.00, 0.00, 7.00, 92.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(750, 32, 83693, 'DIVA ITACY LIMA OLINTO DE OLIVEIRA JUREMA', 79.00, 0.00, 13.00, 92.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(751, 33, 94890, 'BEATRIZ DE SOUZA CARDOSO', 76.00, 0.00, 16.00, 92.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(752, 34, 34134, 'SUENIA MANDUCA RODRIGUES', 75.00, 0.00, 16.50, 91.50, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(753, 35, 39726, 'LUIS HENRIQUE SILVA DE JESUS', 75.00, 0.00, 16.00, 91.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(754, 36, 47635, 'KAMILA KENDRA MAR MARQUES', 75.00, 0.00, 15.00, 90.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(755, 37, 10815, 'CRISTINO ALVES DAMASCENO', 81.00, 0.00, 9.00, 90.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(756, 38, 23486, 'ANDERSON ALBERTO OTAVIANO', 78.00, 0.00, 9.00, 87.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(757, 39, 84377, 'IGOR OLIVEIRA DA SILVA', 75.00, 0.00, 10.00, 85.00, 'LISTA DE ESPERA', '2015', 8, 6, 4),
(758, 1, 98977, 'MANUELLE PAES MEBIUS', 82.00, 0.00, 25.50, 107.50, 'APROVADO', '2015', 10, 6, 4),
(759, 2, 11505, 'KLEBER GOMES CERQUINHO JUNIOR', 87.00, 0.00, 17.50, 104.50, 'APROVADO', '2015', 10, 6, 4),
(760, 3, 10265, 'BRENO RODRIGUES MOREIRA', 82.00, 0.00, 20.00, 102.00, 'APROVADO', '2015', 10, 6, 4),
(761, 4, 96366, 'ROBSON GRACIE ALMEIDA DA SILVA', 84.00, 0.00, 16.50, 100.50, 'LISTA DE ESPERA', '2015', 10, 6, 4),
(762, 5, 87547, 'BEATRIZ AZEVEDO NUNES', 83.00, 0.00, 16.00, 99.00, 'LISTA DE ESPERA', '2015', 10, 6, 4),
(763, 6, 94663, 'VICTOR MERINI MACHADO', 83.00, 0.00, 16.00, 99.00, 'LISTA DE ESPERA', '2015', 10, 6, 4),
(764, 7, 84041, 'ÍTALO EMANOEL OLIVEIRA BRANDÃO', 82.00, 0.00, 14.00, 96.00, 'LISTA DE ESPERA', '2015', 10, 6, 4),
(765, 8, 8212, 'FRANCISCO VINÍCIUS DE ALBUQUERQUE OLIVEIRA', 80.00, 0.00, 14.00, 94.00, 'LISTA DE ESPERA', '2015', 10, 6, 4),
(766, 9, 32742, 'SANDRA LETICIA MIORANDO', 81.00, 0.00, 10.50, 91.50, 'LISTA DE ESPERA', '2015', 10, 6, 4),
(767, 1, 489, 'FRANCISCO SABINO DE OLIVEIRA NETO', 85.00, 0.00, 18.00, 103.00, 'APROVADO', '2015', 1, 6, 4),
(768, 2, 1858, 'SUSAN KEITY NASCIMENTO TRAJANO', 84.00, 0.00, 11.00, 95.00, 'APROVADO', '2015', 1, 6, 4),
(769, 3, 83798, 'ÁKILLA CAROLINE NASCIMENTO PEREIRA', 70.00, 0.00, 17.00, 87.00, 'APROVADO', '2015', 1, 6, 4),
(770, 4, 96360, 'GABRIEL PINHEIRO SOARES ALENCAR E SILVA', 69.00, 0.00, 16.50, 85.50, 'APROVADO', '2015', 1, 6, 4),
(771, 5, 47640, 'FABIANA ZANETTI DA COSTA', 62.00, 0.00, 16.50, 78.50, 'LISTA DE ESPERA', '2015', 1, 6, 4),
(772, 6, 96937, 'ANTONIO BRENO SILVA GOMES', 60.00, 0.00, 17.00, 77.00, 'LISTA DE ESPERA', '2015', 1, 6, 4),
(773, 7, 62393, 'ANA BEATRIZ OLIVEIRA COSTA', 60.00, 0.00, 14.50, 74.50, 'LISTA DE ESPERA', '2015', 1, 6, 4),
(774, 8, 60606, 'RENATHA CRISTYNE COSTA SANTOS', 53.00, 0.00, 16.00, 69.00, 'LISTA DE ESPERA', '2015', 1, 6, 4),
(775, 9, 46684, 'DANIEL SANTOS CARVALHO', 56.00, 0.00, 11.00, 67.00, 'LISTA DE ESPERA', '2015', 1, 6, 4),
(776, 10, 22740, 'IRONI DA ROSA PADILHA', 54.00, 0.00, 13.00, 67.00, 'LISTA DE ESPERA', '2015', 1, 6, 4),
(777, 11, 95866, 'BRUNO SERGIO COSTA BRASIL', 53.00, 0.00, 13.50, 66.50, 'LISTA DE ESPERA', '2015', 1, 6, 4),
(778, 12, 17917, 'MAYCO SILVA DOS SANTOS', 54.00, 0.00, 12.00, 66.00, 'LISTA DE ESPERA', '2015', 1, 6, 4),
(779, 1, 88466, 'ALDROVANDO NERY DE AGUIAR JUNIOR', 91.00, 0.00, 28.00, 119.00, 'APROVADO', '2014', 2, 6, 3),
(780, 2, 63688, 'RAQUEL GOUVEA MOLEIRO', 90.00, 0.00, 28.50, 118.50, 'APROVADO', '2014', 2, 6, 3),
(781, 3, 83659, 'ANA CAROLINA LEMOS DE OLIVEIRA', 90.00, 0.00, 28.50, 118.50, 'APROVADO', '2014', 2, 6, 3),
(782, 4, 35719, 'THIAGO HENRIQUE HIRAKAWA', 89.00, 0.00, 29.00, 118.00, 'APROVADO', '2014', 2, 6, 3),
(783, 5, 39357, 'RENNYER RUGGERY DE SOUZA MENANDRO', 90.00, 0.00, 28.00, 118.00, 'APROVADO', '2014', 2, 6, 3),
(784, 6, 524, 'MAYARA GABRIELLE SOUTO', 88.00, 0.00, 29.00, 117.00, 'APROVADO', '2014', 2, 6, 3),
(785, 7, 876, 'VALÉRIA VIEIRA DA SILVA COUTINHO', 89.00, 0.00, 27.00, 116.00, 'APROVADO', '2014', 2, 6, 3),
(786, 8, 1728, 'MINA NURANI', 91.00, 0.00, 24.50, 115.50, 'APROVADO', '2014', 2, 6, 3),
(787, 9, 83594, 'RACHEL PEREIRA FERREIRA', 90.00, 0.00, 24.63, 114.63, 'APROVADO', '2014', 2, 6, 3),
(788, 10, 60636, 'MARIANA NAVROTZKI CHILANTI', 88.00, 0.00, 26.00, 114.00, 'APROVADO', '2014', 2, 6, 3),
(789, 11, 38743, 'JÚLIO GOMES DO NASCIMENTO NETO', 88.00, 0.00, 25.00, 113.00, 'APROVADO', '2014', 2, 6, 3),
(790, 12, 32861, 'PEDRO GOMES LINS DE CARVALHO', 87.00, 0.00, 25.50, 112.50, 'APROVADO', '2014', 2, 6, 3),
(791, 13, 63862, 'ISABELLA SEIXAS MARTINS', 88.00, 0.00, 24.50, 112.50, 'APROVADO', '2014', 2, 6, 3),
(792, 14, 14002, 'LANA AKEMY LIRA MATSUBARA', 86.00, 0.00, 26.50, 112.50, 'APROVADO', '2014', 2, 6, 3),
(793, 15, 16542, 'RANDIELLY MENDONÇA DA COSTA', 85.00, 0.00, 27.00, 112.00, 'APROVADO', '2014', 2, 6, 3),
(794, 16, 33489, 'SARAH DE OLIVEIRA SILVA', 83.00, 0.00, 28.50, 111.50, 'APROVADO', '2014', 2, 6, 3),
(795, 17, 43436, 'YAGO MAGRINI DOS SANTOS VIEIRA', 86.00, 0.00, 25.50, 111.50, 'APROVADO', '2014', 2, 6, 3),
(796, 18, 89121, 'WESSLEY ROBERTO BATISTA DA SILVA QUIRINO', 86.00, 0.00, 25.00, 111.00, 'APROVADO', '2014', 2, 6, 3),
(797, 19, 39083, 'CIBELLE CARNEIRO FARIAS', 85.00, 0.00, 25.50, 110.50, 'APROVADO', '2014', 2, 6, 3),
(798, 20, 34606, 'DIAGO RAFAEL MOTA FASSANARO', 82.00, 0.00, 28.00, 110.00, 'APROVADO', '2014', 2, 6, 3),
(799, 21, 38454, 'RAYELLE CRISTINE DA SILVA AVELINO', 82.00, 0.00, 28.00, 110.00, 'APROVADO', '2014', 2, 6, 3),
(800, 22, 59662, 'GABRIELA LIMA TARGINO', 84.00, 0.00, 25.50, 109.50, 'APROVADO', '2014', 2, 6, 3),
(801, 23, 87370, 'DANILO JONAS SILVA FRIAÇA', 84.00, 0.00, 25.00, 109.00, 'APROVADO', '2014', 2, 6, 3),
(802, 24, 848, 'FÁBIO GALDINO MOURA', 84.00, 0.00, 25.00, 109.00, 'APROVADO', '2014', 2, 6, 3),
(803, 25, 11602, 'VICTOR RYAN SALES THOMÉ', 80.00, 0.00, 29.00, 109.00, 'APROVADO', '2014', 2, 6, 3),
(804, 26, 65207, 'ADLER MONTEIRO DE MACEDO JÚNIOR', 81.00, 0.00, 28.00, 109.00, 'APROVADO', '2014', 2, 6, 3),
(805, 27, 17576, 'CAROLLINA SANT ANA BEZERRA', 79.00, 0.00, 29.00, 108.00, 'APROVADO', '2014', 2, 6, 3),
(806, 28, 2177, 'ANDRESSA RODRIGUES RIBEIRO', 79.00, 0.00, 29.00, 108.00, 'APROVADO', '2014', 2, 6, 3),
(807, 29, 59982, 'NAIÁ LAURIA DA SILVA', 79.00, 0.00, 29.00, 108.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(808, 30, 1246, 'LUCAS DUTRA LEITE', 79.00, 0.00, 29.00, 108.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(809, 31, 86986, 'CAMILA STEIN', 83.00, 0.00, 25.00, 108.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(810, 32, 38244, 'IZAURA DOS SANTOS SOUZA', 84.00, 0.00, 23.50, 107.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(811, 33, 83436, 'LUCAS IANNUZZI MARTINS', 79.00, 0.00, 28.50, 107.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(812, 34, 33002, 'RAFAELA NASCIMENTO LIMA', 80.00, 0.00, 27.00, 107.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(813, 35, 59793, 'OLYMPIO VITTOR ARCURIO FONSECA', 91.00, 0.00, 14.50, 105.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(814, 36, 10425, 'FRANK SILAS SALDANHA MARQUES', 79.00, 0.00, 26.50, 105.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(815, 37, 88818, 'MARIANE ARANJUES MONTORO', 79.00, 0.00, 26.50, 105.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(816, 38, 90354, 'GIOVANA COIMBRA LUZEIRO', 76.00, 0.00, 29.00, 105.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(817, 39, 489, 'FRANCISCO SABINO DE OLIVEIRA NETO', 77.00, 0.00, 28.00, 105.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(818, 40, 84062, 'THIAGO TORRES MUNIZ', 81.00, 0.00, 23.50, 104.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(819, 41, 87210, 'MATHEUS TOLEDO NAUFAL PINTO', 82.00, 0.00, 22.50, 104.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(820, 42, 87232, 'CAIO BRENNO ABREU', 79.00, 0.00, 25.13, 104.13, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(821, 43, 780, 'STEFFI FERREIRA BUTTENBENDER', 83.00, 0.00, 21.00, 104.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(822, 44, 35704, 'INDRA LICIANE NASCIMENTO DE FREITAS', 75.00, 0.00, 29.00, 104.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(823, 45, 85591, 'GLÓRIA CENTINI', 81.00, 0.00, 22.50, 103.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(824, 46, 89194, 'SUZANI NAOMI HIGA', 82.00, 0.00, 21.50, 103.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(825, 47, 41474, 'JEFFERSON MARTINS DE LIMA', 81.00, 0.00, 22.00, 103.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(826, 48, 33272, 'THIAGO WILLIAN MOREIRA CAMPELO', 81.00, 0.00, 22.00, 103.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(827, 49, 32423, 'YASMIN BASTOS SILVA GOMES', 76.00, 0.00, 27.00, 103.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(828, 50, 86022, 'LIZANDRA CUNHA DE CARVALHO', 77.00, 0.00, 26.00, 103.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(829, 51, 87782, 'SARA DE FREITAS ROMÃO', 76.00, 0.00, 27.00, 103.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(830, 52, 4924, 'HERBERT IAGO FEITOSA DA FONSECA', 77.00, 0.00, 26.00, 103.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(831, 53, 62761, 'DANILLO PEDRO MENDES DA SILVA', 78.00, 0.00, 25.00, 103.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(832, 54, 85692, 'SKARLET POLICARPO ARAUJO', 75.00, 0.00, 27.50, 102.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(833, 55, 89716, 'FRANCISCO RENAN FERREIRA DE SOUSA', 87.00, 0.00, 15.50, 102.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(834, 56, 8589, 'LAYANE FERREIRA BALBINO', 84.00, 0.00, 18.50, 102.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(835, 57, 60472, 'JANAINA GOMES DA ROCHA', 76.00, 0.00, 26.00, 102.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(836, 58, 36026, 'KALINY DA SILVA GALVÃO', 76.00, 0.00, 26.00, 102.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(837, 59, 85183, 'SAMANTA RIBEIRO MUCCINI', 75.00, 0.00, 26.50, 101.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(838, 60, 5091, 'LUÍS FELIPE COÊLHO LEITE', 76.00, 0.00, 25.50, 101.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(839, 61, 7809, 'ATHOS HIAGO DA SILVA OLIVEIRA', 79.00, 0.00, 22.00, 101.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(840, 62, 9222, 'THIAGO PENAFORTE DE OLIVEIRA QUEIROZ', 76.00, 0.00, 25.00, 101.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(841, 63, 33142, 'DMITRI RAVEL BARROSO ABREU', 78.00, 0.00, 22.50, 100.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(842, 64, 11113, 'KELLY DA CONCEIÇÃO AQUINO', 79.00, 0.00, 21.00, 100.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(843, 65, 2439, 'RAPHAELLY VENZEL', 75.00, 0.00, 24.63, 99.63, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(844, 66, 89715, 'ADELMO ISAAC MEDEIROS AVELINO', 76.00, 0.00, 23.50, 99.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(845, 67, 60704, 'RAIANE PINHEIRO DE LIMA', 75.00, 0.00, 24.50, 99.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(846, 68, 32748, 'PAULO TRAJANO DOS SANTOS JÚNIOR', 77.00, 0.00, 22.00, 99.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(847, 69, 8243, 'FELIPE VAROTTO WANDERLEY', 76.00, 0.00, 22.50, 98.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(848, 70, 40322, 'MATHEUS ARAUJO MOREIRA', 79.00, 0.00, 19.50, 98.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(849, 71, 84041, 'ÍTALO EMANOEL OLIVEIRA BRANDÃO', 75.00, 0.00, 22.00, 97.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(850, 72, 90229, 'BRUNO SENA DE MELO', 76.00, 0.00, 20.50, 96.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(851, 73, 90397, 'ALINE MARIANA SILVA CÂNDIDO', 76.00, 0.00, 20.00, 96.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(852, 74, 84707, 'LUIZ ALBERTO NUNES RIBEIRO', 77.00, 0.00, 19.00, 96.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(853, 75, 38624, 'CAROLINE DA COSTA NEVES', 79.00, 0.00, 16.50, 95.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(854, 76, 8339, 'PAULO VICTOR PAZ MACHADO', 76.00, 0.00, 19.00, 95.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(855, 77, 33009, 'SWAMINE DA SILVA GOMES', 77.00, 0.00, 17.50, 94.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(856, 78, 88495, 'NATHANAEL PHILIPE MENDONCA E SILVA', 76.00, 0.00, 18.50, 94.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(857, 79, 33512, 'TIAGO MATOS DOURADO', 77.00, 0.00, 17.00, 94.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(858, 80, 33291, 'AUGUSTO FÉNELON SARAIVA NOGUEIRA', 78.00, 0.00, 15.50, 93.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(859, 81, 88300, 'CLAUDIA JULIANA NORIEGA REY', 76.00, 0.00, 15.00, 91.00, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(860, 82, 32706, 'ALYNE SOUZA MAGALHÃES', 75.00, 0.00, 15.50, 90.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(861, 83, 12286, 'PRISCILLA BRITO DE SOUZA', 77.00, 0.00, 13.50, 90.50, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(862, 84, 85202, 'LUCIANO CARVALHO DUDEK', 81.00, 0.00, 7.67, 88.67, 'LISTA DE ESPERA', '2014', 2, 6, 3),
(863, 1, 83785, 'LUCIVAN SOUSA DOS SANTOS', 89.00, 0.00, 18.00, 107.00, 'APROVADO', '2014', 4, 6, 3),
(864, 2, 38758, 'BRENNO KRISTIANO SOARES DOS SANTOS', 90.00, 0.00, 14.00, 104.00, 'APROVADO', '2014', 4, 6, 3),
(865, 3, 43171, 'CLAUDIA KLECYANNE RODRIGUES DE BRITO', 87.00, 0.00, 16.00, 103.00, 'APROVADO', '2014', 4, 6, 3),
(866, 4, 41225, 'DANIEL DO NASCIMENTO ARAÚJO', 79.00, 0.00, 18.83, 97.83, 'APROVADO', '2014', 4, 6, 3),
(867, 5, 43534, 'ALLAN CHRISTIAN LIMA DA SILVA', 81.00, 0.00, 15.00, 96.00, 'APROVADO', '2014', 4, 6, 3),
(868, 6, 39207, 'HIAGO TOMAZ DA SILVA ARAÚJO', 79.00, 0.00, 16.00, 95.00, 'APROVADO', '2014', 4, 6, 3),
(869, 7, 89608, 'AMANDA RODRIGUES PINATTO', 68.00, 0.00, 23.50, 91.50, 'APROVADO', '2014', 4, 6, 3),
(870, 8, 11828, 'RAIKAR BARRETO DA SILVA STONE', 77.00, 0.00, 14.00, 91.00, 'APROVADO', '2014', 4, 6, 3),
(871, 9, 88358, 'JESSICA LIMA BRITO', 73.00, 0.00, 17.00, 90.00, 'APROVADO', '2014', 4, 6, 3),
(872, 10, 37505, 'JÉSSYCA MAGALHÃES DE MATOS', 69.00, 0.00, 21.00, 90.00, 'APROVADO', '2014', 4, 6, 3),
(873, 11, 37209, 'RADIR ALBUQUERQUE DOS SANTOS', 72.00, 0.00, 15.50, 87.50, 'APROVADO', '2014', 4, 6, 3),
(874, 12, 33636, 'FELIPE FERREIRA SILVA', 71.00, 0.00, 14.50, 85.50, 'APROVADO', '2014', 4, 6, 3),
(875, 13, 32746, 'EDUARDO WANDERLEY DE ALMEIDA', 70.00, 0.00, 14.50, 84.50, 'APROVADO', '2014', 4, 6, 3),
(876, 14, 39349, 'HYURY CÉSAR BARROS DE OLIVEIRA', 68.00, 0.00, 16.00, 84.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(877, 15, 43373, 'ANA BEATRIZ RANGEL PLACIDO', 70.00, 0.00, 13.00, 83.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(878, 16, 36784, 'JAMIS SOUZA DOS SANTOS', 70.00, 0.00, 11.00, 81.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(879, 17, 23352, 'ORLENILDES LIMA DOS SANTOS', 67.00, 0.00, 13.00, 80.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(880, 18, 11594, 'ADHAN CHARLLEYS INACIO GOMES', 67.00, 0.00, 11.00, 78.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(881, 19, 13144, 'MAYCON VINICIUS LUZ COSTA', 63.00, 0.00, 14.00, 77.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(882, 20, 32519, 'KEMILY DE ALMEIDA LIMA', 65.00, 0.00, 11.50, 76.50, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(883, 21, 2624, 'RAPHAEL BARROS ROCHA', 61.00, 0.00, 15.00, 76.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(884, 22, 88571, 'ADRIEL MARTINS DAS NEVES', 62.00, 0.00, 14.00, 76.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(885, 23, 38260, 'DIENY KETHANY DA SILVA GOMES', 59.00, 0.00, 16.50, 75.50, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(886, 24, 85799, 'ALINY COSTA DA SILVA', 59.00, 0.00, 15.17, 74.17, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(887, 25, 39280, 'NATANAEL LEMOS DA CRUZ', 59.00, 0.00, 15.00, 74.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(888, 26, 2904, 'MANOELLE DA COSTA OLIVEIRA', 60.00, 0.00, 14.00, 74.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(889, 27, 1333, 'WESCLEY COSTA DA SILVA', 61.00, 0.00, 13.00, 74.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(890, 28, 36677, 'JOSÉ NILDON ALVES DE LIMA JÚNIOR', 61.00, 0.00, 13.00, 74.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(891, 29, 83631, 'WANDERSON BATISTA SILVA', 59.00, 0.00, 15.00, 74.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(892, 30, 33718, 'ODEVÂNIA DA CRUZ AVELINO', 57.00, 0.00, 16.00, 73.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(893, 31, 168, 'FRANCISMAR GALVÃO DA PENHA', 59.00, 0.00, 13.00, 72.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(894, 32, 64052, 'MATHEUS HENRIQUE RIBEIRO CORREA', 59.00, 0.00, 13.00, 72.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(895, 33, 33695, 'REJANE AGUIAR MAGALHÃES', 60.00, 0.00, 12.00, 72.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(896, 34, 65645, 'PAMELLA PENELLOPY DE MATOS CUMAPA', 55.00, 0.00, 16.50, 71.50, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(897, 35, 13231, 'JESSICA SALES VERAS', 55.00, 0.00, 16.00, 71.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(898, 36, 15322, 'EDISON FERREIRA DE ARAÚJO JÚNIOR', 57.00, 0.00, 13.50, 70.50, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(899, 37, 13071, 'ADRIANO HENRIQUE LIMA DE OLIVEIRA', 60.00, 0.00, 9.50, 69.50, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(900, 38, 17421, 'LUCILANE SANTANA PEREIRA', 57.00, 0.00, 10.00, 67.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(901, 39, 11210, 'HIGOR ALMEIDA SOUSA', 56.00, 0.00, 10.00, 66.00, 'LISTA DE ESPERA', '2014', 4, 6, 3),
(902, 1, 38853, 'ALEXANDRE FEITOSA DA SILVA', 78.00, 0.00, 19.50, 97.50, 'APROVADO', '2014', 6, 6, 3),
(903, 2, 83516, 'CARLOS AUGUSTO FELICIANO PEREIRA', 70.00, 0.00, 19.83, 89.83, 'APROVADO', '2014', 6, 6, 3),
(904, 3, 87405, 'LARISSA ERIKARLA NEGREIROS MADUREIRA', 63.00, 0.00, 16.00, 79.00, 'APROVADO', '2014', 6, 6, 3),
(905, 4, 63749, 'ELAYNE PAULA DE OLIVEIRA HOLANDA', 61.00, 0.00, 15.00, 76.00, 'LISTA DE ESPERA', '2014', 6, 6, 3),
(906, 5, 69432, 'PATRÍCIA MARIA BARREIRO NUNES', 64.00, 0.00, 11.50, 75.50, 'LISTA DE ESPERA', '2014', 6, 6, 3),
(907, 6, 3940, 'SABRINA ARAUJO RAMOS', 58.00, 0.00, 15.50, 73.50, 'LISTA DE ESPERA', '2014', 6, 6, 3),
(908, 7, 53219, 'MAYARA BIANCA PEREIRA RODRIGUES', 55.00, 0.00, 18.00, 73.00, 'LISTA DE ESPERA', '2014', 6, 6, 3),
(909, 8, 87094, 'RAFAEL BRAGA ESTEVES', 56.00, 0.00, 15.50, 71.50, 'LISTA DE ESPERA', '2014', 6, 6, 3),
(910, 9, 37953, 'LACY CARVALHO FALCÃO', 57.00, 0.00, 13.50, 70.50, 'LISTA DE ESPERA', '2014', 6, 6, 3),
(911, 1, 11464, 'LUCAS DA SILVA GOMES', 85.00, 0.00, 27.00, 112.00, 'APROVADO', '2014', 8, 6, 3),
(912, 2, 32511, 'MARCELO CAETANO HORTEGAL ANDRADE', 93.00, 0.00, 18.00, 111.00, 'APROVADO', '2014', 8, 6, 3),
(913, 3, 13971, 'ALANA SPERANDIO PORTO', 90.00, 0.00, 15.00, 105.00, 'APROVADO', '2014', 8, 6, 3),
(914, 4, 10885, 'MILTON VILAR FERREIRA DANTAS', 80.00, 0.00, 19.00, 99.00, 'APROVADO', '2014', 8, 6, 3),
(915, 5, 7780, 'GABRIELA LUDMYLA PEREIRA MARQUES', 74.00, 0.00, 25.00, 99.00, 'APROVADO', '2014', 8, 6, 3),
(916, 6, 61553, 'DANIEL RODRIGUES DA SILVA BARBOSA', 82.00, 0.00, 16.50, 98.50, 'APROVADO', '2014', 8, 6, 3),
(917, 7, 13011, 'FABIO APARECIDO COSTA', 82.00, 0.00, 16.00, 98.00, 'APROVADO', '2014', 8, 6, 3),
(918, 8, 59798, 'ANTONIO ARCANJO MARTINS', 82.00, 0.00, 16.00, 98.00, 'APROVADO', '2014', 8, 6, 3),
(919, 9, 35741, 'KACIO DA SILVA MOURAO', 80.00, 0.00, 15.50, 95.50, 'APROVADO', '2014', 8, 6, 3),
(920, 10, 509, 'GABRIEL DANTE GUERRA DE OLIVEIRA CAMARÃO', 79.00, 0.00, 16.00, 95.00, 'APROVADO', '2014', 8, 6, 3),
(921, 11, 88881, 'TAVILLA SILVA LAGARES', 81.00, 0.00, 14.00, 95.00, 'APROVADO', '2014', 8, 6, 3),
(922, 12, 886, 'NILSON DOS SANTOS NASCIMENTO', 78.00, 0.00, 14.50, 92.50, 'APROVADO', '2014', 8, 6, 3);
INSERT INTO `tb_resultado_final` (`id`, `ordem`, `inscricao`, `nome`, `objetiva`, `especificas`, `redacao`, `total`, `situacao`, `ano`, `cota_id`, `curso_id`, `edital_id`) VALUES
(923, 13, 13405, 'ABIGAIL REBECA RAMIRES FRANCO', 73.00, 0.00, 19.50, 92.50, 'APROVADO', '2014', 8, 6, 3),
(924, 14, 35981, 'VICTOR CORREA COSTA', 76.00, 0.00, 16.00, 92.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(925, 15, 9017, 'MAIKIA ADINAIARA DE SOUZA ARAUJO', 78.00, 0.00, 14.00, 92.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(926, 16, 2100, 'ANNE KAROLYNNE MAGGI ALMEIDA', 68.00, 0.00, 23.67, 91.67, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(927, 17, 86868, 'GLAVILLY KELLY RODRIGUES ROCHA', 72.00, 0.00, 19.50, 91.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(928, 18, 924, 'ANNE KAROLINE TOMÉ BRIGLIA', 71.00, 0.00, 19.50, 90.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(929, 19, 61444, 'JOÃO BATISTA FÉLIX DE SOUSA', 74.00, 0.00, 16.00, 90.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(930, 20, 1652, 'ELVES DOUGLAS CASTRO SOARES', 80.00, 0.00, 10.00, 90.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(931, 21, 11505, 'KLEBER GOMES CERQUINHO JUNIOR', 73.00, 0.00, 15.00, 88.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(932, 22, 83612, 'GILSKLEY DE OLIVEIRA COELHO', 70.00, 0.00, 17.50, 87.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(933, 23, 10265, 'BRENO RODRIGUES MOREIRA', 72.00, 0.00, 15.00, 87.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(934, 24, 84063, 'MATHEUS MARTINS VIEIRA', 72.00, 0.00, 14.50, 86.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(935, 25, 62284, 'ALDISSON LUNA PINHEIRO', 70.00, 0.00, 15.00, 85.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(936, 26, 12622, 'THIAGO DE SOUZA PERUSSOLO', 76.00, 0.00, 9.00, 85.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(937, 27, 87267, 'AILTON MOREIRA RESPLANDES', 75.00, 0.00, 10.00, 85.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(938, 28, 85371, 'SUZANA CINTIA DE QUEIROZ', 69.00, 0.00, 15.50, 84.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(939, 29, 81868, 'RAMON FILIPE MARTINS', 68.00, 0.00, 16.00, 84.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(940, 30, 63968, 'SHERLLITON SANDER DE SOUZA SEABRA', 68.00, 0.00, 15.00, 83.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(941, 31, 66090, 'ELIEL PINTO MACHADO', 66.00, 0.00, 17.00, 83.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(942, 32, 79123, 'GEORGE LUCAS LOPES DA SILVA GOMES', 66.00, 0.00, 16.50, 82.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(943, 33, 10815, 'CRISTINO ALVES DAMASCENO', 69.00, 0.00, 12.50, 81.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(944, 34, 11554, 'SUIANE LIMA CARLOS', 64.00, 0.00, 17.00, 81.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(945, 35, 11788, 'HOLTTON BRUNO SCHUERTZ ALVES', 65.00, 0.00, 14.50, 79.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(946, 36, 38756, 'LÚCIA TATIANA FILGUEIRAS DE SOUZA', 63.00, 0.00, 16.00, 79.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(947, 37, 83759, 'VERENA DE ASSIS FERREIRA', 63.00, 0.00, 16.00, 79.00, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(948, 38, 586, 'VALTECY MENDES ALMEIDA DE ALBUQUERQUE', 62.00, 0.00, 13.50, 75.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(949, 39, 34134, 'SUENIA MANDUCA RODRIGUES', 63.00, 0.00, 8.50, 71.50, 'LISTA DE ESPERA', '2014', 8, 6, 3),
(950, 1, 37984, 'CAIO AUGUSTO LEITÃO MELO', 84.00, 0.00, 10.00, 94.00, 'APROVADO', '2014', 10, 6, 3),
(951, 2, 84331, 'ALANA DOS SANTOS', 72.00, 0.00, 15.50, 87.50, 'APROVADO', '2014', 10, 6, 3),
(952, 3, 12452, 'DESIRÊ DOS SANTOS DIAS', 66.00, 0.00, 18.50, 84.50, 'APROVADO', '2014', 10, 6, 3),
(953, 4, 8805, 'CLARISSA ROSA PINTO', 65.00, 0.00, 16.50, 81.50, 'LISTA DE ESPERA', '2014', 10, 6, 3),
(954, 5, 12144, 'GABRIEL HENRIQUE SILVA MOREIRA', 63.00, 0.00, 16.00, 79.00, 'LISTA DE ESPERA', '2014', 10, 6, 3),
(955, 6, 71888, 'CELSO EDUARDO COSTA NERY', 64.00, 0.00, 12.00, 76.00, 'LISTA DE ESPERA', '2014', 10, 6, 3),
(956, 7, 89070, 'DELLANO CEZAR PINTO DA SILVA', 60.00, 0.00, 16.00, 76.00, 'LISTA DE ESPERA', '2014', 10, 6, 3),
(957, 8, 6245, 'PAULO RICARDO SOUSA CAVALCANTE', 62.00, 0.00, 13.50, 75.50, 'LISTA DE ESPERA', '2014', 10, 6, 3),
(958, 9, 32379, 'ANNA RAILLA BARBALHO ALVES', 60.00, 0.00, 15.00, 75.00, 'LISTA DE ESPERA', '2014', 10, 6, 3),
(959, 1, 60308, 'ROBERTO SOARES AGUIAR', 75.00, 0.00, 16.00, 91.00, 'APROVADO', '2014', 1, 6, 3),
(960, 2, 33022, 'LOAMIR DA SILVA VIANA', 64.00, 0.00, 12.83, 76.83, 'APROVADO', '2014', 1, 6, 3),
(961, 3, 2706, 'ANA LUISA GOMES BARROS PALÁCIO', 53.00, 0.00, 15.00, 68.00, 'APROVADO', '2014', 1, 6, 3),
(962, 4, 15699, 'LIVIA FERNANDA QUEIROZ DE ALMEIDA', 50.00, 0.00, 15.00, 65.00, 'APROVADO', '2014', 1, 6, 3),
(963, 5, 86899, 'PATRÍCIA FERNANDES VIEIRA', 46.00, 0.00, 16.00, 62.00, 'LISTA DE ESPERA', '2014', 1, 6, 3),
(964, 6, 22740, 'IRONI DA ROSA PADILHA', 46.00, 0.00, 15.50, 61.50, 'LISTA DE ESPERA', '2014', 1, 6, 3),
(965, 7, 18718, 'FLÁUBIA DE SOUSA MACEDO', 46.00, 0.00, 15.50, 61.50, 'LISTA DE ESPERA', '2014', 1, 6, 3),
(966, 8, 81879, 'JOSÉ VALDIR CUNHA DOS SANTOS', 41.00, 0.00, 18.00, 59.00, 'LISTA DE ESPERA', '2014', 1, 6, 3),
(967, 9, 64408, 'GABRIELA OLIVIA SANTOS CHAVES', 43.00, 0.00, 16.00, 59.00, 'LISTA DE ESPERA', '2014', 1, 6, 3),
(968, 10, 39672, 'DORIVAN FLORENCIO RODRIGUES DE OLIVEIRA', 43.00, 0.00, 16.00, 59.00, 'LISTA DE ESPERA', '2014', 1, 6, 3),
(969, 11, 17917, 'MAYCO SILVA DOS SANTOS', 42.00, 0.00, 14.00, 56.00, 'LISTA DE ESPERA', '2014', 1, 6, 3),
(970, 12, 67975, 'RONILSON REIS BRITO', 47.00, 0.00, 7.00, 54.00, 'LISTA DE ESPERA', '2014', 1, 6, 3),
(971, 1, 5587, 'HENDEL SANTANA MORAIS', 94.00, 0.00, 30.00, 124.00, 'CLASSIFICADO', '2013', 2, 6, 2),
(972, 2, 12310, 'THAIS SUELEN ISRAEL FERREIRA', 94.00, 0.00, 30.00, 124.00, 'CLASSIFICADO', '2013', 2, 6, 2),
(973, 3, 59736, 'LETÍCIA COUTO CAVALCANTE RODRIGUES', 93.00, 0.00, 30.00, 123.00, 'CLASSIFICADO', '2013', 2, 6, 2),
(974, 4, 2758, 'DKAION VILELA DE JESUS', 97.00, 0.00, 24.00, 121.00, 'CLASSIFICADO', '2013', 2, 6, 2),
(975, 5, 38802, 'ANA CAROLINA MOREIRA SILVA', 91.00, 0.00, 30.00, 121.00, 'CLASSIFICADO', '2013', 2, 6, 2),
(976, 6, 10796, 'TALES CEI HAGE SAADE', 94.00, 0.00, 26.50, 120.50, 'CLASSIFICADO', '2013', 2, 6, 2),
(977, 7, 12758, 'TYRONE ARAUJO SOBRAL', 88.00, 0.00, 30.00, 118.00, 'CLASSIFICADO', '2013', 2, 6, 2),
(978, 8, 10645, 'INGRID FERREIRA BUTTENBENDER', 88.00, 0.00, 30.00, 118.00, 'CLASSIFICADO', '2013', 2, 6, 2),
(979, 9, 32312, 'TARSIA REGINA LEAL RAMOS', 88.00, 0.00, 30.00, 118.00, 'CLASSIFICADO', '2013', 2, 6, 2),
(980, 10, 984, 'PAULO HENRIQUE BRASIL HASS GONÇALVES FILHO', 91.00, 0.00, 27.00, 118.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(981, 11, 35983, 'GUILHERME ARAUJO MARQUES', 88.00, 0.00, 29.00, 117.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(982, 12, 33567, 'JOAO PEDRO PEREIRA BRAGA', 89.00, 0.00, 28.00, 117.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(983, 13, 12512, 'LETICIA LIMA GOMES DA SILVA', 86.00, 0.00, 30.00, 116.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(984, 14, 60851, 'EDUARDO FERNANDES DA SILVA', 87.00, 0.00, 28.50, 115.50, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(985, 15, 63617, 'MICHEL DOUGLAS SILVA DE SOUSA', 88.00, 0.00, 27.00, 115.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(986, 16, 34606, 'DIAGO RAFAEL MOTA FASSANARO', 88.00, 0.00, 27.00, 115.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(987, 17, 524, 'MAYARA GABRIELLE SOUTO', 85.00, 0.00, 30.00, 115.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(988, 18, 801, 'CLARISSA DA SILVA BONFIM', 86.00, 0.00, 29.00, 115.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(989, 19, 64386, 'POLIANA SOARES DE SOUZA', 85.00, 0.00, 30.00, 115.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(990, 20, 876, 'VALÉRIA VIEIRA DA SILVA COUTINHO', 87.00, 0.00, 27.00, 114.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(991, 21, 31587, 'DAVID SMANGOSZEVSKI MARTINS', 89.00, 0.00, 24.50, 113.50, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(992, 22, 33512, 'TIAGO MATOS DOURADO', 86.00, 0.00, 27.00, 113.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(993, 23, 60636, 'MARIANA NAVROTZKI CHILANTI', 86.00, 0.00, 27.00, 113.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(994, 24, 39727, 'HUMBERTO BRITO ORELLANA', 86.00, 0.00, 27.00, 113.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(995, 25, 60125, 'NAYARA TEIXEIRA JALES', 87.00, 0.00, 25.50, 112.50, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(996, 26, 33683, 'LAYANE FERREIRA BALBINO', 85.00, 0.00, 27.00, 112.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(997, 27, 36271, 'LUCAS DE PAULA GALVAO', 85.00, 0.00, 25.00, 110.00, 'LISTA DE ESPERA', '2013', 2, 6, 2),
(998, 1, 33660, 'CAMILA MELO DA SILVA', 85.00, 0.00, 26.00, 111.00, 'CLASSIFICADO', '2013', 4, 6, 2),
(999, 2, 11526, 'ANNE LARISSA PEREIRA', 82.00, 0.00, 27.00, 109.00, 'CLASSIFICADO', '2013', 4, 6, 2),
(1000, 3, 3521, 'THARLES COSTA RAMIRO', 81.00, 0.00, 27.50, 108.50, 'CLASSIFICADO', '2013', 4, 6, 2),
(1001, 4, 3855, 'IAGO FERNANDO DE ABREU RODRIGUES', 80.00, 0.00, 28.00, 108.00, 'CLASSIFICADO', '2013', 4, 6, 2),
(1002, 5, 1118, 'ERICK JORGE RIBEIRO FARIZEL', 83.00, 0.00, 23.00, 106.00, 'CLASSIFICADO', '2013', 4, 6, 2),
(1003, 6, 11594, 'ADHAN CHARLLEYS INACIO GOMES', 78.00, 0.00, 23.00, 101.00, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1004, 7, 11828, 'RAIKAR BARRETO DA SILVA STONE', 76.00, 0.00, 24.50, 100.50, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1005, 8, 37505, 'JÉSSYCA MAGALHÃES DE MATOS', 70.00, 0.00, 25.50, 95.50, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1006, 9, 41225, 'DANIEL DO NASCIMENTO ARAÚJO', 68.00, 0.00, 26.00, 94.00, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1007, 10, 12326, 'VICTOR LIEBICH GUSMÃO GIGANTE', 69.00, 0.00, 25.00, 94.00, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1008, 11, 32746, 'EDUARDO WANDERLEY DE ALMEIDA', 68.00, 0.00, 24.50, 92.50, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1009, 12, 43373, 'ANA BEATRIZ RANGEL PLACIDO', 64.00, 0.00, 27.50, 91.50, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1010, 13, 11786, 'AQUILA LINCOLN MELO CHAGAS', 63.00, 0.00, 27.00, 90.00, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1011, 14, 737, 'KERCYA MAYAHARA MOURA CAVALCANTE', 65.00, 0.00, 23.50, 88.50, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1012, 15, 13071, 'ADRIANO HENRIQUE LIMA DE OLIVEIRA', 64.00, 0.00, 17.00, 81.00, 'LISTA DE ESPERA', '2013', 4, 6, 2),
(1013, 1, 4972, 'SHELYSDON SILVA MARTINS', 81.00, 0.00, 25.00, 106.00, 'CLASSIFICADO', '2013', 6, 6, 2),
(1014, 2, 69432, 'PATRÍCIA MARIA BARREIRO NUNES', 60.00, 0.00, 22.00, 82.00, 'LISTA DE ESPERA', '2013', 6, 6, 2),
(1015, 3, 63031, 'SHIRLENI MOREIRA BEZERRA', 41.00, 0.00, 21.00, 62.00, 'LISTA DE ESPERA', '2013', 6, 6, 2),
(1016, 1, 33181, 'FRANCISCO CARLOS CARNEIRO DA SILVA', 85.00, 0.00, 30.00, 115.00, 'CLASSIFICADO', '2013', 8, 6, 2),
(1017, 2, 8692, 'ALEX FÁBIO MATOS NUNES', 83.00, 0.00, 30.00, 113.00, 'CLASSIFICADO', '2013', 8, 6, 2),
(1018, 3, 4985, 'SAMUEL FELIPE RAMIRES FRANCO', 79.00, 0.00, 30.00, 109.00, 'CLASSIFICADO', '2013', 8, 6, 2),
(1019, 4, 11950, 'ARTEMIS DA SILVA SOUZA', 76.00, 0.00, 28.50, 104.50, 'CLASSIFICADO', '2013', 8, 6, 2),
(1020, 5, 586, 'VALTECY MENDES ALMEIDA DE ALBUQUERQUE', 74.00, 0.00, 25.50, 99.50, 'LISTA DE ESPERA', '2013', 8, 6, 2),
(1021, 6, 35741, 'KACIO DA SILVA MOURAO', 72.00, 0.00, 27.00, 99.00, 'LISTA DE ESPERA', '2013', 8, 6, 2),
(1022, 7, 10265, 'BRENO RODRIGUES MOREIRA', 71.00, 0.00, 28.00, 99.00, 'LISTA DE ESPERA', '2013', 8, 6, 2),
(1023, 8, 10885, 'MILTON VILAR FERREIRA DANTAS', 72.00, 0.00, 27.00, 99.00, 'LISTA DE ESPERA', '2013', 8, 6, 2),
(1024, 9, 13405, 'ABIGAIL REBECA RAMIRES FRANCO', 70.00, 0.00, 28.50, 98.50, 'LISTA DE ESPERA', '2013', 8, 6, 2),
(1025, 10, 7780, 'GABRIELA LUDMYLA PEREIRA MARQUES', 71.00, 0.00, 26.50, 97.50, 'LISTA DE ESPERA', '2013', 8, 6, 2),
(1026, 11, 36784, 'JAMIS SOUZA DOS SANTOS', 72.00, 0.00, 21.50, 93.50, 'LISTA DE ESPERA', '2013', 8, 6, 2),
(1027, 12, 1618, 'YASMIN DE FREITAS SANTOS', 68.00, 0.00, 21.50, 89.50, 'LISTA DE ESPERA', '2013', 8, 6, 2),
(1028, 1, 2168, 'JOSE NAZARE MACHADO NETTO', 79.00, 0.00, 28.00, 107.00, 'CLASSIFICADO', '2013', 10, 6, 2),
(1029, 2, 39056, 'JOAO PAULO DE OLIVEIRA CAMARA', 75.00, 0.00, 28.50, 103.50, 'LISTA DE ESPERA', '2013', 10, 6, 2),
(1030, 3, 37984, 'CAIO AUGUSTO LEITÃO MELO', 67.00, 0.00, 22.50, 89.50, 'LISTA DE ESPERA', '2013', 10, 6, 2),
(1031, 1, 63683, 'LUCAS ELIAS FRANÇA', 83.00, 0.00, 27.00, 110.00, 'CLASSIFICADO', '2013', 1, 6, 2),
(1032, 2, 28288, 'DEIVITH DA CRUZ ALBARADO', 64.00, 0.00, 27.00, 91.00, 'CLASSIFICADO', '2013', 1, 6, 2),
(1033, 3, 64188, 'SYSSI OLIVEIRA LARA', 65.00, 0.00, 21.00, 86.00, 'LISTA DE ESPERA', '2013', 1, 6, 2),
(1034, 4, 64743, 'CARIN MARIA DANTAS NEIVA', 58.00, 0.00, 17.50, 75.50, 'LISTA DE ESPERA', '2013', 1, 6, 2),
(1035, 5, 39672, 'DORIVAN FLORENCIO RODRIGUES DE OLIVEIRA', 52.00, 0.00, 19.50, 71.50, 'LISTA DE ESPERA', '2013', 1, 6, 2),
(1036, 6, 12774, 'WANDA CAVALCANTE LOTAS', 50.00, 0.00, 19.00, 69.00, 'LISTA DE ESPERA', '2013', 1, 6, 2),
(1037, 1, 38873, 'LUCAS NATHÃ ALMEIDA LIRA', 27.50, 0.00, 94.00, 121.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1038, 2, 43869, 'MARLA MIKAELY DANTAS DE MEDEIROS', 29.50, 0.00, 91.00, 120.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1039, 3, 10793, 'ANA GESSYCA MENEZES ALCÂNTARA', 30.00, 0.00, 89.00, 119.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1040, 4, 951, 'AMANDA PEREIRA TRIANI', 29.50, 0.00, 89.00, 118.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1041, 5, 35155, 'ANTONIO CARLOS DE OLIVEIRA JUNIOR', 27.50, 0.00, 90.00, 117.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1042, 6, 33678, 'JAYNNE BEZERRA MAGALHAES', 26.00, 0.00, 91.00, 117.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1043, 7, 4599, 'LEVI KIYOSHI OYAMA DE SOUZA', 29.00, 0.00, 88.00, 117.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1044, 8, 12034, 'RODRIGO MARQUES CARNEIRO', 28.50, 0.00, 88.00, 116.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1045, 9, 8023, 'MARIANA PEREIRA FERREIRA', 29.50, 0.00, 87.00, 116.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1046, 10, 3370, 'RÔNIKI CLEAN SÁ', 23.50, 0.00, 92.00, 115.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1047, 11, 11597, 'AUGUSTO PATRYCIO SOUSA CAVALCANTE', 24.50, 0.00, 91.00, 115.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1048, 12, 580, 'AMILTON ALBUQUERQUE DA SILVA', 18.00, 0.00, 97.00, 115.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1049, 13, 7819, 'HEVELIN ALINE COSTA DA SILVA', 23.00, 0.00, 92.00, 115.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1050, 14, 7892, 'RODOLFO MOREIRA MONTEIRO', 23.50, 0.00, 91.00, 114.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1051, 15, 32938, 'TIAGO GUIMARÃES GRANA', 24.00, 0.00, 90.00, 114.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1052, 16, 45926, 'ANDREZA KAROLINE SOUZA BARROS DE BRITO', 28.00, 0.00, 86.00, 114.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1053, 17, 4927, 'MATEUS DE CARVALHO SOARES', 29.00, 0.00, 85.00, 114.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1054, 18, 3042, 'ANDIARA NATTRODT THOMÉ', 28.00, 0.00, 84.00, 112.00, 'CLASSIFICADO', '2012', 2, 6, 1),
(1055, 19, 2292, 'KARLA KAROLINA DOS SANTOS FERNANDES', 21.50, 0.00, 90.00, 111.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1056, 20, 724, 'NATACHA HELEN DE ASSUNÇÃO', 23.50, 0.00, 88.00, 111.50, 'CLASSIFICADO', '2012', 2, 6, 1),
(1057, 21, 12609, 'MAYRON DUARTE MELO', 24.50, 0.00, 87.00, 111.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1058, 22, 1174, 'VERA TAINÃ DE MELO RESENDE', 25.50, 0.00, 86.00, 111.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1059, 23, 33969, 'MATHEUS DE AZEVEDO PAIVA', 25.50, 0.00, 86.00, 111.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1060, 24, 4810, 'LÍVIA ROLIM SOUSA', 25.00, 0.00, 86.00, 111.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1061, 25, 646, 'IURI ADÔNIS DE SOUZA NASCIMENTO', 26.00, 0.00, 85.00, 111.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1062, 26, 12310, 'THAIS SUELEN ISRAEL FERREIRA', 27.00, 0.00, 84.00, 111.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1063, 27, 10815, 'CRISTINO ALVES DAMASCENO', 20.50, 0.00, 90.00, 110.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1064, 28, 7743, 'NAYRA DA SILVA FREITAS', 26.00, 0.00, 84.00, 110.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1065, 29, 35976, 'LEONARDO ARAUJO MARQUES', 26.00, 0.00, 84.00, 110.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1066, 30, 984, 'PAULO HENRIQUE BRASIL HASS GONÇALVES FILHO', 20.50, 0.00, 89.00, 109.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1067, 31, 15922, 'THALES CAVALCANTE RAMOS', 22.50, 0.00, 87.00, 109.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1068, 32, 35963, 'NATHALIA JACOB ARAUJO', 23.50, 0.00, 86.00, 109.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1069, 33, 35156, 'HENDEL SANTANA MORAIS', 23.50, 0.00, 86.00, 109.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1070, 34, 876, 'VALÉRIA VIEIRA DA SILVA COUTINHO', 21.00, 0.00, 88.00, 109.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1071, 35, 33379, 'MARDELSON NERY DE SOUZA', 21.00, 0.00, 88.00, 109.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1072, 36, 4251, 'HELLEN KATTERINE BARROS DE OLIVEIRA', 21.50, 0.00, 87.00, 108.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1073, 37, 7610, 'DANILLO NUNES DE BASTOS', 21.00, 0.00, 87.00, 108.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1074, 38, 12758, 'TYRONE ARAUJO SOBRAL', 24.00, 0.00, 84.00, 108.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1075, 39, 848, 'FÁBIO GALDINO MOURA', 19.50, 0.00, 88.00, 107.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1076, 40, 35983, 'GUILHERME ARAUJO MARQUES', 20.50, 0.00, 87.00, 107.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1077, 41, 39016, 'LUCIANO OLIVEIRA AZEVEDO NEVES', 20.00, 0.00, 87.00, 107.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1078, 42, 2710, 'LUIZ GUSTAVO MENDES COIMBRA', 22.00, 0.00, 84.00, 106.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1079, 43, 33585, 'JOHN NASCIMENTO DA CONCEICAO', 22.00, 0.00, 84.00, 106.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1080, 44, 35719, 'THIAGO HENRIQUE HIRAKAWA', 21.00, 0.00, 84.00, 105.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1081, 45, 38678, 'MAYUME NICHIDA RODRIGUES', 20.00, 0.00, 84.00, 104.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1082, 46, 1246, 'LUCAS DUTRA LEITE', 20.50, 0.00, 83.00, 103.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1083, 47, 520, 'DANILLO MENEZES BASTOS', 18.50, 0.00, 84.00, 102.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1084, 48, 10796, 'TALES CEI HAGE SAADE', 19.50, 0.00, 83.00, 102.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1085, 49, 15547, 'MARIA DE NAZERÉ DOS SANTOS SIMÃO', 15.00, 0.00, 83.00, 98.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1086, 50, 11786, 'AQUILA LINCON MELO CHAGAS', 18.50, 0.00, 62.00, 80.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1087, 51, 877, 'PATRÍCIA DE SOUSA FERNANDES', 19.50, 0.00, 61.00, 80.50, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1088, 52, 36813, 'LUCIANO SENNA MOLINA', 19.00, 0.00, 60.00, 79.00, 'LISTA DE ESPERA', '2012', 2, 6, 1),
(1089, 53, 37325, 'TOBIAS SILVA BOTELHO', 15.50, 0.00, 60.00, 75.50, 'LISTA DE ESPERA', '2012', 2, 6, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_tipo_prova`
--

CREATE TABLE `tb_tipo_prova` (
  `id` int(10) UNSIGNED NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_tipo_prova`
--

INSERT INTO `tb_tipo_prova` (`id`, `tipo`) VALUES
(1, 'PSS1'),
(2, 'PSS2'),
(3, 'PSS3'),
(4, 'INDÍGENA'),
(5, 'INTEGRAL');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'ROMERO GOMES DA SILVA', 'ROMERO.UFRR@GMAIL.COM', NULL, '$2y$10$RSG787vXRfKG5btWxhaQS.fjCiM0AdMXE.nquSrnZHbqY3RgVnaO.', NULL, '2018-11-25 23:46:23', '2018-11-25 23:46:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `tb_alternativas`
--
ALTER TABLE `tb_alternativas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_cota`
--
ALTER TABLE `tb_cota`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_cursos`
--
ALTER TABLE `tb_cursos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_cursos_tipo`
--
ALTER TABLE `tb_cursos_tipo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_disciplina`
--
ALTER TABLE `tb_disciplina`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_edital`
--
ALTER TABLE `tb_edital`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_gabarito`
--
ALTER TABLE `tb_gabarito`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_instituicao`
--
ALTER TABLE `tb_instituicao`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_resultado_final`
--
ALTER TABLE `tb_resultado_final`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_tipo_prova`
--
ALTER TABLE `tb_tipo_prova`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tb_alternativas`
--
ALTER TABLE `tb_alternativas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_cota`
--
ALTER TABLE `tb_cota`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tb_cursos`
--
ALTER TABLE `tb_cursos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tb_cursos_tipo`
--
ALTER TABLE `tb_cursos_tipo`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_disciplina`
--
ALTER TABLE `tb_disciplina`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tb_edital`
--
ALTER TABLE `tb_edital`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tb_gabarito`
--
ALTER TABLE `tb_gabarito`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=764;

--
-- AUTO_INCREMENT for table `tb_instituicao`
--
ALTER TABLE `tb_instituicao`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_resultado_final`
--
ALTER TABLE `tb_resultado_final`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1090;

--
-- AUTO_INCREMENT for table `tb_tipo_prova`
--
ALTER TABLE `tb_tipo_prova`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
